//Toxic
 exports.bad = [
"anjing","Anjing","Memek","Asu","Asw","Bangsat","Tolol",
"Goblok","Gblk","Ajg","Kontol","mmk","Bangsat","Gblk","tolol",
"peler","Pler","ajg","asw","asu","Babi","kontol","ngentot","bngst"
]
//Toxic
 exports.dosa = [
"Bokep","bokep","bct","Bct","Ngentod","Snge","Sange","Blok","ngewe",
"Ngewe","Ngentd","vcs","Vcs","Coli","coli","colmek","Colmek",
"toket","Toket","oyo","Ah ah ah"
]
//Badword
 exports.badword = ["asu","Asu","asw","Asw","Ajg","ajg",
"Anjing","anjing","Bajingan","bajingan","Bjingan","bjingan",
"Babi","babi","Bacot","bacot","Bcot","bcot","Cacat","cacat",
"Jancok","jancok","Jncok","jncok","Kontol","kontol","Kntl",
"kntl","KONTOL","kirek","Kirek","Lonte","lonte","Lnte","lnte",
"Memek","memek","Mmek","mmek","Pler","pler","Silet","Silit",
"silit","Silet","Tai","tai","Taek","taek"
]

//Ucapan selamat malem
 exports.katamalem = [
"Selamat malam","selamat malam","Malam",
"malam","Malem","malem","oyasumi","Oyasumi",
"Oyasuminasai","oyasuminasai","Night","night",
"Good night","good night","Selamat tidur","selamat tidur"
]
//Ucapan terimakasih 
 exports.thanks = [
"hnk","hanks","akasih","ksh","ksih"
]
//Ucapan lopyu
 exports.katalopyu = [
"lopyu","lopyutu","i love you","love","lopyu","Lopyu"
]
//Ucapan selamat siang
 exports.katasiang = [
"Selamat siang","selamat siang",
"Siang","siang","koniciwa","Koniciwa"
]
//Ucapan selamat sore
 exports.katasore = [
"Selamat sore","selamat sore","Sore","sore"
]
//Ucapan selamat pagi
 exports.ohayo = [
"pagi","Pagi","ohayo","Ohayo"
]
//Respon salam kenal
 exports.ken = [
"salken","Salken","slkn","Slkn","Slken"
]
//Ucapan hai
 exports.katahai = [
"Halo","halo","Hallo","hallo","Hai","hai","Moshi moshi",
"moshi moshi","Kirara","kirara","Woy","woy","woyy","weh","Weh"
]
//Respon spam bot
 exports.teksspam = [
"Ups kamu terdeteksi spam",
"Jangan spam kak",
"Jangan spam dong kak, nanti dibanned nie",
"Gak boleh spam kak",
"Wey kak jangan spam ashu"
]
//Respon game salah
 exports.tekssalah = [
"Salah","Bukan","Salah salah salah","Sualah","Selamat jawaban kamu salah",
"Coba lagi","Hampir","Dikit lagi","Bukan bukan","Yah salah","Yahaha salah",
"Bukan itu","No!","Horeeeee!\nEh salah bukan itu","Asik salah",
"Masih salah 😎","Bukan itu bambang"
]
//Respon orang gblok
 exports.salam = [
"P","p","p","Pp","pp","P","pP","PP"
]
//Respon link gc private OFF
 exports.rangel = [
"Link","link","Link grup","Link group","Linkgc","linkgc"
]
//Respon panggilan bot
 exports.katabot = [
"bot","Bot","bott","Bott"
]
//Respon ara ara
 exports.katara = [
"ara","Ara","ara ara","Ara ara"
]
//Respon wibu
 exports.katakawai = [
"yare","yare yare","baka","Baka","gambare","Gambare"
]
//===========================================================//
//GANTI SETERAH LUH
//Ownerin
 exports.devoloper1 = "6281316643491"

