const fs = require("fs");
const path = require("path");
const Jimp = require('jimp');
const axios = require("axios");
const moment = require("moment-timezone");
const { ttsAudio } = require('../lib/scraper');

async function autoOpenCloseGc(conn) {
  let setTime = global.db.data.others?.setTime || {};
  const groupIds = Object.keys(setTime);
  
  for (const groupId of groupIds) {
    const { timeOpen, timeClose, reasonOpen, reasonClose } = setTime[groupId];
    const now = moment().tz("Asia/Jakarta").format("HH:mm");   
    let groupMetadata = await conn.groupMetadata(groupId).catch(() => null);
    if (!groupMetadata) {
        return
        continue;
      }
    let mems = groupMetadata.participants.map(participant => participant.id);
    if (timeOpen && now === timeOpen) {
      try {
        await conn.groupSettingUpdate(groupId, 'not_announcement');
        console.log(`Grup ${groupId} berhasil dibuka pada ${timeOpen}`);           const fteks = { 
  key: { 
    fromMe: false, 
    participant: groupId, 
    ...(groupId ? { remoteJid: "status@broadcast" } : {}) 
  }, 
  message: { 
    "conversation": " 🔔 Notification " 
  } 
};
        let teksBuka = `🌟 Grup telah *dibuka* pada waktu yang dijadwalkan (${timeOpen}). Anggota kini dapat mengirim pesan.\n\n📄 *Alasan:* ${reasonOpen || "Tidak ada alasan yang diberikan."}`;        let audioBuffer = await ttsAudio(teksBuka)
      conn.sendMessage(
          groupId,
          { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true })

        
        await conn.sendMessage(groupId, { text: teksBuka,contextInfo: { mentionedJid: mems }},{quoted:fteks}); 
        
      } catch (error) {
        return
      }
    }  
    if (timeClose && now === timeClose) {
      try {
        await conn.groupSettingUpdate(groupId, 'announcement');
        console.log(`Grup ${groupId} berhasil ditutup pada ${timeClose}`);   
     const fteks = { 
  key: { 
    fromMe: false, 
    participant: groupId, 
    ...(groupId ? { remoteJid: "status@broadcast" } : {}) 
  }, 
  message: { 
    "conversation": " 🔔 Notification " 
  } 
};
        let teksTutup = `🔒 Grup telah *ditutup* pada waktu yang dijadwalkan (${timeClose}). Hanya admin yang dapat mengirim pesan.\n\n📄 *Alasan:* ${reasonClose || "Tidak ada alasan yang diberikan."}`;    
        await conn.sendMessage(groupId, { text: teksTutup,contextInfo: { mentionedJid: mems }},{quoted:fteks});
      } catch (error) {
        return
      }
    }
  }
}

async function notifGcAlarm(conn) {
  let setTimeAlarm = global.db.data.others?.setTimeAlarm || [];
  let timeAlarm = global.db.data.others?.timeAlarm || [];
  if (setTimeAlarm.length > 0) {
    for (let i = 0; i < setTimeAlarm.length; i++) {
      const { chatId, time, teks, alarmName } = setTimeAlarm[i];  
      const now = moment().tz("Asia/Jakarta").format("HH:mm");   
      if (now === time) {     
        let groupMetadata = await conn.groupMetadata(chatId).catch(() => null);
    if (!groupMetadata) {
        return
        continue;
      }
        let groupName = groupMetadata?.subject || "Grup";
        let teksAlarm = `${gris1}*🔔 ALARM TIBA!*  
🕒 *Waktu:* ${time}  
🏷️ *Nama Alarm:* ${alarmName}  
💬 *Pesan Alarm:* "${teks}"  
📢 *Grup:* ${groupName}  
⏰ *Segera siapkan diri untuk aktivitas berikutnya!*${gris1}`;
        let mems = groupMetadata ? groupMetadata.participants.map(participant => participant.id) : [];     
        await conn.sendMessage(chatId, {
          image: { url: 'https://files.catbox.moe/q97x4s.jpeg' },
          caption: teksAlarm,
          contextInfo: { mentionedJid: mems }
        }); 
        await conn.sendMessage(chatId, {
          audio: { url: 'https://sf16-ies-music-va.tiktokcdn.com/obj/musically-maliva-obj/7266592523120364294.mp3' },
          mimetype: "audio/mp4",
          ptt: true
        });
        console.log(`Alarm "${alarmName}" telah dikirim ke grup ${groupName} pada ${time}.`);        
        if (!timeAlarm.includes(chatId)) {
          timeAlarm.push(chatId);
        }
      }
    }
    global.db.data.others.timeAlarm = timeAlarm;
    global.db.data.others.setTimeAlarm = setTimeAlarm;
  }
}

async function notifPrivate(conn) {
  let notipPrivate = global.db.data.others?.notipPrivate || []; 
  let timePrivate = global.db.data.others?.timePrivate || [];   

  if (notipPrivate.length > 0) {
    for (let i = 0; i < notipPrivate.length; i++) {
      const { chatId, nomorTujuan, time, teks, notifikasiName } = notipPrivate[i];  
      const now = moment().tz("Asia/Jakarta").format("HH:mm"); 
      if (now === time) {
  const fvn = { key: { fromMe: false,participant: nomorTujuan, ...(nomorTujuan ? { remoteJid: "status@broadcast" } : {}) }, message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds": "9999","ptt": "true"}}}

        let teksNotif = transformText (`*🔔 NOTIFIKASI PRIVATE TIBA!*
🕒 *Waktu:* ${time}
🏷️ *Nama Notifikasi:* ${notifikasiName}
💬 *Pesan Notifikasi:* "${teks}"
⏰ *Segera lihat pesan ini untuk informasi lebih lanjut!`);

        try {
          await conn.sendMessage(nomorTujuan, {
  text: teksNotif 
}, {
  quoted: fvn 
});
          console.log(`Notifikasi private "${notifikasiName}" telah dikirim ke ${nomorTujuan} pada ${time}.`);
   
          if (!timePrivate.includes(chatId)) {
            timePrivate.push(chatId);
          }
        } catch (error) {
          return
        }
      }
    }

    global.db.data.others.timePrivate = timePrivate;
    global.db.data.others.notipPrivate = notipPrivate;
  }
}

async function autoOpenCloseGcStore(conn) {
const dataStore = "./database/store/GroupStore.json";
    setInterval(async () => {
        const currentTime = moment().tz("Asia/Jakarta").format("HH:mm");

        if (!fs.existsSync(dataStore)) return;
        let db = JSON.parse(fs.readFileSync(dataStore, "utf-8"));

        for (let group of db) {
            const idGcStore = group.idGc;
            const namaGcStore = group.namaGc || "No Name";
            const waktuOpenStore = group.timeOpen || "";
            const waktuCloseStore = group.timeClose || "";
            const reasonOpen = group.reasonOpen || "Tanpa alasan";
            const reasonClose = group.reasonClose || "Tanpa alasan";

            // Jika waktu saat ini sama dengan waktu buka di database
            if (currentTime === waktuOpenStore && waktuOpenStore !== "") {
                const teksBuka = `🌟 *STORE BUKA* 🌟\n\n📅 *Waktu:* ${waktuOpenStore}\n📌 *Alasan:* \n ${reasonOpen}\n`;

                try {
                    await conn.groupSettingUpdate(idGcStore, "not_announcement");
                    await conn.sendMessage(idGcStore, { text: teksBuka });
                    console.log(`✅ Grup ${idGcStore} telah dibuka pada ${waktuOpenStore} dengan alasan: ${reasonOpen}`);
                } catch (error) {
                    return
                }
            }

          
            if (currentTime === waktuCloseStore && waktuCloseStore !== "") {
                const teksTutup = `🔒 *STORE TUTUP* 🔒\n\n📅 *Waktu:* ${waktuCloseStore}\n📌 *Alasan:* \n ${reasonClose}\n`;

                try {
                    await conn.groupSettingUpdate(idGcStore, "announcement");
                    await conn.sendMessage(idGcStore, { text: teksTutup });
                    console.log(`✅ Grup ${idGcStore} telah ditutup pada ${waktuCloseStore} dengan alasan: ${reasonClose}`);
                } catch (error) {
                    return
                }
            }
        }
    }, 60 * 1000); // Periksa setiap 1 menit
}

async function notifSholatJumat(conn) {
    setInterval(async () => {
        const currentTime = moment().tz('Asia/Jakarta');
        const dayOfWeek = currentTime.format('dddd'); 
        const currentTimeFormatted = currentTime.format('HH:mm'); 

        if (dayOfWeek === "Jumat" && currentTimeFormatted === "11:00") {
            const teksSholatJumat = `🌙 *Pemberitahuan Sholat Jumat* 🌙\nHalo semuanya! Jangan lupa untuk melaksanakan *Sholat Jumat* hari ini. Bersiaplah sebelum adzan berkumandang. Semoga amal ibadah kita diterima oleh Allah SWT. 🙏`;

            try {
                await conn.groupSettingUpdate(idGcBot, 'announcement');
                await conn.sendMessage(idGcBot, { text: teksSholatJumat });
                console.log("Notifikasi Sholat Jumat berhasil dikirim!");
            } catch (error) {
                console.error(`Gagal mengirim notifikasi Sholat Jumat: ${error.message}`);
            }
        }

        if (currentTimeFormatted === "13:00") {
            const teksSholatJumatSiang = `Hallo semuanya, gimana Sholat Jum'at nya? Sudah beres? Sekarang grup telah dibuka kembali.`;

            try {
                await conn.groupSettingUpdate(idGcBot, 'not_announcement');
                await conn.sendMessage(idGcBot, { text: teksSholatJumatSiang });
                console.log("Notifikasi Sholat Jumat Siang berhasil dikirim!");
            } catch (error) {
                console.error(`Gagal mengirim notifikasi Sholat Jumat Siang: ${error.message}`);
            }
        }

    }, 60 * 1000); // Periksa setiap 1 menit
}

async function autoNotifSholat(conn) {
  const notifSholat = global.db.data.others?.notifSholat || {};
  const autonotifSholat = global.db.data.others?.autonotifSholat || {};
  
  
  const imgSholat = {
    shubuh: 'https://pomf2.lain.la/f/a8kx7qr5.jpg',
    dzuhur: 'https://pomf2.lain.la/f/t7m10ph5.jpg',
    ashar: 'https://pomf2.lain.la/f/dn8n9y5s.jpg',
    magrib: 'https://pomf2.lain.la/f/gql8sri.jpg',
    isya: 'https://pomf2.lain.la/f/b46jiomf.jpg',
  };

  const groupIds = Object.keys(notifSholat);
  const now = moment().tz("Asia/Jakarta").format("HH:mm");

  for (const groupId of groupIds) {
    const isAutonotifActive = autonotifSholat[groupId]?.status;
    if (!isAutonotifActive) continue; // Skip jika auto-notifikasi tidak aktif

    const jadwalSholat = notifSholat[groupId];
    if (!jadwalSholat) continue;

    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
      if (now === waktu) {
        try {
          const groupMetadata = await conn.groupMetadata(groupId).catch(() => null);
          if (!groupMetadata) continue;
          const mems = groupMetadata.participants.map((participant) => participant.id);
          const groupName = groupMetadata?.subject || "Grup";

          const thumbnailUrl = imgSholat[sholat] || 'https://pomf2.lain.la/f/fm7dfpvc.jpg'; // Gunakan fallback jika tidak ada gambar

          const contextInfo = {
            externalAdReply: {
              title: `Hai Anggota grup ${groupName}`,
              body: `Waktu ${sholat.toUpperCase()} telah tiba. Ambil wudhu dan tunaikan sholat ya! 😊`,
              mediaType: 1,
              thumbnailUrl,
              sourceUrl: "https://instagram.com/ehanzdhoanx",
              renderLargerThumbnail: true,
            },
          };

          await conn.sendMessage(groupId, {
            audio: { url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ' },
            mimetype: "audio/mp4",
            ptt: true,
            contextInfo,
            mentionedJid: mems,
          });

          console.log(`Notifikasi sholat '${sholat}' dikirim ke grup ${groupName} (${groupId})`);
        } catch (error) {
          return
        }
      }
    }
  }
}

async function autoSholat(conn) {
  const notifSholat = global.db.data.others?.notifSholat || {};
  const autoSholat = global.db.data.others?.autoSholat || {};

  const groupIds = Object.keys(notifSholat); 
  const now = moment().tz("Asia/Jakarta").format("HH:mm");

  for (const groupId of groupIds) {
    const isAutoSholatActive = autoSholat[groupId]?.status; 
    if (!isAutoSholatActive) continue; 

    const jadwalSholat = notifSholat[groupId];
    if (!jadwalSholat) continue; 

    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
      if (now === waktu) {
        try {
          const groupMetadata = await conn.groupMetadata(groupId).catch(() => null);
          if (!groupMetadata) continue;

          const groupName = groupMetadata?.subject || "Grup";
          const teksTutup = `${gris1}🔒 *AUTO SHOLAT* \n\nGrup *${groupName}* telah ditutup selama 5 menit untuk menghormati waktu *${sholat.toUpperCase()}*. Silakan ambil wudhu dan tunaikan sholat! 😊\n\n⏰ *${waktu}*${gris1}`;
          const teksBuka = `${gris1}🔓 *AUTO SHOLAT* \n\nGrup *${groupName}* telah dibuka kembali. Semoga ibadah kalian diterima! 🙏${gris1}`;

          // Tutup grup
          await conn.groupSettingUpdate(groupId, "announcement");
          await conn.sendMessage(groupId, { text: teksTutup });

          console.log(`Grup '${groupName}' ditutup untuk waktu sholat '${sholat}' (${waktu})`);
          setTimeout(async () => {
            try {
          
              await conn.groupSettingUpdate(groupId, "not_announcement");
              await conn.sendMessage(groupId, { text: teksBuka });

              console.log(`Grup '${groupName}' dibuka kembali setelah waktu sholat '${sholat}'`);
            } catch (err) {
              return
            }
          }, 300000); 
        } catch (error) {
          return
        }
      }
    }
  }
}







async function autoSendTugas(conn) {
  const tugasFilePath = "./database/tugas.json";
const mediaFolder = "./database/tugas_media";


function loadDataTugas() {
  return fs.existsSync(tugasFilePath) ? JSON.parse(fs.readFileSync(tugasFilePath)) : [];
}
  const dataTugas = loadDataTugas(); 
  const now = moment().tz("Asia/Jakarta").format("HH:mm"); 

  for (const task of dataTugas) {
    if (task.time === now) {
      try {
    let groupMetadata = await conn.groupMetadata(task.chatId).catch(() => null);
 if (!groupMetadata) continue;
 let mems = groupMetadata ? groupMetadata.participants.map(participant => participant.id) : [];    
 let message = `${gris1}✨ *Informasi Tugas Baru* ✨

📅 *Waktu*: ${task.time}  
📌 *Nama Tugas*: "${task.taskName}"  
👥 *Grup*: ${task.groupName}  

📝 *Deskripsi Tugas*:  
"${task.message}"

🔔 Jangan lupa selesaikan tepat waktu!${gris1}`;
        let mediaPath = task.media ? path.resolve(task.media) : null;

        if (mediaPath && fs.existsSync(mediaPath)) {
          const mediaBuffer = fs.readFileSync(mediaPath);
          const mimeType = mediaPath.split(".").pop().toLowerCase(); 

        
          if (["jpg", "jpeg", "png"].includes(mimeType)) {
            await conn.sendMessage(task.chatId, { image: mediaBuffer, caption: message,contextInfo: { mentionedJid: mems } });
          } else if (["mp4"].includes(mimeType)) {
            await conn.sendMessage(task.chatId, { video: mediaBuffer, caption: message,contextInfo: { mentionedJid: mems }
        }); 
          } else if (["mp3", "mpeg", "m4a", "opus"].includes(mimeType)) {
            await conn.sendMessage(task.chatId, {
              audio: mediaBuffer,
              mimetype: `audio/${mimeType}`,
            });
            await conn.sendMessage(task.chatId, { text: message,contextInfo: { mentionedJid: mems }
        }); 
          } else if (["webp"].includes(mimeType)) {
            await conn.sendMessage(task.chatId, { sticker: mediaBuffer });
            await conn.sendMessage(task.chatId, { text: message,contextInfo: { mentionedJid: mems }
        });  
          } else {
            await conn.sendMessage(task.chatId, {
              document: mediaBuffer,
              fileName: path.basename(mediaPath),
            });
            await conn.sendMessage(task.chatId, { text: message,contextInfo: { mentionedJid: mems }
        });  
          }
        } else {
          console.warn(`Media untuk tugas "${task.taskName}" tidak ditemukan di ${mediaPath}.`);
          await conn.sendMessage(task.chatId, {
            text: `📅 *Tugas "${task.taskName}"*:\n${task.message}\n\n🔎 Media tidak Ada.`,contextInfo: { mentionedJid: mems }
          });
        }

        console.log(`Tugas "${task.taskName}" berhasil dikirim ke grup ${task.chatId}`);
      } catch (error) {
        return
      }
    }
  }
}

async function updateGempa(conn) {
  try {
   if (!global.db.data.others) global.db.data.others = {};
    let gempa = global.db.data.others.updateGempa;
    let data1 = global.db.data.others.infogempa;
  
    if (!gempa) global.db.data.others.updateGempa = [];

    if (gempa && gempa.length > 0) {
      setInterval(async () => {
        const { data } = await axios.get("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json");

        let nana = /TimurLaut|Tenggara|BaratDaya|BaratLaut|Utara|Timur|Selatan|Barat/;
        let lokasi = data.Infogempa.gempa.Wilayah;
        let waktu = data.Infogempa.gempa.Jam;

        let caption = `${gris1}*📢 INFO GEMPA TERKINI 📢*

📅 *Tanggal:* ${data.Infogempa.gempa.Tanggal}
⏰ *Waktu:* ${data.Infogempa.gempa.Jam}
📍 *Koordinat:* ${data.Infogempa.gempa.Coordinates}
💥 *Magnitudo:* ${data.Infogempa.gempa.Magnitude}
🌊 *Kedalaman:* ${data.Infogempa.gempa.Kedalaman}
📌 *Lokasi:* ${data.Infogempa.gempa.Wilayah}
⚠️ *Potensi:* ${data.Infogempa.gempa.Potensi}
📡 *Dirasakan di:* ${data.Infogempa.gempa.Dirasakan}

*Catatan:*
_Untuk menonaktifkan fitur pembaruan otomatis mengenai gempa, silakan ketik_ *.updategempa off*

🌍 *Tetap waspada dan jaga keselamatan diri!*${gris1}`;
 if (data1) {
          let getGroups = await conn.groupFetchAllParticipating();
          let groups = Object.entries(getGroups).map(entry => entry[1]);
          let groupIds = groups.map(v => v.id);
          let image = { url: "https://data.bmkg.go.id/DataMKG/TEWS/" + data.Infogempa.gempa.Shakemap };

          if (data1.lokasi !== lokasi && data1.waktu !== waktu) {
            data1.lokasi = lokasi;
            data1.waktu = waktu;

            for (let groupId of gempa) {
              if (!groupIds.includes(groupId)) {
                gempa.splice(gempa.indexOf(groupId), 1); 
                console.log("Menghapus auto update gempa pada grup");
              } else {
                await sleep(3000);
                await conn.sendMessage(groupId, { image, caption });
              }
            }
          }
        } else {
          let getGroups = await conn.groupFetchAllParticipating();
          let groups = Object.entries(getGroups).map(entry => entry[1]);
          let groupIds = groups.map(v => v.id);
          let image = { url: "https://data.bmkg.go.id/DataMKG/TEWS/" + data.Infogempa.gempa.Shakemap };

          global.db.data.others.infogempa = {
            lokasi: lokasi,
            waktu: waktu
          };
for (let groupId of gempa) {
            if (!groupIds.includes(groupId)) {
              gempa.splice(gempa.indexOf(groupId), 1); 
              console.log("Menghapus auto update gempa pada grup");
            } else {
              await sleep(3000);
              await conn.sendMessage(groupId, { image, caption });
            }
          }
        }
      }, 60_000 * 10); // Interval pembaruan setiap 10 menit
    }

  } catch (err) {
      return
    //console.error("Error in mainFunction:", err);
  }
}
//======== Notif Imsakiyah ========//

async function autoSendNotifImsakiyah(conn) {
    const path = "./database/Ramadhan/GroupNotification.json";

    let settings = global.db.data.settings["settingbot"];
    let status = settings.Ramadhan;

    if (!status) {
        console.log("🚫 Notifikasi Ramadhan dinonaktifkan.");
        return;
    }

    if (!fs.existsSync(path)) return;

    let now = moment().tz("Asia/Jakarta");
    let hour = now.hours();
    let minute = now.minutes();
    let day = now.date();

    let notifications = JSON.parse(fs.readFileSync(path));

    for (let notif of notifications) {
        try {
            let groupMetadata = await conn.groupMetadata(notif.chatId).catch(() => null);
            if (!groupMetadata) continue;

            let mems = groupMetadata.participants.map(participant => participant.id);

            // 🎯 Audio berdasarkan jenis waktu
                                         let audioAdzan = 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
            let audioSources = {
                "Sahur": "https://www.tikwm.com/video/music/7476468701865184517.mp3",
                "Imsak": "https://www.tikwm.com/video/music/7213846251035528474.mp3",
                "Subuh": "https://raw.githubusercontent.com/Muler-Official/upload-db-media/main/uploader/9e243fe0b9.mp3",
                "Dzuhur": `${audioAdzan}`,
                "Ashar":  `${audioAdzan}`,
                "Maghrib": `${audioAdzan}`,
                "Isya": `${audioAdzan}`
            };

            // 🕒 Pengingat Sahur (03:00 WIB)
            if (hour === 3 && minute === 0) {
                let teksSahur = "📢 *Pengingat Waktu Sahur*\n\nMohon perhatian, bagi Anda yang akan melaksanakan sahur, segeralah sahur. Atas nama *PT Rangelofficial*, kami mengucapkan *selamat menikmati santap sahur Anda*. Terima kasih.";
                
                await conn.sendMessage(notif.chatId, { 
                    audio: { url: audioSources["Sahur"] }, 
                    mimetype: 'audio/mp4', 
                    ptt: true 
                });

                await conn.sendMessage(notif.chatId, { text: teksSahur });

                console.log(`✅ Notifikasi sahur terkirim ke ${notif.chatId}`);
                continue;
            }

            // 🕌 Ambil Data Imsakiyah
            let response = await axios.post("https://equran.id/api/v2/imsakiyah", {
                provinsi: notif.provinsi,
                kabkota: notif.kabkota
            });

            let data = response.data;
            if (data.code !== 200 || !data.data[0]) continue;

            let jadwal = data.data[0].imsakiyah.find(j => parseInt(j.tanggal) === day);
            if (!jadwal) continue;

            let jadwalTimes = {
                "Imsak": jadwal.imsak,
                "Subuh": jadwal.subuh,
                "Dzuhur": jadwal.dzuhur,
                "Ashar": jadwal.ashar,
                "Maghrib": jadwal.maghrib,
                "Isya": jadwal.isya
            };

            // 🔄 Loop untuk mengecek waktu sholat yang sesuai
            for (let [waktu, jam] of Object.entries(jadwalTimes)) {
                let [h, m] = jam.split(":").map(Number);

                if (h === hour && m === minute) {
                    let message = `${gris1}🕌🌙 *Marhaban Ya Ramadhan! هَلْ هَلْ 🌟* \n\n📍 *${notif.kabkota}, ${notif.provinsi}*\n⏰ Sekarang waktunya *${waktu}*\n\n💖 Perbanyak dzikir, tingkatkan ibadah, dan raih keberkahan di bulan suci ini! 🤲✨${gris1}`;

                    await conn.sendMessage(notif.chatId, { 
                        audio: { url: audioSources[waktu] }, 
                        mimetype: 'audio/mp4', 
                        ptt: true 
                    });

                    await conn.sendMessage(notif.chatId, { 
                        text: message });

                    

                    console.log(`✅ Notifikasi ${waktu} terkirim ke ${notif.chatId}`);
                }
            }
        } catch (error) {
            return
        }
    }
}


module.exports = { 
autoOpenCloseGc,
notifGcAlarm,
notifSholatJumat,
notifPrivate,
autoOpenCloseGcStore,
autoNotifSholat,
autoSholat,
autoSendTugas,
updateGempa,
autoSendNotifImsakiyah
};