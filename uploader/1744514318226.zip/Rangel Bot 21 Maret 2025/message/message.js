const { stikOtw, stikSpam, stikAdmin, stikTagOwn, stikBug, stikCmd, stikToxic, stikSalam, stikOwner, stikThanks, stikDel, stikError, stikSucces,stikBan } = require('../message/autosticker.js');

// Fungsi untuk mengambil sticker secara acak
const getRandomSticker = (stickerArray) => stickerArray[Math.floor(Math.random() * stickerArray.length)];

module.exports = async (m, conn, senderNumber, prefix, command, setReply) => {
    const responType = db.data.settings['settingbot'].responType;

    global.mess = {
        wait: () => {
            if (responType === "text") {
                m.reply('_꩜ 𝘗𝘳𝘰𝘤𝘦𝘴𝘴𝘪𝘯𝘨 ꩜_ _ _ _');
            } else if (responType === "sticker") {
                const stikot = getRandomSticker(stikOtw);
                conn.sendSticker(m.chat, stikot, m);
            }
        },
        spam: () => {
            if (responType === "text") {
                setReply('Beri bot jeda 5 detik!');
            } else if (responType === "sticker") {
                const stikSpm = getRandomSticker(stikSpam);
                conn.sendSticker(m.chat, stikSpm, m);
            }
        },
        baned: () => {
            if (responType === "text") {
                setReply('Kamu telah di banned karena telah melakukan spam!');
            } else if (responType === "sticker") {
                const stikBaned = getRandomSticker(stikBan);
                conn.sendSticker(m.chat, stikBaned, m);
            }
        },
        query: () => {
            if (responType === "text") {
                setReply('Masukan query!');
            } else if (responType === "sticker") {
                setReply('Masukan query!');
            }
        },
        success: () => {
            if (responType === "text") {
                setReply('Berhasil!');
            } else if (responType === "sticker") {
                const stikSucs = getRandomSticker(stikSucces);
                conn.sendSticker(m.chat, stikSucs, m);
            }
        },
        error: {
            link: () => {
                if (responType === "text") {
                    setReply('Error api atau linkya mungkin!');
                } else if (responType === "sticker") {
                    const stikEr = getRandomSticker(stikError);
                    conn.sendSticker(m.chat, stikEr, m);
                }
            }
        },
        block: {
            Bowner: () => {
                if (responType === "text") {
                    setReply('Maaf kak command tersebut telah di block oleh owner!');
                } else if (responType === "sticker") {
                    setReply('Maaf kak command tersebut telah di block oleh owner!');
                }
            },
            Bsystem: () => {
                if (responType === "text") {
                    setReply('Command tersebut telah di block oleh system karena terjadi error!');
                } else if (responType === "sticker") {
                    setReply('Command tersebut telah di block oleh system karena terjadi error!');
                }
            }
        },
        only: {
            prem: () => {
                if (responType === "text") {
                    setReply('Fitur khusus user premium, hubungi owner untuk membeli premium!');
                } else if (responType === "sticker") {
                    setReply('Fitur khusus user premium, hubungi owner untuk membeli premium!');
                }
            },
            owner: () => {
                if (responType === "text") {
                    setReply('Fitur Khusus Owner Bot!');
                } else if (responType === "sticker") {
                    const stikOwn = getRandomSticker(stikOwner);
                    conn.sendSticker(m.chat, stikOwn, m);
                }
            },
            group: () => {
                if (responType === "text") {
                    setReply('*Group Only* - Command ini hanya dapat digunakan di grup!');
                } else if (responType === "sticker") {
                    setReply('*Group Only* - Command ini hanya dapat digunakan di grup!');
                }
            },
            admin: () => {
                if (responType === "text") {
                    setReply('Fitur ini hanya dapat digunakan oleh Admin Group!');
                } else if (responType === "sticker") {
                    const stikAdmn = getRandomSticker(stikAdmin);
                    conn.sendSticker(m.chat, stikAdmn, m);
                }
            },
            badmin: () => {
                if (responType === "text") {
                    setReply('Fitur dapat Digunakan Setelah Bot menjadi ADMIN!');
                } else if (responType === "sticker") {
                    setReply('Fitur dapat Digunakan Setelah Bot menjadi ADMIN!');
                }
            }
        }
    };

                
                
  
global.dfail = (type) => {
let msg = {
    
rowner: "*Owner Only* - Command ini hanya untuk owner bot!",
owner: "*Owner Only* - Command ini hanya untuk owner bot!",
mods: "*Owner Only* - Command ini hanya untuk owner bot!",
premium: "*Premium Only* - Command ini hanya untuk member premium!",
group: "*Group Only* - Command ini hanya dapat digunakan di grup!",
groupvip: "*❌ Not Acces* - Command ini hanya dapat digunakan di grup VIP!",
nocmdstore: `*❌ Not Acces* - Command ini Tidak Dapat Di Gunakan Di ${m.groupName} !`,
cmdstore: "*❌ Not Acces* - Coomand Hanya Dapat Digunakan Di Group Store!",
private: "*Private Only* - Command ini hanya dapat digunakan di chat pribadi!",
admin: "*Admin Only* - Command ini hanya untuk admin grup!",
selerpanel: '🚫 *Akses Ditolak!* \n\nMaaf, fitur ini hanya dapat digunakan oleh anggota *Reseller Panel*. \n\n✨ *Bergabunglah dengan kami untuk menikmati fitur eksklusif ini!*',
botAdmin: "Jadikan bot sebagai admin untuk menggunakan command ini",
onlyprem: "Hanya user *premium* yang dapat menggunakan fitur ini di *private chat*!!",
nsfw: "Admin menonaktifkan fitur *NSFW* di grup ini!",
rpg: "Admin menonaktifkan fitur *RPG Game* di grup ini!",
game: "Admin menonaktifkan fitur *Game* di grup ini!",
limitExp: "Limit kamu habis! Beberapa command tidak dapat diakses!\n\nKamu bisa beli limit caranya dengan mengetik *.buy limit 5*",
restrict: "Fitur ini tidak dapat digunakan!!",
unreg: `Silahkan daftar ke *database* bot terlebih dahulu jika ingin menggunakan fitur ini!\n\n📝 *Format Pendaftaran:*

   *.daftar nama,umur*  
   Contoh: *.daftar John.25*\n`,

}[type];

if (msg)
return setReply(msg)
};
 

}





const fs = require("fs");
const { color } = require("../lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})