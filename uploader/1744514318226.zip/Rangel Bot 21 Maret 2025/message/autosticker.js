exports.stikOtw = [
// oke tunggu bentar kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080626461.webp"
]
exports.stikToxic = [
// istighfar kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737079699099.webp" 
]
exports.stikSpam = [
// bentar dulu kak 
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056134004.webp",
// jangan spam dong
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737079906743.webp'
]
exports.stikAdmin = [
 //hany qadmin hang bisa kak
"https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737079414268.webp" 
]
exports.stikTagOwn = [ "https://cdn.filestackcontent.com/jbXPAjcHRNSYNalvhbBD" ]
exports.stikOwner = [
// ga boleh
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056734997.webp'
]
exports.stikBug = [ 'https://cdn.filestackcontent.com/pPZCyTUJT2WqARnZ4Qo1' ]

exports.stikDel = [
// apaan tuh kak
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737055956041.webp']
exports.stikCmd = [
 // bodo ah 
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056275723.webp',
// ga ada dalam menu nih
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056610209.webp',
// ga mau aku ngambek
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737079100675.webp',
// hadeuhh
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737079197059.webp',
// ketik menu
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080132952.webp',
// ketik nya yang benar dong
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080301188.webp',
// mau ku jotos
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080464171.webp'
]
exports.stikBan = [
// kakak telah di banned 
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080910200.webp'
]
exports.stikThanks = [
// sama sama
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737080768907.webp'
]
exports.stikSalam = [
// ucap salam napa
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737081031478.webp'
]
exports.stikSucces = [
// done kak
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056416633.webp'
]
exports.stikError = [
// error kak
'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1737056532333.webp'
]