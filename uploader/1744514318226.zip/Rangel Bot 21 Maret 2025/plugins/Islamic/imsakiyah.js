const axios = require('axios');

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`📌 *Cara Penggunaan:* 
🔹 *${usedPrefix + command} provinsi* → Melihat daftar provinsi yang tersedia
🔹 *${usedPrefix + command} <nama provinsi>* → Melihat daftar kabupaten/kota dalam provinsi
🔹 *${usedPrefix + command} <nama provinsi> | <kabupaten/kota>* → Melihat jadwal imsakiyah

📝 *Contoh:* 
✔ ${usedPrefix + command} provinsi
✔ ${usedPrefix + command} Jawa Barat
✔ ${usedPrefix + command} Jawa Barat | Kab Tasikmalaya`);
    }

    let args = text.split("|").map(a => a.trim());

    if (args.length === 1 && args[0].toLowerCase() === "provinsi") {
        try {
            let response = await axios.get("https://equran.id/api/v2/imsakiyah/provinsi");
            let data = response.data.data;

            let pesan = "📌 *Daftar Provinsi yang Tersedia:* 📌\n\n";
            pesan += data.map((prov, i) => `${i + 1}. ${prov}`).join("\n");

            return m.reply(`${pesan}\n\nContoh Penggunaan : Imsakiyah Jawa Barat`);
        } catch (error) {
            console.error(error);
            return m.reply("❌ Terjadi kesalahan saat mengambil daftar provinsi.");
        }
    }

    if (args.length === 1) {
        let provinsi = args[0];
        try {
            let response = await axios.post("https://equran.id/api/v2/imsakiyah/kabkota", { provinsi });
            let data = response.data.data;

            if (!data || data.length === 0) {
                return m.reply("⚠ Provinsi tidak ditemukan atau tidak tersedia.");
            }

            let pesan = `📍 *Daftar Kabupaten/Kota di ${provinsi}:* 📍\n\n`;
            pesan += data.map((kab, i) => `${i + 1}. ${kab}`).join("\n");

            return m.reply(`${pesan}\n\nContoh Penggunaan : Imsakiyah Jawa Barat | Kota Tasikmalaya`);
        } catch (error) {
            console.error(error);
            return m.reply("❌ Terjadi kesalahan saat mengambil daftar kabupaten/kota.\nSilahkan Sesuaikan Nama Kab Yng Ada Di List");
        }
    }

    if (args.length === 2) {
        let [provinsi, kabkota] = args;

        try {
            let response = await axios.post("https://equran.id/api/v2/imsakiyah", { provinsi, kabkota });
            let data = response.data;

            if (data.code !== 200) {
                return m.reply("⚠ Gagal mendapatkan data. Pastikan nama provinsi dan kabupaten/kota benar.");
            }

            let jadwal = data.data[0].imsakiyah;
            let pesan = `📅 *Jadwal Imsakiyah ${kabkota}, ${provinsi}* 📅\n\n`;

            jadwal.forEach(j => {
                pesan += `📆 Tanggal: ${j.tanggal} Ramadan 1446 H\n`;
                pesan += `⏳ Imsak: ${j.imsak}\n`;
                pesan += `🕌 Subuh: ${j.subuh}\n`;
                pesan += `🌅 Terbit: ${j.terbit}\n`;
                pesan += `🌞 Dhuha: ${j.dhuha}\n`;
                pesan += `🕛 Dzuhur: ${j.dzuhur}\n`;
                pesan += `🕒 Ashar: ${j.ashar}\n`;
                pesan += `🌇 Maghrib: ${j.maghrib}\n`;
                pesan += `🌙 Isya: ${j.isya}\n\n`;
            });

            return m.reply(pesan);
        } catch (error) {
            console.error(error);
            return m.reply("❌ Terjadi kesalahan saat mengambil data, coba cek lagi kesalahan nya.");
        }
    }
};

handler.help = ["imsakiyah"];
handler.tags = ["search"];
handler.command = ["imsakiyah"];
handler.noCmdStore = true;

module.exports = handler;