const toMs = require('ms');
const chalk = require('chalk');
const fs = require('fs-extra');
const moment = require('moment-timezone');
const util = require('util');
const { exec, spawn } = require('child_process');
const axios = require('axios');
const speed = require('performance-now');
const ms = require('parse-ms');
const fetch = require('node-fetch');
const cheerio = require('cheerio');


//----------------- LIB FILE ------------------\\
const { getDateId, resetLevelingXp, userXp, userLeveling, getLevelingXp, getLevelingLevel, getLevelingId, addLevelingXp, addLevelingLevel, addUserId } = require("../../lib/user");
const { msgFilter, addSpam, SpamExpired, cekSpam} = require('../../lib/antispam')
const { addblockcmd, deleteblockcmd, checkblockcmd } = require ("../../lib/blockcmd");
const { addError,clearAllError, deleteError, checkError } = require("../../lib/totalerror")
const { Nothing,Failed,Succes,addAutoClear,autoClearChat, checkDataName, createDataId, addDataId, removeDataId, checkDataId, getHit, cmdAdd, expiredCmd } = require("../../lib/totalcmd");
const { cekBannedUser } = require("../../lib/banned")
const {randomNomor,isNumber,makeid,pickRandom,getBuffer } = require("../../lib/myfunc")
//=== message 
const {bad,thanks,ken,dosa,katamalem,katasiang,katasore,katalopyu,ohayo,devoloper1,teksspam,tekssalah,katara,katabot,katakawai,kataaii,ppTolak,ppLimit,badword} = require('../../message/messages')
const {vnToxic,vnMenu,vnSalam,vnAra, vnBot,vnSpam,vnPagi,vnSiang,vnMalam,vnOwner, vnKawai, vnLove} = require('../../message/autovn.js')
const { stikOtw,stikSpam,stikAdmin,stikTagOwn,stikBug,stikToxic } = require('../../message/autosticker.js')

const {register} = require("../../message/register.js")
const {settings} = require("../../message/settingsbot.js")
const { Logmessage, Logcommands, Logerror } = require('../../message/logger');
const databaseStore = "./database/store/GroupStore.json";
let dataStore = JSON.parse(fs.readFileSync(databaseStore, "utf-8"));

let handler = (m) => m;
handler.before = async function (m, { conn, q,isPremium, command, setReply, isOwner,prefix,thePrefix,store }) {

  try{
  //Database 
  const AntiSpam = db.data.antispam;
  const DataId = db.data.data;
  const ban = db.data.banned;
  const listcmdblock = db.data.blockcmd;
  const listerror = db.data.listerror;
  const hitnya = db.data.hittoday;
  const dash = db.data.dashboard;
  const allcommand = db.data.allcommand;
  const spammer = [];

  const { type,args, reply,sender,ucapanWaktu,from,botNumber,senderNumber,groupName,groupId,groupMembers,groupDesc,groupOwner,pushname,itsMe,isGroup,mentionByTag,mentionByReply,users,budy,content,body } = m
// settings
settings(m,isNumber)
 var autoRead = db.data.settings['settingbot'].autoRead
var responType = db.data.settings['settingbot'].responType
  
var Ownerin = `${nomerOwner}@s.whatsapp.net`

  const isCmd = m.body.startsWith(prefix);
  const chat = global.db.data.chats[m.chat];
  
  const timeWib = moment().tz('Asia/Jakarta').format('HH:mm:ss')
  const user = global.db.data.users[m.sender]
  const numberQuery = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`
  const Input = (mentionByTag && mentionByTag[0]) ? mentionByTag[0] : (mentionByReply || q ? numberQuery : false);

//FAKE REPLY  
require("../../message/alfake.js")(m,pushname,sender,ucapanWaktu,body)

   
//Type data
const isReaction = (m.type == 'reactionMessage')
const isAllMedia = (m.type === 'imageMessage' || m.type === 'videoMessage' || m.type === 'stickerMessage' || m.type === 'audioMessage' || m.type === 'contactMessage' || m.type === 'locationMessage')
const isSticker = (type == 'stickerMessage')



// function 
const getRandomMedia = (mediaArray) => mediaArray[Math.floor(Math.random() * mediaArray.length)];
//STIKER saat ada yg toxic
const stikToxc = getRandomMedia(stikToxic)
// Security 
const isAntiBadword = m.isGroup ? db.data.chats[m.chat].antibadword : false; 
const isGame = isGroup ? db.data.chats[from].game : false

//function security 
/*if (isGroup && isAntiBadword) {
    // Daftar kata toxic
    const badWords = /Anjing|Monyet|Setan|Goblog|Yatim|ngentot|Memek|Kontol|Asu|coli|sange|Bot goblog|ngewe/i;
    
    if (badWords.test(budy)) {

        if (m.isAdmin) return m.reply('Alah, admin grup mah bebas yekan :v');
 
        if (!m.isBotAdmin) return 

        if (responType === "text") {
            await conn.sendMessage(from, { text: 'Jangan kasar-kasar dong.' }, { quoted: m });
        } else if (responType === "sticker") {
            await conn.sendSticker(m.chat, stikToxc, m);
        } else {
            await conn.sendMessage(from, { text: 'Jangan kasar-kasar dong.' }, { quoted: m });
        }

      
        await conn.sendMessage(from, { delete: m.key });
    }
}*/
/*if (m.message && m.message.reactionMessage) {
    try {
        // Hanya berjalan di grup
        if (!m.isGroup) return;

const groupMetadata = isGroup ? await conn.groupMetadata(m.chat).catch(e => {}) : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''

 const isBotAdmin = isGroup ? groupAdmins.includes(botNumber) : false
        if (!isBotAdmin) {
            return console.log("⚠️ Bot bukan admin, fitur kick & hapus pesan tidak bisa digunakan.");
        }

        // Ambil emoji yang digunakan untuk reaksi
        let emoji = m.message.reactionMessage.text;
        
        // Coba memuat pesan yang mendapatkan reaksi
        let reactedMessage;
        try {
            reactedMessage = await conn.loadMessage(m.chat, m.message.reactionMessage.key.id);
        } catch (err) {
            return console.log("❌ Gagal memuat pesan yang di-react:", err);
        }

        // Pastikan reactedMessage valid
        if (!reactedMessage || !reactedMessage.key) {
            return console.log("❌ Tidak bisa menemukan detail pesan yang di-react!");
        }

        let sender = reactedMessage.key.participant || reactedMessage.key.remoteJid;

        if (!sender) {
            return console.log("❌ Tidak bisa menemukan pengirim pesan yang di-react!");
        }

        // Jika emoji yang digunakan adalah kaki 🦵
        if (emoji === '🖕🏻') {
            const isAdmin = participants.find(p => p.id === sender)?.admin;
            const isOwner2 = sender === isOwner;

            if (!isAdmin && !isOwner) {
                console.log(`🦵 Mengeluarkan ${sender} karena mendapatkan reaksi kick!`);
                await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
            } else {
                console.log(`✅ Tidak bisa meng-kick ${sender}, karena mereka adalah admin/owner.`);
            }

            // Hapus pesan yang mendapat reaksi kaki
            await conn.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: reactedMessage.key.id, 
                    participant: sender 
                }
            });
        }
    } catch (err) {
        console.error("❌ Terjadi kesalahan saat menangani reaksi kaki:", err);
    }
}
if (m.message && m.message.reactionMessage) {
    try {
        // Hanya berjalan di grup
        if (!m.isGroup) return;

        const groupMetadata = isGroup ? await conn.groupMetadata(m.chat).catch(e => {}) : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''

 const isBotAdmin = isGroup ? groupAdmins.includes(botNumber) : false

        if (!isBotAdmin) {
            return console.log("⚠️ Bot bukan admin, fitur kick & hapus pesan tidak bisa digunakan.");
        }

        // Ambil emoji yang digunakan untuk reaksi
        let emoji = m.message.reactionMessage.text;
        console.log(`ℹ️ Emoji yang digunakan: ${emoji}`);

        // Ambil ID pesan yang mendapat reaksi
        let messageId = m.message.reactionMessage.key.id;
        let chatId = m.chat;

        console.log(`ℹ️ Mencoba memuat pesan dengan ID: ${messageId}`);

        // Coba memuat pesan yang mendapatkan reaksi
        let reactedMessage;
        try {
            reactedMessage = await conn.loadMessage(chatId, messageId);
            console.log("✅ Pesan ditemukan dengan loadMessage.");
        } catch (err) {
            console.log("⚠️ loadMessage gagal, mencoba fetchMessage...");
            try {
                reactedMessage = await conn.fetchMessage(chatId, messageId);
                console.log("✅ Pesan ditemukan dengan fetchMessage.");
            } catch (fetchErr) {
                return console.log("❌ Gagal memuat pesan yang di-react:", fetchErr);
            }
        }

        // Pastikan reactedMessage valid
        if (!reactedMessage || !reactedMessage.key) {
            return console.log("❌ Tidak bisa menemukan detail pesan yang di-react!");
        }

        let sender = reactedMessage.key.participant || reactedMessage.key.remoteJid;

        if (!sender) {
            return console.log("❌ Tidak bisa menemukan pengirim pesan yang di-react!");
        }

        console.log(`ℹ️ Pesan yang di-react berasal dari: ${sender}`);

        // Jika emoji yang digunakan adalah kaki 🦵
        if (emoji === '🦵') {
            //const isAdmin = participants.find(p => p.id === sender)?.admin;
            const isOwner2 = sender === isOwner;

            if (!isBotAdmin && !isOwner2) {
                console.log(`🦵 Mengeluarkan ${sender} karena mendapatkan reaksi kick!`);
                await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
            } else {
                console.log(`✅ Tidak bisa meng-kick ${sender}, karena mereka adalah admin/owner.`);
            }

            // Hapus pesan yang mendapat reaksi kaki
            await conn.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: reactedMessage.key.id, 
                    participant: sender 
                }
            });
        }
    } catch (err) {
        console.error("❌ Terjadi kesalahan saat menangani reaksi kaki:", err);
    }
}*/
        

            
// =========== FUNCTION GAME ===========//
const sendReact = (emoji) => {
conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
}
const salahGame = ["❌", "🙈", "🤦", "❎"];
const emotSalah = pickRandom(salahGame);
let teksHampirBenar = [
            `🤏 *Dikit Lagi!* Kamu hampir berhasil, coba lagi!`,
            `🧐 Hmm, sudah hampir benar! Ayo coba sekali lagi.`,
            `⏳ *Sedikit Lagi!* Jawabanmu hampir benar, ayo lanjutkan!`
        ];
        let hampirBenar = pickRandom(teksHampirBenar);
// GAME SUSUNKATA 
 conn.susunkata =  conn.susunkata ?  conn.susunkata : {};
 conn.susunkataCooldown =  conn.susunkataCooldown ?  conn.susunkataCooldown : {};

if (isGroup && from in  conn.susunkata) {
    const cooldownTime = 5000; 
    const threshold = 0.72; 
    const id = m.chat;
    const gameData =  conn.susunkata[id];
    const json = JSON.parse(JSON.stringify(gameData[1]));
    if ( conn.susunkataCooldown[id]) {
        let lastInteraction =  conn.susunkataCooldown[id];
        if (new Date() - lastInteraction < cooldownTime) {
            return; 
        }
    }
     conn.susunkataCooldown[id] = new Date(); 
    if (budy.toLowerCase() === json.jawaban.toLowerCase().trim()) {
        user.balance += gameData[2]; 
        user.exp += 999; 
        const successResponses = [
            `${gris1}🎉 *Benar!* Kamu jenius! 💡\n+${gameData[2]} Balance 💸\n+999 EXP 📈${gris1}`,
            `${gris1}✨ *Jawaban tepat!* Hebat sekali! 🌟\n+${gameData[2]} Balance 💵\n+999 EXP 🆙${gris1}`,
            `${gris1}🔥 *Sempurna!* Kamu berhasil! 🏆\n+${gameData[2]} Balance 💸\n+999 EXP 🌠${gris1}`
        ];
        const chosenResponse = pickRandom(successResponses);
        reply(chosenResponse); 
        clearTimeout(gameData[3]); 
        delete  conn.susunkata[id]; 
    } 
    else if (similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
         reply(hampirBenar); 
    } 
    else {
  sendReact(emotSalah)      
     
    }
}   
// TEKA TEKI
 conn.tekateki =  conn.tekateki || {}; 
 conn.tekatekiCooldown =  conn.tekatekiCooldown || {}; 
if (isGroup && from in  conn.tekateki) {
    if (!isGroup) return; 
    const threshold = 0.72; 
    let id = m.chat;
    let json = JSON.parse(JSON.stringify( conn.tekateki[id][1]));
    if ( conn.tekatekiCooldown[id]) {
        let lastInteraction =  conn.tekatekiCooldown[id];
        if (new Date() - lastInteraction < 5000) {
            return; 
        }
    }
     conn.tekatekiCooldown[id] = new Date();
    if (budy.toLowerCase() === json.jawaban.toLowerCase().trim()) {
        user.balance +=  conn.tekateki[id][2];
        let correctReplies = [
            `${gris1}🎉 *GAME TEKA-TEKI*\n\nJawaban Kamu Benar! 🎊\n\nHadiah: +${ conn.tekateki[id][2]} Balance 💸\nExp: +999🆙${gris1}`,
            `${gris1}🔥 *GAME TEKA-TEKI*\n\nLuar biasa! Kamu berhasil! 💪\n\nBonus: +${ conn.tekateki[id][2]} Balance 💵\nExp: +999📈${gris1}`,
            `${gris1}✨ *GAME TEKA-TEKI*\n\nKamu jago! Jawaban benar! 🎯\n\nBonus: +${ conn.tekateki[id][2]} Balance 💸\nExp: +999🆙${gris1}`
        ];
        let replyCorrect = pickRandom(correctReplies);
        reply(replyCorrect); 
        clearTimeout( conn.tekateki[id][3]);
        delete  conn.tekateki[id]; 
    } 
    else if (similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
        
        reply(hampirBenar);
    } 
    else {
      sendReact(emotSalah) 
    }
}

// TEBAK KIMIA
 conn.tebakkimia =  conn.tebakkimia ?  conn.tebakkimia : {}  
if(isGroup && from in  conn.tebakkimia){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.tebakkimia[id][1]))
 let isSurender = /^((me)?nyerah|surr?ender)$/i.test(budy)
 if (budy.toLowerCase() == json.lambang.toLowerCase().trim()) {
user.balance +=  conn.tebakkimia[id][2]
 global.db.data.users[m.sender].exp += 10
   let tebkKmia = `${gris1}*GAME TEBAK KIMIA*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebakkimia[id][2]} Balance 💸${gris1}`
setReply(tebkKmia)
 clearTimeout( conn.tebakkimia[id][3])
 delete  conn.tebakkimia[id]
 } else if(similarity(budy.toLowerCase(), json.lambang.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
// CAK LONTONG
 conn.caklontong =  conn.caklontong ?  conn.caklontong : {}  
if(isGroup && from in  conn.caklontong){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.caklontong[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
 global.db.data.users[m.sender].exp +=  conn.caklontong[id][2]
 let ckLntg = `${gris1}*GAME CAKLONTONG*\n*Benar!*\n+${ conn.caklontong[id][2]} XP\n+1500 Money\n${json.deskripsi}${gris1}`
setReply(ckLntg)
 clearTimeout( conn.caklontong[id][3])
 delete  conn.caklontong[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
  // TEBAK LAGU
 conn.tebaklagu =  conn.tebaklagu ?  conn.tebaklagu : {}  
if(isGroup && from in  conn.tebaklagu){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.tebaklagu[id][1]))
 if (budy.toLowerCase() == json.judul.toLowerCase().trim()) {
user.balance +=  conn.tebaklagu[id][2]
 let tbkLgu = `${gris1}*GAME TEBAK LAGU*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebaklagu[id][2]} Balance 💸${gris1}`
   reply (tbkLgu)
 clearTimeout( conn.tebaklagu[id][3])
 delete  conn.tebaklagu[id]
 } else if(similarity(budy.toLowerCase(), json.judul.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
// TEBAK TEBAKAN
 conn.tebaktebak =  conn.tebaktebak ?  conn.tebaktebak : {}  
if(isGroup && from in  conn.tebaktebak){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.tebaktebak[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.balance +=  conn.tebaktebak[id][2]
 global.db.data.users[m.sender].exp += 50
let tebkTbk = `${gris1}*GAME TEBAK TEBAKAN*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebaktebak[id][2]} Balance 💸\n EXP: +50${gris1}`
reply (tebkTbk)
   clearTimeout( conn.tebaktebak[id][3])
 delete  conn.tebaktebak[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
  // TEBAKKATA
 conn.tebakkata =  conn.tebakkata ?  conn.tebakkata : {}  
if(isGroup && from in  conn.tebakkata){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.tebakkata[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.balance +=  conn.tebakkata[id][2]
 var teks6 = `${gris1}*GAME TEBAK KATA*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebakkata[id][2]} Balance 💸${gris1}`
   reply (teks6)
 clearTimeout( conn.tebakkata[id][3])
 delete  conn.tebakkata[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
// TEBAK LIRIK
 conn.tebaklirik =  conn.tebaklirik ?  conn.tebaklirik : {}  
if(isGroup && from in  conn.tebaklirik){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
let json = JSON.parse(JSON.stringify( conn.tebaklirik[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.balance +=  conn.tebaklirik[id][2]
 global.db.data.users[m.sender].exp += 10
   var teks7 = `${gris1}*GAME TEBAK LIRIK*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebaklirik[id][2]} Balance 💸\n EXP: +10${gris1}`
   reply (teks7)
 clearTimeout( conn.tebaklirik[id][3])
 delete  conn.tebaklirik[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
 // SIAPAKAH AKU
 conn.siapaaku =  conn.siapaaku ?  conn.siapaaku : {}
if(isGroup && from in  conn.siapaaku){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.siapaaku[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.balance +=  conn.siapaaku[id][2]
let spaAku = `${gris1}*GAME SIAPAKAH AKU*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.siapaaku[id][2]} Balance 💸${gris1}`
 setReply(spaAku)
 clearTimeout( conn.siapaaku[id][3])
 delete  conn.siapaaku[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
else {
      sendReact(emotSalah) 
    }
}
  // TEBAK GAMBAR
 conn.tebakgambar =  conn.tebakgambar ?  conn.tebakgambar : {}  
if(isGroup && from in  conn.tebakgambar){
if(!isGroup) {return} 
const threshold = 0.72
let id = m.chat
 let json = JSON.parse(JSON.stringify( conn.tebakgambar[id][1]))
 if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
user.balance +=  conn.tebakgambar[id][2]
let bnarGmbar = `${gris1}*GAME TEBAK GAMBAR*\n\nJawaban Kamu Benar!\n Hadiah : +${ conn.tebakgambar[id][2]} Balance 💸${gris1}`
reply(bnarGmbar)
 clearTimeout( conn.tebakgambar[id][3])
 delete  conn.tebakgambar[id]
 } else if(similarity(budy.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) setReply(`*Dikit Lagi!*`)
    else {
      sendReact(emotSalah) 
    }
}
//Game Family 100
 conn.family =  conn.family ?  conn.family : {}
if(isGroup && from in  conn.family){
if(!isGroup) {return} 
let threshold = 0.72 
let id =  m.chat
let room =  conn.family[id]
let textG = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
if (!isSurrender) {
let index = room.jawaban.indexOf(textG)
if (index < 0) {
if (Math.max(...room.jawaban.filter((_, index) => !room.terjawab[index]).map(jawaban => similarity(jawaban, textG))) >= threshold) return setReply('Dikit lagi!')
 }
if (!isCmd && room.terjawab[index]) {return} 
user.balance += room.winScore
room.terjawab[index] = m.sender
}
let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
let caption = `${gris1}*GAME FAMILY100*

*Soal:* ${room.soal}

Terdapat ${room.jawaban.length} jawaban${room.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
`: ''}
${isWin ? `*SEMUA JAWABAN TERJAWAB ✅*` : isSurrender ? '*MENYERAH ❌*' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
 return isSurrender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '✓ ' + room.terjawab[index].split('@')[0]  : ''}`.trim() : false
 }).filter(v => v).join('\n')}

${isSurrender ? '' : `+${room.winScore} Money tiap jawaban benar`}
     ${gris1}`.trim()
 conn.sendMessage(from, {text: `${caption}`, mentions: [room.terjawab + '@s.whatsapp.net']}, {quoted: m}).then(msg => {
  conn.family[id].msg = msg
}).catch(_ => _)
if (isWin || isSurrender) delete  conn.family[id] }


// ======= command:====== //
  try{
  switch (command) {

// ========== FITUR GAME ==========//
case 'susunkata': {
    if (!isGame) return dfail('game'); 
    if (!isGroup) return; 
    if (!isPremium && global.db.data.users[sender].glimit < 1) {
        return dfail('limitExp'); 
    }
    let poin = 1000; 
    let timeout = 120000; 
    let id = m.chat;
    if (id in  conn.susunkata) {
        return setReply('Masih ada soal belum terjawab di chat ini.');
    }
    try {
        let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json')).json();
        let json = src[Math.floor(Math.random() * src.length)]; 
        let caption = 
            `*🎮 GAME SUSUN KATA 🎮*\n\n` +
            `*Soal :* ${json.soal}\n` +
            `*Tipe :* ${json.tipe}\n\n` +
            `⏱ *Timeout:* ${(timeout / 1000).toFixed(2)} detik\n` +
            `🎁 *Exp:* +999\n` +
            `💸 *Bonus:* +${poin} Balance\n`.trim()
        ;
         conn.susunkata[id] = [
            await setReply(caption), 
            json, 
            poin, 
            setTimeout(async () => {
                conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m);
                await m.reply(
                    `⏱ *Waktu habis!*\n` +
                    `Jawaban yang benar adalah: *${json.jawaban}*`
                );
                delete  conn.susunkata[id]; 
            }, timeout),
        ];
        db.data.users[sender].glimit -= 1;
        m.reply('1 limit game Anda telah terpakai.');
    } catch (err) {
        console.error(err); 
    }
}
break;          
case 'tekateki': {
    if (!isGame) return dfail('game')
    if (!isGroup) return;
    if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp')

    let poin = 1000; 
    let timeout = 120000; 
    let id = m.chat;
    if (id in  conn.tekateki) {
        return reply('Masih ada soal belum terjawab di chat ini.');
    }

  
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json')).json();
    let json = src[Math.floor(Math.random() * src.length)]; 

    let caption = `
*Soal :* ${json.soal}

Timeout: *${(timeout / 1000).toFixed(2)} detik*
Exp: +999
Bonus: +${poin} Balance
`.trim();
 
     conn.tekateki[id] = [
        await reply(caption),
        json,
        poin,
        setTimeout(async () => {
            if ( conn.tekateki[id]) {
conn.sendSticker( m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m);
 await reply(`Waktu game telah habis.\nJawabannya adalah: ${json.jawaban}`);
                delete  conn.tekateki[id];
            }
        }, timeout),
    ];

 
    db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break;
case 'tebakbendera':{
if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 1000
let timeout = 120000
let id = m.chat
if (id in  conn.tebakbendera) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let teks = Ehztext(`Bendera Apakah Ini ?\n
Timeout *${(timeout / 1000).toFixed(2)} detik*
Exp : +999
Bonus : +${poin} Balance`.trim())
 conn.tebakbendera[id] = [
 conn.sendImage(from, json.img , teks, m),
json,
setTimeout(async () => {
if ( conn.tebakbendera[id]) 
 conn.sendSticker( m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m);
await reply(`Waktu game telah habis
Jawabannya adalah : ${json.name}`)  
delete  conn.tebakbendera[id]
 }, timeout)
 ]
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
case 'caklontong':{
if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 3000
let timeout = 120000
let tiketcoin = 1
let id = m.chat
if (id in  conn.caklontong) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let caption = `*Soal :* ${json.soal}\n\n
Timeout *${(timeout / 1000).toFixed(2)} detik*
Bonus : +${poin}
Tiketcoin : +${tiketcoin} `.trim()
 conn.caklontong[id] = [
await setReply(caption),
json, poin,
setTimeout(async () => {
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`Waktu game telah habis
Jawabannya adalah : ${json.jawaban}

${json.deskripsi}`)  
delete  conn.caklontong[id]
 }, timeout)
 ]
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
case 'tebakkimia':{
if (!isGame) return dfail('game')
    if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
if (!isGroup) return;
	let timeout = 40000
	let poin = 1000
	let id = m.chat
	if (id in  conn.tebakkimia) return setReply('Masih ada soal belum terjawab di chat ini')
	let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkimia.json')).json()
	let json = src[Math.floor(Math.random() * src.length)]
	let caption = `*TEBAK KIMIA*
	Unsur: ${json.unsur}
	Soal: Singkatan atau lambang di atas adalah...
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Hadiah: ${poin} Balance
	`.trim()
	 conn.tebakkimia[id] = [
	await setReply(caption),
	json, poin,
	setTimeout(async () => {
	if ( conn.tebakkimia[id]) 
user.balance -= 200
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`*GAME TEBAK KIMIA*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.jawaban}*\n𖦹 Balance kamu dikurangi 200\n𖦹 Sisa Balance kamu: *${db.data.users[sender].balance.toLocaleString()}*`)
	delete  conn.tebakkimia[id]
	 }, timeout)
	 ]
	
    db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
        }
	break
 case 'tebakkata':{
  if (!isGame) return dfail('game');
if (!isGroup) return
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 1000
let timeout = 120000
let id = m.chat
if (id in  conn.tebakkata) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let caption = `*Soal :* ${json.soal}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Exp : +999
Bonus : +${poin} Balance`.trim()
 conn.tebakkata[id] = [
await setReply(caption),
json, poin,
setTimeout(async () => {
if ( conn.tebakkata[id]) 
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`Waktu game telah habis
Jawabannya adalah : ${json.jawaban}`)
delete  conn.tebakkata[id]
 }, timeout)
 ]

db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
     }
break
 case 'tebaklirik':{
if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 1000
let timeout = 120000
let id = m.chat
if (id in  conn.tebaklirik) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let caption = `*Soal :* ${json.soal}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Exp : +999
Bonus : +${poin} Balance`.trim()
 conn.tebaklirik[id] = [
await setReply(caption),
json, poin,
setTimeout(async () => {
if ( conn.tebaklirik[id]) 
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`Waktu game telah habis
  Jawabannya adalah : ${json.jawaban}`)  
delete  conn.tebaklirik[id]
 }, timeout)
 ]
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
case 'tebaklagu':{
    if (!isGame) return dfail('game');
if (!isGroup) return ;
	let timeout = 60000
	let poin = 1200
	let id = m.chat
	if (id in  conn.tebaklagu) return setReply('Masih ada soal belum terjawab di chat ini')
	let src = await (await fetch('https://raw.githubusercontent.com/qisyana/scrape/main/tebaklagu.json')).json()
	let json = src[Math.floor(Math.random() * src.length)]    
 var lagu = await  conn.sendMessage(from, {audio: {url: `${json.lagu}`, ptt: true, mimetype: 'audio/mpeg'}}, { quoted: m })
	let caption = `${gris1}*TEBAK LAGU*
	Artis: ${json.artis}
	Soal: Judul lagu di atas adalah...
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Hadiah: ${poin} Balance${gris1}
	`.trim()
	 conn.tebaklagu[id] = [
		await  conn.sendMessage(from, {text: caption}, {quoted: m}),
	json, poin,
	setTimeout(async () => {
	if ( conn.tebaklagu[id]) 
     user.balance -= 200
let tbkLgu = `${gris1}*GAME TEBAK LAGU*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.judul}*\n𖦹 Balance kamu dikurangi 200\n𖦹 Sisa Balance kamu: *${db.data.users[sender].balance.toLocaleString()}*${gris1}`
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(tbkLgu)
	delete  conn.tebaklagu[id]
	 }, timeout)
	 ]
	
    db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
    }
	break
case 'tebakgambar':{
  if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 1000
let timeout = 120000
let id = m.chat
if (id in  conn.tebakgambar) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let kentir = await getBuffer(json)       
let teks = Ehztext(`*Soal :* ${json.deskripsi}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Exp : +999
Bonus : +${poin} Balance`.trim())
 conn.tebakgambar[id] = [
 conn.sendImage(from, json.img , teks, m),
json,
setTimeout(async () => {
if ( conn.tebakgambar[id])
conn.sendSticker(m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`Waktu game telah habis
Jawabannya adalah : ${json.jawaban}`)  
delete  conn.tebakgambar[id]
 }, timeout)
 ]
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
case 'siapaaku':
case 'siapakahaku':{
if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let poin = 1000
let timeout = 120000
let id = m.chat
if (id in  conn.siapaaku) return setReply('Masih ada soal belum terjawab di chat ini')
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let caption = `*Soal :* ${json.soal}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Exp : +999
Bonus : +${poin} Balance`.trim()
 conn.siapaaku[id] = [
await setReply(caption),
json, poin,
setTimeout(async () => {
if ( conn.siapaaku[id]) 
conn.sendSticker( m.chat,'https://pomf2.lain.la/f/wjw7ptlr.webp',m)
await reply(`Waktu game telah habis
Jawabannya adalah : ${json.jawaban}`)  
delete  conn.siapaaku[id]
 }, timeout)
 ]
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
case 'family100': {
if (!isGame) return dfail('game');
if (!isGroup) return;
if (!isPremium && global.db.data.users[sender].glimit < 1) return dfail('limitExp');
let winScore = 1000
let id = m.chat
if (id in  conn.family) return reply('Masih ada kuis yang belum terjawab di chat ini') 
let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')).json()
let json = src[Math.floor(Math.random() * src.length)]
let caption = Ehztext(`*Soal :* ${json.soal}

Terdapat *${json.jawaban.length}* jawaban${json.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
`: ''}

+${winScore} Money tiap jawaban benar
`.trim())
 conn.family[id] = {
id,
msg: await m.reply(caption),
...json,
terjawab: Array.from(json.jawaban, () => false),
winScore,
}
db.data.users[sender].glimit -= 1;
    m.reply('1 limit game Anda telah terpakai.');
}
break
    case ">":
      {
        if (!isOwner) return mess.only.owner()
        try {
          let evaled = await eval(q);
          if (typeof evaled !== "string")
            evaled = require("util").inspect(evaled);
          m.reply(evaled);
        } catch (err) {
          m.reply(String(err));
        }
      }
      break;

    case '=>':
      {
        if (!isOwner) return mess.only.owner()
        try {
          let evaled = await eval(`(async () => { ${q} })()`);
          if (typeof evaled !== "string")
            evaled = require("util").inspect(evaled);
          await setReply(evaled);
        } catch (err) {
          await setReply(String(err));
        }
      }
      break;



    
    case 'sendcase':
try {
   if (!isOwner && !itsMe) return mess.only.owner()
    if (!q) return setReply("*Mau kirim Case apa kak?*");
    let who;
    try {
        if (m.isGroup) {
            who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
        } else {
            who = m.sender; 
        }
    } catch (err) {
        if (m.isGroup) {
            who = args[0] + '@s.whatsapp.net'; 
        } else {
            who = m.sender; 
        }
    }
    if (!who) return setReply(`Tag atau nomor tidak ditemukan!`);
    if (q.startsWith(prefix)) return setReply("Query tidak boleh menggunakan prefix");
const getCase = (cases) => {
return "case  "+`'${cases}'`+fs.readFileSync("./plugins/Case/case.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
    let caseData = await getCase(q);
    if (!caseData) return setReply(`Case ${q} tidak ditemukan`);
  let kirCas = `${gris}Hai Kak Ada Kiriman case Dari Owner Ku Nih${gris} \n\n ${caseData}`
    await conn.sendMessage(who, { text: kirCas });
    setReply(`Case "${q}" berhasil dikirim ke ${who}`);
} catch (err) {
    console.log(err);
    setReply(`Case ${q} tidak ditemukan atau terjadi kesalahan`);
}
break;

  case 'spamtag': {
 if (!isOwner) return mess.only.owner();
 if (!isGroup) return reply('❌ Perintah ini hanya bisa digunakan di dalam grup!');
 if (!args[0]) return reply('❌ Format salah! Gunakan: .spamtag @user|jumlah|pesan');
 let input = args.join(" ").split("|");
 let mentionedUser = input[0].trim();
 let jumlahTag = parseInt(input[1]);
 let customMessage = input.slice(2).join(" ") || "⚡ Tag!"; 

 if (!mentionedUser.includes("@")) return reply('❌ Tag pengguna yang valid!');
 if (isNaN(jumlahTag) || jumlahTag < 1) return reply('❌ Jumlah harus angka dan minimal 1!');
 if (jumlahTag > 10) return reply('❌ Maksimal hanya bisa menandai 10 kali per perintah!');

 reply(`🔁 Menandai ${mentionedUser} sebanyak ${jumlahTag} kali dengan pesan: "${customMessage}"`);

 for (let i = 0; i < jumlahTag; i++) {
 setTimeout(() => {
 conn.sendMessage(from, { 
 text: `${customMessage} @${mentionedUser.replace("@", "")}`, 
 mentions: [mentionedUser.replace("@", "") + "@s.whatsapp.net"] 
 });
 }, i * 2000); // Jeda 2 detik per tag
 }
}
break
  case 'chat': { 
if (!isOwner) return mess.only.owner() 
 if (!args[0] || !args[1]) return m.reply(`Gunakan: *${prefix}chat nomor|pesan*\nContoh: *${prefix}chat 81234567890|Hai, apa kabar?*`);
const activeReplies = {}; 
 let [target, ...pesanConfessArray] = args.join(' ').split('|');
 let pesanConfess = pesanConfessArray.join('|').trim(); 
 if (!target || !pesanConfess) throw `Format salah! Gunakan: *${prefix}chat nomor|pesan*\nContoh: *${prefix}chat 81234567890|Hai, apa kabar?*`;
 let nomor = target.replace(/[^0-9]/g, ''); 
 nomor += '@s.whatsapp.net';
 try {
 await conn.sendMessage(nomor, { text: pesanConfess }, { quoted: m });
 conn.sendText(m.chat, `Pesan berhasil dikirim ke ${target}.\n\n*Pesan:* ${pesanConfess}`, m);
 } catch (err) {
 conn.sendText(m.chat, `Gagal mengirim pesan ke ${target}. Pastikan nomor benar.\n\n*Error:* ${err}`, m);
 return;
 }
 if (!activeReplies[nomor]) {
 activeReplies[nomor] = m.chat; 
 conn.ev.on('messages.upsert', async (chatUpdate) => {
 try {
 if (!chatUpdate.messages) return;
 let msg = chatUpdate.messages[0];
 if (msg.key.remoteJid !== nomor || msg.key.fromMe) return;
 let balasan = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
 if (balasan) {
 conn.sendText(activeReplies[nomor], `*Balasan dari ${target}:*\n\n${balasan}`, m);
 } 
 delete activeReplies[nomor];
 } catch (err) {
 console.error('Error handling reply:', err);
 }
 });
 } else { 
 conn.sendText(m.chat, `Sedang menunggu balasan dari ${target}...`, m);
 }
}
break;
  default:
  } //Akhir switch command
//------- BATAS DARI AREA CASE -------\\
if (budy.startsWith('https://vt.tiktok.com/') || 
    budy.startsWith('https://www.tiktok.com/') || 
    budy.startsWith('https://vm.tiktok.com/')) {
    try {
        let res = await fetch(`https://api.agatz.xyz/api/tiktok?url=${budy}`);
        let json = await res.json();

        if (json.status !== 200 || !json.data.status) {
            return await conn.sendMessage(m.chat, { text: "🚫 Gagal mengambil video TikTok. Coba lagi nanti!" }, { quoted: m });
        }

        let fbk = `*🎵 乂 Tiktok Downloader 🎵*\n\n` +
                  `👤 *Nama:* ${json.data.author.fullname}\n` +
                  `🆔 *Nickname:* @${json.data.author.nickname}\n` +
                  `📅 *ID:* ${json.data.id}\n` +
                  `📝 *Deskripsi:* ${json.data.title}\n` +
                  `📅 *Diunggah pada:* ${json.data.taken_at}\n` +
                  `🌎 *Region:* ${json.data.region}\n` +
                  `👀 *Views:* ${json.data.stats.views}\n` +
                  `❤️ *Likes:* ${json.data.stats.likes}\n` +
                  `💬 *Komentar:* ${json.data.stats.comment}\n` +
                  `🔄 *Dibagikan:* ${json.data.stats.share}\n`;

        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        await conn.sendMessage(m.chat, {
            video: { url: json.data.data.find(d => d.type === "nowatermark")?.url || json.data.data.find(d => d.type === "nowatermark_hd")?.url},
            caption: fbk
        }, { quoted: m });

    } catch (err) {
        console.log(err);
        await conn.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat mengunduh video TikTok." }, { quoted: m });
    }
}
      
} catch (err){
  //add to dashboard
if(isCmd) Failed(toFirstCase(command), dash)
let e = util.format(err)

if(err.message.includes("Cannot find module")){
let module = err.message.split("Cannot find module '")[1].split("'")[0]
let teks = `Module ${module} belom di install
silakan install terlebih dahulu`
return setReply(teks)
}

await setReply(`]─────「 *SYSTEM-ERROR* 」─────[\n\n${e}\n\n© ${botName}`)
if(checkError(err.message, db.data.listerror)) return
addError(err.message, command, db.data.listerror)

let media = 'tidak ada'

if(q.length > "0"){
var tetek = q
} else if(q.length == "0"){
var tetek = "No Query ❌"
}

if (isGroup && m.isBotAdmin) {
let linkgc = await conn.groupInviteCode(from)
var yeh = `https://chat.whatsapp.com/${linkgc}`
} else if(isGroup && !m.isBotAdmin){
var yeh = `Botz Is Not Admin`
} else if(!isGroup){
var yeh = `Botz Is Not In The Group`
}

let teks =`
*]───── 「 Laporan Bug ⚠️」 ─────[*

👤 Nama : ${pushname}
📳 Nomer : wa.me/${senderNumber}
📢 Info Laporan :
         _${e}_
🔖 Command : ${prefix}${command}
⏰Time : ${timeWib} Wib
📝 Query : ${tetek}
🧩 Quoted : ${media}
💠 Group : ${isGroup?`${groupName}`:'Di private chat'}
🆔 ID : ${from}
🌐 Link Group : ${yeh}
  
  
`
await conn.sendMessage(Ownerin, {text:teks} , {quoted: fkontak})
await conn.sendMessage(from,{ text: "Laporan error telah dikirim ke Developer Botz"})

}

} catch(err){
  console.log(chalk.bgYellow(chalk.black("[ ERROR CASE ]")),util.format(err))
  let e = String(err)
  if (e.includes("this.isZero")) {return}
  if (e.includes('Connection Closed')){ return }
  if (e.includes('Timed Out')){ return }
  if (e.includes('Value not found')){ return }
  console.log(chalk.white('Message Error : %s'), chalk.green(util.format(e)))
  }
};
module.exports = handler;