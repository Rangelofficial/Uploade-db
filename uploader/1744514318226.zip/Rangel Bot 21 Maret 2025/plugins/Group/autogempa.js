const fs = require("fs");

let handler = async (m, { text, setReply }) => {
  const filePath = "./database/group/notification.json";
  let notificationData;

  try {
    // Membaca file JSON atau membuat data default jika file tidak ada
    notificationData = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch (e) {
    notificationData = [];
  }

  // Mencari entri `updategempa` dalam data
  let updateGempaEntry = notificationData.find((entry) => entry.updategempa);

  // Jika tidak ditemukan, tambahkan entri `updategempa`
  if (!updateGempaEntry) {
    updateGempaEntry = { updategempa: [] };
    notificationData.push(updateGempaEntry);
  }

  const args = text.trim().toLowerCase();

  // Mengecek perintah on/off
  if (args === "on" || args === "off") {
    const chatId = m.chat;

    if (args === "on") {
      // Menambahkan grup ke dalam daftar updategempa jika belum ada
      if (!updateGempaEntry.updategempa.includes(chatId)) {
        updateGempaEntry.updategempa.push(chatId);
        setReply(`Autogempa diaktifkan untuk grup ini.`);
      } else {
        setReply(`Autogempa sudah diaktifkan di grup ini.`);
      }
    } else if (args === "off") {
      // Menghapus grup dari daftar updategempa
      if (updateGempaEntry.updategempa.includes(chatId)) {
        updateGempaEntry.updategempa = updateGempaEntry.updategempa.filter((jid) => jid !== chatId);
        setReply(`Autogempa dinonaktifkan untuk grup ini.`);
      } else {
        setReply(`Autogempa belum diaktifkan di grup ini.`);
      }
    }

    // Menyimpan data setelah perubahan
    try {
      fs.writeFileSync(filePath, JSON.stringify(notificationData, null, 2));
    } catch (e) {
      return setReply("Terjadi kesalahan saat menyimpan data autogempa.");
    }
  } else {
    return setReply("Format salah! Gunakan:\n.autogempa on untuk mengaktifkan autogempa\n.autogempa off untuk menonaktifkan autogempa.");
  }
};

handler.tags = ["admin"];
handler.command = ["autogempa"];
handler.noCmdPrivate = true;
handler.admin = true;
handler.description = ["Aktifkan atau nonaktifkan autogempa."];
module.exports = handler;