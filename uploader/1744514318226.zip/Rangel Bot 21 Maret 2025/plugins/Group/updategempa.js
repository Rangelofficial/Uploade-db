let handler = async (m, { q, prefix, setReply, command, onlyToko, onlyAdmin, onlyBadmin }) => {

    if (!q) return setReply(`*UPDATE GEMPA*\nGunakan perintah: ${prefix + command} on/off`);
    let dataGempa = db.data.others['updateGempa'] || []; 

    if (m.isGroup) {
        if (q.toLowerCase() === "on") {
            if (dataGempa.includes(m.chat)) return setReply("Sudah aktif di group ini.");
            dataGempa.push(m.chat); 
            setReply(`Berhasil menambahkan group ${m.groupName} ke dalam auto update gempa.`);
        } else if (q.toLowerCase() === "off") {
            if (!dataGempa.includes(m.chat)) return setReply("Sudah nonaktif di group ini.");
            dataGempa.splice(dataGempa.indexOf(m.chat), 1); 
            setReply(`Berhasil menonaktifkan group ${m.groupName} dari auto update gempa.`);
        } else {
            return setReply(`Gunakan perintah yang benar, contoh: ${prefix + command} on/off`);
        }
    } else {
        if (!q) return setReply("Masukkan ID grup (idgc).");

        if (dataGempa.includes(m.chat)) return setReply("Sudah aktif untuk grup ini.");
        dataGempa.push(q); 
        setReply(`Berhasil menambahkan ${q} ke dalam auto update gempa.`);
    }
    db.data.others['updateGempa'] = dataGempa;
};

handler.help = ['updategempa'];
handler.tags = ['settings'];
handler.command = ['updategempa'];
handler.group = true
module.exports = handler;