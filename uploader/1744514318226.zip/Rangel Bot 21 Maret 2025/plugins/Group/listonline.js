let handler = async (m, { conn,store, args}) => {
    try {
       
        let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] :m.chat;
        if (!store.presences || !store.presences[id]) {
            return conn.reply(m.chat, 'Tidak ada data online untuk grup ini.', m);
        }
        let online = [...Object.keys(store.presences[id]), conn.user.jid];
        conn.sendText(
            m.chat,
            'List Online:\n\n' +
                online
                    .map((v) => '⭔ @' + v.replace(/@.+/, ''))
                    .join('\n'),
            m,
            { mentions: online }
        );
    } catch (e) {
        console.error(e);
       return
    }
};

// Properti plugin
handler.help = ['listonline'];
handler.tags = ['group'];
handler.command = /^listonline$/i;
handler.noCmdPrivate = true;

module.exports = handler;
