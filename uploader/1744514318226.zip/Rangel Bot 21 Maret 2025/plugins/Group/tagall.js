// tagall.js

let handler = async (m, { q,conn,setReply, command,onlyToko,onlyAdmin,onlyBadmin}) => {
   if (!m.isGroup) return mess.only.group()
   if (!m.isAdmin) return mess.only.admin()
if (!m.isBotAdmin) return mess.only.badmin()
    
 const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ?  conn.sendMessage(m.chat, { text: teks, mentions: memberr, contextInfo: { "mentionedJid": memberr }}):  conn.sendMessage(m.chat, {mentions: memberr,text: teks, contextInfo: { "mentionedJid": memberr }},{quoted: m})
}
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001) 
    let inpo = q ? q : `I love you` + readmore + `tube :v`; // Default message or custom message

    let members_id = [];
    let tes = '\n';
    m.groupMembers.forEach(i => {
        tes += `• @${i.id.split('@')[0]}\n`; 
        members_id.push(i.id); 
    });

    mentions(`${inpo}\n${tes}`, members_id, false);
};

handler.help = ["tagall"];
handler.tags = ["group"];
handler.command = ["tagall"];

module.exports = handler;
