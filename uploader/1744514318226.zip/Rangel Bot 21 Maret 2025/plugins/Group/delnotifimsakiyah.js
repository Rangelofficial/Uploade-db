const fs = require("fs");

const path = "./database/Ramadhan/GroupNotification.json";

let handler = async (m) => {
    if (!fs.existsSync(path)) return m.reply("📌 Tidak ada notifikasi imsakiyah yang terdaftar.");

    let notifications = JSON.parse(fs.readFileSync(path));

   
    let index = notifications.findIndex(notif => notif.chatId === m.chat);

    if (index === -1) {
        return m.reply("⚠ Grup ini tidak memiliki notifikasi imsakiyah yang aktif.");
    }

   
    notifications.splice(index, 1);
    fs.writeFileSync(path, JSON.stringify(notifications, null, 2));

    m.reply("✅ Notifikasi imsakiyah untuk grup ini telah dihapus.");
};

handler.help = ["delnotifimsakiyah"];
handler.tags = ["search"];
handler.command = ["delnotifimsakiyah"];

module.exports = handler;