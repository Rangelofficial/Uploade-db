// getppgc.js

let handler = async (m, { conn, onlyToko, setReply }) => {
    try {
        let ppimg = await conn.profilePictureUrl(m.chat);
        if (!ppimg) {
            ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg';
        }
        await conn.sendMessage(m.chat, { image: { url: ppimg }, caption: "Ini adalah foto profil grup." });
    } catch (err) {
        console.log(err);
        setReply("Terjadi kesalahan saat mengambil foto profil grup.");
    }
};

handler.help = ["getppgc"];
handler.tags = ["group"];
handler.grooup = true
handler.command = ["getppgc"];

module.exports = handler;
