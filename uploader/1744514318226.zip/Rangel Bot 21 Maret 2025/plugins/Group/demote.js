let handler = async (m, { q, conn, isOwner,onlyAdmin,onlyBadmin,onlyToko, command, setReply }) => {
    if (!m.users) return setReply("reply/tag targetnya");
    if (!m.isAdmin && !isOwner) return mess.only.admin()
    if (!m.isGroup) return mess.only.group()
    if (!m.isBotAdmin) return mess.only.badmin()
    await conn
      .groupParticipantsUpdate(m.chat, [m.users], "demote")
      .then((res) => setReply(`Sukses Demote ${m.users}`))
      .catch((err) => setReply(jsonformat(err)));
  };
  
  handler.tags = ["admin"];
  handler.command = ["unadmin","demote"];
  handler.noCmdPrivate = true;
 
  module.exports = handler;