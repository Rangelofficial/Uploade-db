const axios = require("axios");
const fs = require("fs");
const path = "./database/Ramadhan/GroupNotification.json";

if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify([])); // Buat file jika belum ada

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`📌 *Cara Penggunaan:* 
🔹 *${usedPrefix + command} provinsi* → Melihat daftar provinsi yang tersedia
🔹 *${usedPrefix + command} <nama provinsi>* → Melihat daftar kabupaten/kota dalam provinsi
🔹 *${usedPrefix + command} <nama provinsi> | <kabupaten/kota>* → Mengaktifkan notifikasi Imsakiyah

📝 *Contoh:* 
✔ ${usedPrefix + command} Jawa Barat | Kota Tasikmalaya`);
    }

    let args = text.split("|").map(a => a.trim());

    if (args.length === 1 && args[0].toLowerCase() === "provinsi") {
        try {
            let response = await axios.get("https://equran.id/api/v2/imsakiyah/provinsi");
            let data = response.data.data;

            let pesan = "📌 *Daftar Provinsi yang Tersedia:* 📌\n\n";
            pesan += data.map((prov, i) => `${i + 1}. ${prov}`).join("\n");

            return m.reply(`${pesan}\n\nContoh Penggunaan : ${usedPrefix + command} Jawa Barat`);
        } catch (error) {
            console.error(error);
            return m.reply("❌ Terjadi kesalahan saat mengambil daftar provinsi.");
        }
    }

    if (args.length === 1) {
        let provinsi = args[0];
        try {
            let response = await axios.post("https://equran.id/api/v2/imsakiyah/kabkota", { provinsi });
            let data = response.data.data;

            if (!data || data.length === 0) {
                return m.reply("⚠ Provinsi tidak ditemukan atau tidak tersedia.");
            }

            let pesan = `📍 *Daftar Kabupaten/Kota di ${provinsi}:* 📍\n\n`;
            pesan += data.map((kab, i) => `${i + 1}. ${kab}`).join("\n");

            return m.reply(`${pesan}\n\nContoh Penggunaan : ${usedPrefix + command} Jawa Barat | Kota Tasikmalaya`);
        } catch (error) {
            console.error(error);
            return m.reply("❌ Terjadi kesalahan saat mengambil daftar kabupaten/kota.");
        }
    }

    if (args.length === 2) {
        let [provinsi, kabkota] = args;
        let notifications = JSON.parse(fs.readFileSync(path));
        let namaGc = m.groupName
        // Cek apakah notifikasi sudah ada untuk pengguna ini
        let existing = notifications.find(n => n.chatId === m.chat);

        if (existing) {
            existing.provinsi = provinsi;
            existing.kabkota = kabkota;
        } else {
            notifications.push({ chatId: m.chat, provinsi, kabkota, namaGc });
        }

        fs.writeFileSync(path, JSON.stringify(notifications, null, 2));

        return m.reply(`✅ Notifikasi Imsakiyah telah diaktifkan untuk *${kabkota}, ${provinsi}*.\nBot akan mengirimkan jadwal setiap hari.`);
    }
};

handler.help = ["notifimsakiyah"];
handler.tags = ["search"];
handler.command = ["addnotifimsakiyah"];
handler.noCmdStore = true;

module.exports = handler;