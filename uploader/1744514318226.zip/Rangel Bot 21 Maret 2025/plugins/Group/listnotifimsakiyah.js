const fs = require("fs");

const path = "./database/Ramadhan/GroupNotification.json";

let handler = async (m) => {
    if (!fs.existsSync(path)) return m.reply("📌 Tidak ada notifikasi imsakiyah yang terdaftar.");

    let notifications = JSON.parse(fs.readFileSync(path));

    if (notifications.length === 0) {
        return m.reply("📌 Tidak ada grup yang mengaktifkan notifikasi imsakiyah.");
    }

    let message = "📢 *Daftar Notifikasi Imsakiyah yang Aktif*\n\n";
    notifications.forEach((notif, i) => {
        message += `📍 *Grup ${i + 1}*\n`;
        message += `🔹 *Chat ID:* ${notif.chatId}\n`;
        message += `🔹 *Group Name:* ${notif.namaGc}\n`;
        message += `📌 *Provinsi:* ${notif.provinsi}\n`;
        message += `🏙 *Kabupaten/Kota:* ${notif.kabkota}\n\n`;
    });

    m.reply(message);
};

handler.help = ["listnotifimsakiyah"];
handler.tags = ["search"];
handler.command = ["listnotifimsakiyah"];

module.exports = handler;