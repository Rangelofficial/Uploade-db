// setnamegc.js

let handler = async (m, { q,conn,setReply, command,onlyToko,onlyAdmin,onlyBadmin }) => {
   if (!m.isGroup) return mess.only.group()
   if (!m.isAdmin) return mess.only.admin()
if (!m.isBotAdmin) return mess.only.badmin()
    
    if (!q) return setReply(`Kirim perintah ${command} <teks>`);
    
    try {
        // Mengubah nama grup
        await conn.groupUpdateSubject(m.chat, q);
        setReply("Nama grup berhasil diubah.");
    } catch (err) {
        console.log(err);
        setReply("Terjadi kesalahan saat mengubah nama grup.");
    }
};

handler.help = ["setnamegc"];
handler.tags = ["group"];
handler.command = ["setnamegc"];

module.exports = handler;
