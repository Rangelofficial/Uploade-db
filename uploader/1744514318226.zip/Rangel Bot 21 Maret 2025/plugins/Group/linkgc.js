let handler = async (m, { q, conn,onlyToko,onlyBadmin, isOwner, setReply }) => {
  if (!m.isGroup) return mess.only.group()
  if (!m.isBotAdmin) return mess.only.badmin()
  let Url = await conn
    .groupInviteCode(m.chat)
    .catch(() => seReply(mess.error.api));
  let asu = "https://chat.whatsapp.com/" + Url;
  m.reply(asu);
};
handler.help = ["linkgc"];
handler.tags = ["admin"];
handler.command = ["linkgc"];
handler.noCmdPrivate = true;
module.exports = handler;