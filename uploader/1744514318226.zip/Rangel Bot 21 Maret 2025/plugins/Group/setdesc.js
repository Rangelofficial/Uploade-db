// setdesc.js

let handler = async (m, { q,conn,setReply, command,onlyToko,onlyAdmin,onlyBadmin }) => {
  if (!m.isGroup) return mess.only.group()

  if (!m.isAdmin) return mess.only.admin()
if (!m.isBotAdmin) return mess.only.badmin()

    if (!q) return setReply(`Kirim perintah ${command} <teks>`);
    
    try {
   
        await conn.groupUpdateDescription(m.chat, q);
        setReply("Deskripsi grup berhasil diubah.");
    } catch (err) {
        console.log(err);
        setReply("Terjadi kesalahan saat mengubah deskripsi grup.");
    }
};

handler.help = ["setdesc"];
handler.tags = ["group"];
handler.command = ["setdesc"];
handler.noCmdPrivate = true;
module.exports = handler;
 