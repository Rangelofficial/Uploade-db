// delppgc.js

let handler = async (m, { conn,setReply, command,onlyToko,onlyAdmin,onlyBadmin }) => {
  
    if (!m.isAdmin) return mess.admin()
    if (!m.isBotAdmin) return mess.only.badmin()

    try {
        // Menghapus foto profil grup
        await conn.removeProfilePicture(m.chat);
        setReply("Foto profil grup berhasil dihapus!");
    } catch (err) {
        console.error(err);
        setReply("Terjadi kesalahan saat menghapus foto profil grup.");
    }
};

handler.help = ["delppgc"];
handler.tags = ["group"];
handler.command = ["delppgc"];
handler.noCmdPrivate = true;
module.exports = handler;
