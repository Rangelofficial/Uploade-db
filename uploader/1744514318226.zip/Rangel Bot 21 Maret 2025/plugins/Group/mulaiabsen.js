let handler = async (m, { conn, usedPrefix, text }) => {
   
    conn.absen = conn.absen ? conn.absen : {};
    let id = m.chat;

    if (id in conn.absen) {
        await conn.reply(m.chat, `❗ *Masih ada absen berlangsung di grup ini!*\n\n*${usedPrefix}hapusabsen* - untuk menghapus absen`, m);
        return; 
    }
   
    conn.absen[id] = [
        await conn.reply(m.chat, `✅ *Berhasil memulai absen!*\n\n*${usedPrefix}absen* - untuk melakukan absen\n*${usedPrefix}cekabsen* - untuk mengecek daftar hadir\n*${usedPrefix}hapusabsen* - untuk menghapus data absen\n\n*Deskripsi:* ${text}`, m),
        [],
        text
    ];
}

handler.help = ['mulaiabsen [teks]'];
handler.tags = ['absen'];
handler.command = /^(start|mulai)absen$/i;
handler.noCmdPrivate = true; 
handler.admin = true; 

module.exports = handler;
