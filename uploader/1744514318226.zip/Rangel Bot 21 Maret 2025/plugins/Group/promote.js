let handler = async (m, { q, conn,onlyAdmin,onlyBadmin, isOwner,onlyToko, command, setReply }) => {
  if (!m.users) return setReply("reply/tag targetnya");
  if (!m.isAdmin && !isOwner) return mess.only.admin()
  if (!m.isGroup) return mess.only.group()
  if (!m.isBotAdmin) return mess.only.badmin()
  await conn.groupParticipantsUpdate(m.chat, [m.users], "promote")
    .then((res) => setReply(`Sukses Promote ${m.users}`))
    .catch((err) => setReply(jsonformat(err)));
};

handler.tags = ["admin"];
handler.command = ["promote"];
handler.noCmdPrivate = true;

module.exports = handler;
