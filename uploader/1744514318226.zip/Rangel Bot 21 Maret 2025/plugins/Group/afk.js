let handler = async (m, { q, setReply, conn, pushname, fkontak }) => {
    if (!m.isGroup) return setReply("Perintah ini hanya bisa digunakan di grup.");
    if (m.key.fromMe) return;
    if (!q) return setReply("Alasan afk apa?");

    let user = global.db.data.users[m.sender];
    user.afk = +new Date();
    user.afkReason = q;
    let afkMessage = `🚨 *${m.pushname} sekarang dalam mode AFK!* 🚨\n` +
                     `🔹 *Alasan*: ${q || 'Tidak ada alasan khusus.'}\n` +
                     `⏳ *Kamu akan dianggap AFK hingga kembali aktif.*`;
    await conn.sendMessage(m.chat, { text: afkMessage },{quoted:m});
};

handler.help = ["afk"];
handler.tags = ["group"];
handler.command = ["afk"];  

module.exports = handler;

