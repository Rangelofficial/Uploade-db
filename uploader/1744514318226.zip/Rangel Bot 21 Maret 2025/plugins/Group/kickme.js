let handler = async (m, { q, conn,onlyToko,onlyBadmin, isOwner, setReply }) => {
  try {
    if (!m.isGroup) return mess.only.group()
    if (!m.isBotAdmin) return mess.only.badmin()
    await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
    await setReply("Done wkwkw");
  } catch (err) {
    setReply(`${err}`);
  }
};
handler.help = ["kickme"];
handler.tags = ["admin"];
handler.command = ["kickme"];
handler.noCmdPrivate = true;
module.exports = handler;