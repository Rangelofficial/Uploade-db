// tagme.js

let handler = async (m, { isGroup,conn, from, onlyToko }) => {
    if (!m.isGroup) return mess.only.group();
    
    let menst = [m.sender];
    await conn.sendMessage(from, { 
        text: `@${m.senderNumber}`, 
        mentions: menst 
    }, { quoted: m });
};

handler.help = ["tagme"];
handler.tags = ["group"];
handler.command = ["tagme"];

module.exports = handler;
