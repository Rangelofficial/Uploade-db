
let handler = async (m, { conn, prefix }) => {
    let id = m.chat;
    conn.absen = conn.absen ? conn.absen : {};
   
    if (!(id in conn.absen)) {
        await conn.reply(m.chat, `_*Tidak ada absen berlangsung di grup ini!*_\n\n*${prefix}mulaiabsen* - untuk memulai absen`, m);
        return; 
    }

    let d = new Date();
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });

    let absen = conn.absen[id][1];
    let list = absen.map((v, i) => `nih ${i + 1}.  @${v.split`@`[0]}`).join('\n'); 

    let caption = `* TANGGAL *\n${date}\n${conn.absen[id][2]}\n\n* SUDAH ABSEN *\n*Total:* ${absen.length}\n\n${list}`; 
    
    await conn.reply(m.chat, caption, m, { mentions: conn.parseMention(caption) });
}

handler.help = ['cekabsen'];
handler.tags = ['absen'];
handler.command = /^cekabsen$/i;
handler.noCmdPrivate = true;
module.exports = handler;
