const moment = require("moment-timezone");
const { getBuffer } = require("../../lib/myfunc");

let handler = async (m, { q, conn, from, isOwner, command, setReply }) => {
  if (!m.isGroup) return setReply("❌ Fitur ini hanya bisa digunakan dalam grup.");

  let _meta = await conn.groupMetadata(m.chat);
  let _img = await conn.profilePictureUrl(_meta.id, "image").catch(() => 'https://via.placeholder.com/200');

  // Data Keamanan Grup
  const chatData = db.data.chats[m.chat] || {};
  
  let caption = `📌 *Informasi Grup*  
━━━━━━━━━━━━━━━━━━  
📛 *Nama:* ${_meta.subject}  
📆 *Dibuat pada:* ${moment(_meta.creation * 1000).format("LL")}  
👤 *Pemilik Grup:* ${_meta.subjectOwner || "Tidak Diketahui"}  

👥 *Total Anggota:* ${_meta.participants.length}  
🔰 *Admin:* ${_meta.participants.filter(x => x.admin === "admin").length}  
👤 *Member:* ${_meta.participants.filter(x => x.admin === null).length}  

━━━━━━━━━━━━━━━━━━  
🔒 *Sistem Keamanan*  
- 🚫 Anti Link GC: *${chatData.antilinkgc ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔗 Anti Link: *${chatData.antilink ? 'Aktif ✅' : 'Mati ❌'}*  
- 🛑 Anti Virtex: *${chatData.antivirtex ? 'Aktif ✅' : 'Mati ❌'}*  
- 🌍 Anti Asing: *${chatData.antiasing ? 'Aktif ✅' : 'Mati ❌'}*  
- 🗑️ Anti Delete: *${chatData.antidelete ? 'Aktif ✅' : 'Mati ❌'}*  
- 🖼️ Anti Gambar: *${chatData.antiimage ? 'Aktif ✅' : 'Mati ❌'}*  
- 🎭 Anti Stiker: *${chatData.antisticker ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔊 Anti Audio: *${chatData.antiaudio ? 'Aktif ✅' : 'Mati ❌'}*  
- 🎥 Anti Video: *${chatData.antivideo ? 'Aktif ✅' : 'Mati ❌'}*  
- 📢 Anti Promosi: *${chatData.antipromosi ? 'Aktif ✅' : 'Mati ❌'}*  
- ⚠️ Anti Spam: *${chatData.antispam ? 'Aktif ✅' : 'Mati ❌'}*  
- 🗯️ Anti Toxic: *${chatData.badword ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔗 Anti Wame: *${chatData.antiwame ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔒 Ban Chat: *${chatData.banchat ? 'Aktif ✅' : 'Mati ❌'}*  
- 🎉 Welcome Message: *${chatData.welcome ? 'Aktif ✅' : 'Mati ❌'}*  
- 👀 Anti View Once: *${chatData.antiviewonce ? 'Aktif ✅' : 'Mati ❌'}*  
- 🤖 Anti Bot: *${chatData.antibot ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔕 Anti Hide Tag: *${chatData.antihidetag ? 'Aktif ✅' : 'Mati ❌'}*  
- 🔞 Anti Porn & NSFW: *${chatData.antiPorn || chatData.nsfw ? 'Aktif ✅' : 'Mati ❌'}*  

━━━━━━━━━━━━━━━━━━  
🏆 *Fitur Tambahan*  
- 🎮 Mode Game: *${chatData.game ? 'Aktif ✅' : 'Mati ❌'}*  
- 🏹 Mode RPG: *${chatData.rpg ? 'Aktif ✅' : 'Mati ❌'}*  
- 📈 Auto Level Up: *${chatData.autolevelup ? 'Aktif ✅' : 'Mati ❌'}*  

━━━━━━━━━━━━━━━━━━  
💎 *Status VIP*  
- ⭐ VIP: *${chatData.vip ? 'Ya ✅' : 'Tidak ❌'}*  
- 📅 Masa Berlaku VIP: *${chatData.vipExpired ? moment(chatData.vipExpired).format("LL") : 'Tidak Ada'}*  
- ⏳ Masa Berlaku Grup: *${chatData.expired ? moment(chatData.expired).format("LL") : 'Tidak Ada'}*  

━━━━━━━━━━━━━━━━━━  
📌 *ID Grup:* ${_meta.id}  
🚀 *Bot Powered by:* Ʀαиgєℓ Bσƚ ヅ`;

  await conn.sendMessage(
    m.chat,
    {
      caption,
      image: await getBuffer(_img),
    },
    { quoted: m }
  );
};

handler.tags = ["admin"];
handler.command = ["infogc"];
handler.noCmdPrivate = true;
module.exports = handler;