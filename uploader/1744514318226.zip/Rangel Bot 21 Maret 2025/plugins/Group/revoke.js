let handler = async (m, { q, conn, isOwner,onlyToko,onlyAdmin,onlyBadmin, command, setReply }) => {
  if (!m.isGroup) return mess.only.group()
  if (!m.isAdmin) return mess.only.admin()
  if (!m.isBotAdmin) return mess.only.badmin()
  await conn
    .groupRevokeInvite(m.chat)
    .then((res) => {
      setReply(`Sukses menyetel tautan undangan grup ini`);
    })
    .catch(() => m.reply(mess.error.api));
};

handler.tags = ["admin"];
handler.command = ["revoke"];
handler.group = true;
handler.admin = true;
module.exports = handler;