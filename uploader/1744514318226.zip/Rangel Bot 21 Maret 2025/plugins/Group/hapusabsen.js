let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat;
    conn.absen = conn.absen ? conn.absen : {};   
    if (!(id in conn.absen)) {
        await conn.reply(m.chat, `_*Tidak ada absen berlangsung di grup ini!*_\n\n*${usedPrefix}mulaiabsen* - untuk memulai absen`, m);
        return; 
    }

    delete conn.absen[id];   
    await conn.reply(m.chat, `✅ *Berhasil!* Absen di grup ini telah dihapus.`, m);
}

handler.help = ['hapusabsen'];
handler.tags = ['absen'];
handler.command = /^(delete|hapus)absen$/i;
handler.noCmdPrivate = true;
handler.admin = true; 

module.exports = handler;

