// setppgc.js

const fs = require('fs');

let handler = async (m, { conn,setReply, command,onlyToko,onlyAdmin,onlyBadmin }) => {
   if (!m.isGroup) return mess.only.group()
   if (!m.isAdmin) return mess.only.admin()
if (!m.isBotAdmin) return mess.only.badmin()
const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage'; 
    const isImage = m.mtype === 'imageMessage'; 
    const quoted = m.quoted ? m.quoted : m;

    if (isImage || isQuotedImage) {
        try {
            let media = await conn.downloadAndSaveMediaMessage(quoted, 'ppgc_' + Date.now());
            
            await conn.profilePictureUrl(m.chat, { url: media });
            setReply("Sukses mengubah foto profil grup!");

            fs.unlinkSync(media);
        } catch (err) {
            console.error(err);
            setReply("Terjadi kesalahan saat mengubah foto profil grup.");
        }
    } else {
        setReply(`Kirim atau balas gambar dengan caption .${command} untuk mengubah foto profil grup.`);
    }
};

handler.help = ["setppgc"];
handler.tags = ["group"];
handler.command = ["setppgc"];

module.exports = handler;
