const fs = require('fs');
const moment = require("moment-timezone");
const timeWib = moment().tz('Asia/Jakarta').format('HH:mm:ss')




let handler = async (m, { conn, text, args, setReply }) => {
   
    let targetNumber;

   let ucapanWaktu;
if (timeWib < "06:00:00") {
    ucapanWaktu = '🌅 Selamat pagi!';
} else if (timeWib < "11:00:00") {
    ucapanWaktu = '☀️ Selamat pagi!';
} else if (timeWib < "15:00:00") {
    ucapanWaktu = '🌞 Selamat siang!';
} else if (timeWib < "18:00:00") {
    ucapanWaktu = '🌇 Selamat sore!';
} else if (timeWib < "19:00:00") {
    ucapanWaktu = '🌙 Selamat malam!';
} else {
    ucapanWaktu = '🌌 Selamat malam!';
}
    if (args[0]) {
        targetNumber = args[0].replace(/[^0-9]/g, "");  
    } else if (m.quoted) {
        const quotedMessageSender = m.quoted.sender; 
        targetNumber = quotedMessageSender.split("@")[0];  
    } else {
        return setReply("Masukkan nomor target (contoh: 62xx) atau reply pesan dari target.");
    }
    let cek1 = await conn.onWhatsApp(targetNumber + "@s.whatsapp.net");
    if (cek1.length === 0) return setReply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!!!`);

    const userResPanel = JSON.parse(fs.readFileSync("./database/store/reselerpanel.json"));  
const isResPanel = userResPanel.includes(m.sender.replace('@s.whatsapp.net', ''));
    if (userResPanel.includes(targetNumber)) {
        return setReply(`Nomor ${targetNumber} sudah terdaftar sebagai Reseller Panel!`);
    }
    userResPanel.push(targetNumber);
    fs.writeFileSync("./database/store/reselerpanel.json", JSON.stringify(userResPanel)); 

    setReply(`Sukses! Sekarang ${targetNumber} adalah Reseller Panel!`);

    await conn.sendMessage(targetNumber + "@s.whatsapp.net", {
        image: {
            url: `https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1735950753706.jpg`
        },
        caption: `Hallo ${ucapanWaktu} ${targetNumber}!\n\nSelamat! Kamu sekarang adalah Reseller Panel. \n\nJangan ragu untuk menghubungi kami jika ada pertanyaan atau bantuan yang dibutuhkan.`
    }, {
        quoted: m
    });
};

handler.help = ['addreselerpanel'];
handler.tags = ['admin'];
handler.command = /^(addreselerpanel)$/i;
handler.owner = true;  

module.exports = handler;

