const fetch = require('node-fetch'); // Import module fetch

const handler = async (m, { args, command, reply, isPremium, usedPrefix }) => {
    try {
        // Jika command adalah 'action', tampilkan daftar perintah
        if (command === 'action') {
            let commandsList = handler.command
                .filter((cmd) => cmd !== 'action') 
                .map((cmd) => `${usedPrefix}${cmd}`) 
                .join('\n'); 

            return reply(`*🔹 Daftar Action yang Tersedia:*\n\n${commandsList}`);
        }

        // Menentukan action berdasarkan command yang digunakan
        let action;
        if (command === 'startsrv') action = 'start';
        else if (command === 'stopsrv') action = 'stop';
        else if (command === 'restartsrv') action = 'restart';
        else return reply('*❌ Command tidak dikenali!*');

        if (!isPremium) return reply('*❌ Fitur ini hanya untuk pengguna premium!*');

        let srv = args[0];
        if (!srv) return reply('*❌ ID server tidak ditemukan!*\nSilakan masukkan ID server yang ingin dikontrol.');

        // Request ke API untuk mengubah status server
        let response = await fetch(`${domain}/api/client/servers/${srv}/power`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiPlta}`
            },
            body: JSON.stringify({ signal: action })
        });

        // Jika request gagal, ambil pesan error
        if (!response.ok) {
            let res = await response.text(); // Menggunakan text() untuk debugging
            return reply(`❌ ERROR:\n${res}`);
        }

        // Sukses mengubah status server
        reply(`✅ *BERHASIL ${action.toUpperCase()} SERVER!*`);
    } catch (error) {
        console.error(error);
        reply('*❌ Terjadi kesalahan saat memproses permintaan.*');
    }
};

handler.command = ['startsrv', 'stopsrv', 'restartsrv', 'action'];
handler.selerpanel = true;
handler.cmdStore = true;
handler.description = ["Mengontrol status server (start, stop, restart) berdasarkan ID."];

module.exports = handler;