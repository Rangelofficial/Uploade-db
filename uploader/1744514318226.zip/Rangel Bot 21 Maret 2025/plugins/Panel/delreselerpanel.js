const fs = require('fs');

let handler = async (m, { conn, text, args,  setReply }) => {
    
    let targetNumber;
    if (args[0]) {
        targetNumber = args[0].replace(/[^0-9]/g, "");  
    } else if (m.quoted) {
        const quotedMessageSender = m.quoted.sender;  
        targetNumber = quotedMessageSender.split("@")[0];  
    } else {
   
        return setReply("Masukkan nomor target (contoh: 62xx) atau reply pesan dari target yang ingin dihapus.");
    }
    let userResPanel = JSON.parse(fs.readFileSync("./database/store/reselerpanel.json"));
    const unp = userResPanel.indexOf(targetNumber);
    if (unp === -1) return setReply(`Nomor ${targetNumber} tidak ditemukan dalam daftar reseller.`);
    userResPanel.splice(unp, 1);
    fs.writeFileSync("./database/reselerpanel.json", JSON.stringify(userResPanel)); 
    setReply(`✅ Sukses! Nomor ${targetNumber} berhasil dihapus dari Reseller Panel.`);
};

handler.help = ['delreselerpanel'];
handler.tags = ['admin'];
handler.command = /^(delreselerpanel)$/i;
handler.owner = true;  

module.exports = handler;
