

const fs = require('fs');

let handler = async (m, { text, setReply }) => {
    const path = './database/store/datapanel.json';
    if (!text || isNaN(text)) {
        return setReply("❌ *Format salah!*\nPenggunaan:\n.delbuyerpanel [Nomor Urutan]");
    }
    let dataBuyPanel;
    try {
        dataBuyPanel = JSON.parse(fs.readFileSync(path, 'utf-8'));
    } catch (error) {
        return setReply("❌ *Terjadi kesalahan saat membaca file data panel.*\nPastikan file JSON ada dan formatnya benar.");
    }
    const index = parseInt(text) - 1; 
    if (index < 0 || index >= dataBuyPanel.length) {
        return setReply(`⚠️ *Nomor urutan tidak valid!*\nTotal pembeli saat ini: ${dataBuyPanel.length}`);
    }   
    const removedBuyer = dataBuyPanel.splice(index, 1);

    try {
       
        fs.writeFileSync(path, JSON.stringify(dataBuyPanel, null, 2));
    } catch (error) {
        return setReply("❌ *Terjadi kesalahan saat menyimpan perubahan data panel.*");
    }

    return setReply(`✅ *Pembeli berhasil dihapus!*\n\n🔢 *Nomor Urutan:* ${text}\n👤 *Nama:* ${removedBuyer[0].buyer_name}\n📞 *Nomor:* ${removedBuyer[0].number}\n🔑 *ID:* ${removedBuyer[0].ID}`);
};

handler.help = ["delbuyerpanel [Nomor Urutan]"];
handler.tags = ["panel"];
handler.command = /^(delbuyerpanel)$/i;
handler.owner = true;

module.exports = handler;