const fs = require('fs');
const moment = require('moment'); 

let handler = async (m, { setReply, text, conn }) => {
    const path = './database/store/datapanel.json';    
    let dataBuyPanel;
    
    try {
        dataBuyPanel = JSON.parse(fs.readFileSync(path, 'utf-8'));
    } catch (error) {
        return setReply("❌ *Terjadi kesalahan saat membaca file data panel.*\nPastikan file JSON ada dan formatnya benar.");
    }

    let idToExtend = text.trim();  
    if (!idToExtend) {
        return setReply("❌ *ID yang ingin diperpanjang belum dimasukkan.*");
    } 

    let buyerIndex = dataBuyPanel.findIndex(buyer => buyer.ID === idToExtend);
    if (buyerIndex === -1) {
        return setReply(`📂 *ID ${idToExtend} tidak ditemukan dalam daftar pembeli.*`);
    }

    let buyer = dataBuyPanel[buyerIndex];
    
    let newExpiredDate = moment(buyer.expired, 'DD/MM/YYYY').add(30, 'days').format('DD/MM/YYYY');

    buyer.expired = newExpiredDate;
    buyer.data.notification = false; 

    try {
  
        fs.writeFileSync(path, JSON.stringify(dataBuyPanel, null, 2), 'utf-8');
 
        const message = `📝 *Pembaruan Masa Aktif Panel Anda*:\n\n` +
                        `✅ *Nama Pembeli:* ${buyer.buyer_name}\n` +
                        `📞 *Nomor Pembeli:* ${buyer.number}\n` +
                        `📅 *Tanggal Pembelian:* ${buyer.date}\n` +
                        `⏳ *Masa Berlaku Hingga:* ${buyer.expired}\n\n` +
                        `🔑 *Akun Rangelofficial:*\n` +
                        `👤 *Username:* ${buyer.data.nama}\n` +
                        `🔐 *Password:* ${buyer.data.password}\n` +
                        `🌐 *Login Panel:* ${buyer.data.loginpanel}\n\n` +
                        `📢 *Catatan Penting:*\nMasa aktif Anda telah diperpanjang selama 30 hari.\n\nTerima kasih telah menggunakan layanan kami!`;
        await conn.sendMessage(`${buyer.number}@s.whatsapp.net`, { text: message });

        setReply(`✅ *Berhasil memperpanjang panel dengan ID ${idToExtend} hingga ${newExpiredDate}.*\n📩 *Notifikasi telah dikirim ke ${buyer.number}.*`);
    } catch (error) {
        setReply("❌ *Terjadi kesalahan saat menyimpan data pembeli atau mengirim pesan.*");
    }
};

handler.help = ["perpanjangpanel <id>"];
handler.tags = ["panel"];
handler.command = /^(perpanjangpanel)$/i;
handler.owner = true;
handler.description = ["Memperpanjang masa berlaku panel pembeli dengan ID tertentu selama 30 hari"];

module.exports = handler;