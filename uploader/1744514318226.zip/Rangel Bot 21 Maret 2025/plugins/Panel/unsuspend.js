const fetch = require('node-fetch'); 

const handler = async (m, { args, reply }) => {
    try {
 
        let srv = args[0];
        if (!srv) return reply('*❌ ID server tidak ditemukan!*\nSilakan masukkan ID server yang ingin di-unsuspend.\nAtau Cek Dengan Ketik *.listsrv* Untuk Melihat ID server');

        let response = await fetch(`${domain}/api/application/servers/${srv}/unsuspend`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiPlta}`
            }
        });
        
        if (!response.ok) {
            let res = await response.json();
            return reply(res.errors ? '*⚠️ SERVER NOT FOUND!*' : '*❌ Gagal membuka suspend server.*');
        }
        
        reply('*✅ SERVER BERHASIL DI-UNSUSPEND!*');
    } catch (error) {
        console.error(error);
        reply('*❌ Terjadi kesalahan saat memproses permintaan.*');
    }
};

handler.command = ['unsuspend'];
handler.selerpanel = true;
handler.cmdStore = true;
handler.description = ["Membuka suspend server berdasarkan ID "];

module.exports = handler;