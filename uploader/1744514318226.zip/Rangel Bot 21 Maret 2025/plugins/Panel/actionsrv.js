const fetch = require('node-fetch'); 

const handler = async (m, { args, command, reply, isPremium, usedPrefix }) => {
    try {
 
        if (command === 'actionsrv') {
            let commandsList = handler.command
                .filter((cmd) => cmd !== 'actionsrv') 
                .map((cmd) => `${usedPrefix}${cmd}`) 
                .join('\n'); 

            return reply(`*🔹 Daftar Action Server yang Tersedia:*\n\n${commandsList}`);
        }

        let action = command.replace('srv', '').toLowerCase(); 

        if (!isPremium) return reply('*❌ Fitur ini hanya untuk pengguna premium!*');

        let srv = args[0];
        if (!srv) return reply('*❌ ID server tidak ditemukan!*\nSilakan masukkan ID server yang ingin dikontrol.');

        let response = await fetch(`${domain}/api/client/servers/${srv}/power`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiPlta}`
            },
            body: JSON.stringify({ signal: action })
        });

        if (!response.ok) {
            let res = await response.json();
            return reply(res.errors ? `❌ *ERROR:* ${JSON.stringify(res.errors[0], null, 2)}` : '*❌ Gagal mengubah status server.*');
        }

        reply(`✅ *BERHASIL ${action.toUpperCase()} SERVER!*`);
    } catch (error) {
        console.error(error);
        reply('*❌ Terjadi kesalahan saat memproses permintaan.*');
    }
};

handler.command = ['startsrv', 'stopsrv', 'restartsrv', 'actionsrv'];
handler.selerpanel = true;
handler.cmdStore = true;
handler.description = ["Mengontrol status server (start, stop, restart) berdasarkan ID."];

module.exports = handler;