const fs = require('fs');

let handler = async (m, { setReply, text }) => {
    const path = './database/store/datapanel.json';    
    let dataBuyPanel;
    try {
        dataBuyPanel = JSON.parse(fs.readFileSync(path, 'utf-8'));
    } catch (error) {
        return setReply("❌ *Terjadi kesalahan saat membaca file data panel.*\nPastikan file JSON ada dan formatnya benar.");
    }  

    let numberToCheck = text.trim();  
    if (!numberToCheck) {
        return setReply("❌ *Nomor yang ingin dicek belum dimasukkan.*");
    }

    let buyers = dataBuyPanel.filter(buyer => buyer.number === numberToCheck);
    
    if (buyers.length === 0) {
        return setReply(`📂 *Nomor ${numberToCheck} tidak ditemukan dalam daftar pembeli.*`);
    }

    let buyerInfo = `🛒 *DAFTAR DETAIL PEMBELI PANEL*\n\n`;
    
    buyers.forEach((buyer, index) => {
        buyerInfo += `*Pembeli ${index + 1}:*\n`;
        buyerInfo += `👤 *Nama:* ${buyer.buyer_name}\n`;
        buyerInfo += `📞 *Nomor:* ${buyer.number}\n`;
        buyerInfo += `💳 *Pembayaran:* ${buyer.payment}\n`;
        buyerInfo += `💾 *RAM:* ${buyer.data.ram}\n`;
        buyerInfo += `💰 *Harga:* ${buyer.data.harga}\n`;
        buyerInfo += `📅 *Tanggal Beli:* ${buyer.date}\n`;
        buyerInfo += `⏳ *Berlaku Hingga:* ${buyer.expired}\n`;
        buyerInfo += `🔑 *ID:* ${buyer.ID}\n\n`;
    });

    setReply(buyerInfo);
};

handler.help = ["cekbuyerpanel <nomor>"];
handler.tags = ["panel"];
handler.command = /^(cekbuyerpanel)$/i;
handler.cmdStore = true;
handler.owner = true;
handler.description = ["Memeriksa data pembeli berdasarkan nomor"];

module.exports = handler;