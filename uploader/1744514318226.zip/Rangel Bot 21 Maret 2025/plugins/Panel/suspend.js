
const fetch = require('node-fetch');

const handler = async (m, { args, reply }) => {
    try {
     
        let srv = args[0];
        if (!srv) return reply('*❌ ID server tidak ditemukan!*\nSilakan masukkan ID server yang ingin di-suspend.\nAtau Cek Dengan Ketik *.listsrv* Untuk Melihat ID server');

      
        let response = await fetch(`${domain}/api/application/servers/${srv}/suspend`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiPlta}`
            }
        });

       
        if (!response.ok) {
            let res = await response.json();
            return reply(res.errors ? '*⚠️ SERVER NOT FOUND!*' : '*❌ Gagal suspend server.*');
        }

        reply('*✅ SERVER BERHASIL DI-SUSPEND!*');
    } catch (error) {
        console.error(error);
        reply('*❌ Terjadi kesalahan saat memproses permintaan.*');
    }
};

handler.command = ['suspend'];
handler.selerpanel = true;
handler.cmdStore = true;
handler.description = ["Suspend server berdasarkan ID dengan validasi input dan penanganan error."];

module.exports = handler;