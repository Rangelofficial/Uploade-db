const fetch = require('node-fetch');

const handler = async (m, { args, setReply,isResPanel }) => {
    
    let srv = args[0];
    
    if (!srv) return setReply('ID server mana yang ingin dihapus?');

    try {
        let f = await fetch(`${domain}/api/application/servers/${srv}`, {
            method: "DELETE",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apiPlta,
            }
        });
        let res = f.ok ? { errors: null } : await f.json();
        if (res.errors) {
            return setReply('*SERVER TIDAK DITEMUKAN*');
        }
        return setReply('*SERVER BERHASIL DIHAPUS*');
    } catch (error) {
        console.error(error);
        return setReply('Terjadi kesalahan saat mencoba menghapus server. Silakan coba lagi nanti.');
    }
};

handler.command = ['delserver','delsrv'];
handler.help = ['delserver <ID>'];
handler.tags = ['server'];
handler.selerpanel = true;

module.exports = handler;
