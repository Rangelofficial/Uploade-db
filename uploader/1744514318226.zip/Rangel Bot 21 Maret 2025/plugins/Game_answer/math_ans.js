let handler = m => m
async function before(m, {  conn }) {
   conn.math =  conn.math ?  conn.math : {}

  if ((id in  conn.math)) {
    let math = JSON.parse(JSON.stringify( conn.math[id][1]))
    if (parseInt(m.text) === math.result) {
      db.data.users[m.sender].exp += math.bonus
      clearTimeout( conn.math[id][3])
      delete  conn.math[id]
     m.reply(`✅ *Benar!*\n+${math.bonus} XP`)
    } else if (/^-?[0-9]+(\.[0-9]+)?$/.test(m.text)) m.reply('salah');    

  }
  
}
module.exports = handler