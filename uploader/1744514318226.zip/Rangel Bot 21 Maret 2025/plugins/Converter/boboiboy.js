const axios = require("axios");

let handler = async (m, { q, conn, args, usedPrefix, command }) => {
    try {
        if (!q) {
            return m.reply(`*Contoh:* ${usedPrefix + command} cihuyy`);
        }

        const apiKey = apiTermai
        const ttsUrl = `https://ai.xterm.codes/api/text2speech/elevenlabs?text=${encodeURIComponent(q)}&key=${apiKey}&voice=boboiboy`;

       
        const audioResponse = await axios.get(ttsUrl, { responseType: "arraybuffer" });

        if (!audioResponse || !audioResponse.data) {
            throw new Error("Gagal mengambil audio TTS");
        }

        
        await conn.sendMessage(
            m.chat,
            { 
                audio: Buffer.from(audioResponse.data), 
                mimetype: "audio/mpeg", 
                ptt: true 
            }, 
            { quoted: m }
        );

    } catch (error) {
        console.error("Terjadi kesalahan:", error);
        m.reply("Terjadi kesalahan saat memproses permintaan Anda. Limit pemakaian API mungkin sudah habis. Coba lagi nanti.");
    }
};

handler.help = ["boboiboy <teks>"];
handler.tags = ["internet", "ai", "tts"];
handler.command = ["boboiboy"];

module.exports = handler;