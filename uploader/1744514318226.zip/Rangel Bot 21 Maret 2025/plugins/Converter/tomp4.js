const fetch = require("node-fetch");
const uploadToCatbox = require('../../lib/uploadToCatbox');

const handler = async (m, { conn, sendReact }) => {
  const isQuotedSticker = m.quoted && m.quoted.mtype === "stickerMessage";
  const quoted = m.quoted ? m.quoted : m;

  if (!isQuotedSticker) {
    return m.reply("Reply pada stiker yang ingin dikonversi ke MP4.");
  }
mess.wait()
  try {
    let media = await quoted.download();
    let url = await uploadToCatbox(media);

    
    let apiUrl = `https://api.neoxr.eu/api/webp2mp4?url=${encodeURIComponent(url)}&apikey=${Neoxr}`;
    let response = await fetch(apiUrl);
    let result = await response.json();

    if (!result.status || !result.data || !result.data.url) {
      return m.reply("Gagal mengonversi stiker menjadi video MP4.");
    }

    
    await conn.sendMessage(
      m.chat,
      { video: { url: result.data.url }, caption: "Konversi WebP ke MP4 berhasil!" },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    sendReact("❌");
    m.reply(`Terjadi kesalahan: ${err.message}`);
  }
};

handler.help = ["tomp4"];
handler.command = ["tomp4","tovideo"];
handler.tags = ["convert"];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Ubah stiker jadi video"];

module.exports = handler;