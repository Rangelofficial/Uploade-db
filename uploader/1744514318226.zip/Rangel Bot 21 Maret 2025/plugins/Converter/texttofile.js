const fs = require('fs');
const { getRandom } = require('../../lib/myfunc');

const handler = async (m, { conn, args, setReply }) => {
    if (!args.length) {
        return setReply('Masukkan teks yang ingin diubah menjadi dokumen!\n\nContoh: .totext json {"nama": "Ehanz", "usia": 20}');
    }

    let format = args[0].toLowerCase(); // Format file (json, txt, js, dll)
    let supportedFormats = ['json', 'txt', 'js', 'html', 'css', 'xml', 'md'];

    if (!supportedFormats.includes(format)) {
        return setReply(`Format yang didukung: ${supportedFormats.join(', ')}`);
    }

    let textContent = args.slice(1).join(' ');
    if (!textContent) {
        return setReply('Teks tidak boleh kosong!');
    }

    try {
        setReply('Proses mengubah teks ke dokumen...');
        let fileName = getRandom(`.${format}`);
        fs.writeFileSync(fileName, textContent);

        await conn.sendMessage(m.chat, {
            document: { url: fileName },
            mimetype: 'text/plain',
            fileName: `converted.${format}`
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (e) {
        console.error(e);
        setReply('Terjadi kesalahan saat mengonversi teks ke dokumen!');
    }
};

handler.help = ['totext'];
handler.command = ['texttofile'];
handler.tags = ['convert'];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Ubah teks menjadi dokumen dalam format JSON, TXT, JS, dll"];

module.exports = handler;