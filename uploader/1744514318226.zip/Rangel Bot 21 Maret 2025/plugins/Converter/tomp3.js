const fs = require('fs');
const { exec } = require('child_process');
const { getRandomFile } = require('../../lib/myfunc'); 

const handler = async (m, { conn, setReply }) => {
    const isQuotedVideo = m.quoted && m.quoted.mtype === 'videoMessage';
    const isQuotedAudio = m.quoted && m.quoted.mtype === 'audioMessage';
    const isVideo = m.mtype === 'videoMessage';
    const isAudio = m.mtype === 'audioMessage';
    const isQuotedDocument = m.quoted && m.quoted.mtype === 'documentMessage' && m.quoted.mimetype.startsWith('audio/');
    const isDocument = m.mtype === 'documentMessage' && m.mimetype.startsWith('audio/');

    const quoted = m.quoted ? m.quoted : m;

    if (!(isQuotedVideo || isVideo || isQuotedAudio || isAudio || isQuotedDocument || isDocument)) {
        return setReply('Reply video atau dokumen audio untuk mengonversi!');
    }

    try {
        setReply('Proses mengonversi...');  
        let media = await conn.downloadAndSaveMediaMessage(quoted);   
        let ran = getRandomFile('.mp3');   

        // Jika file sudah audio, cukup ubah ke MP3 tanpa VN
        let command = isQuotedAudio || isAudio || isQuotedDocument || isDocument
            ? `ffmpeg -i ${media} -q:a 0 -map a ${ran}`
            : `ffmpeg -i ${media} -vn ${ran}`;

        exec(command, async (err) => {
            fs.unlinkSync(media);
            if (err) {
                return setReply(`Terjadi kesalahan: ${err.message}`);
            }   
            let buffer = fs.readFileSync(ran);    
            await conn.sendMessage(m.chat, { mimetype: 'audio/mp4', audio: buffer }, { quoted: m });     
            fs.unlinkSync(ran);
        });
    } catch (e) {
        console.error(e);
        setReply('Terjadi kesalahan saat memproses media!');
    }
};

handler.help = ['tomp3'];
handler.command = ['tomp3'];
handler.tags = ['convert'];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Ambil audio dari video atau konversi audio ke MP3"];

module.exports = handler;