//unyuk menepi cimmandnya di mwnu doang//

