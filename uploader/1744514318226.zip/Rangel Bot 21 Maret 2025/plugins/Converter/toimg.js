const fs = require('fs');
const { exec } = require('child_process');
const { getRandom } = require('../../lib/myfunc'); 

const handler = async (m, { conn, setReply }) => {
    const isQuotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage';
    const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
    const isQuotedDocument = m.quoted && m.quoted.mtype === 'documentMessage' && m.quoted.mimetype.startsWith('image/');
    
    const quoted = m.quoted ? m.quoted : m;

    if (!(isQuotedSticker || isQuotedImage || isQuotedDocument)) {
        return setReply('Reply sticker atau dokumen gambar!');
    }

    try {
        setReply('Proses mengubah ke gambar...');
        let media = await conn.downloadAndSaveMediaMessage(quoted);  
        let ran = getRandom('.png'); 

        // Jika dokumen sudah berupa gambar, cukup kirim ulang tanpa konversi
        if (isQuotedDocument || isQuotedImage) {
            let buffer = fs.readFileSync(media);
            await conn.sendMessage(m.chat, { image: buffer, caption: 'Berhasil mengubah ke gambar!' }, { quoted: m });
            fs.unlinkSync(media);
            return;
        }

        // Konversi sticker ke gambar
        exec(`ffmpeg -i ${media} ${ran}`, async (err) => {
            fs.unlinkSync(media);
            if (err) {
                return setReply(`Terjadi kesalahan: ${err.message}`);
            }
            let buffer = fs.readFileSync(ran);
            await conn.sendMessage(m.chat, { image: buffer, caption: 'Berhasil mengubah ke gambar!' }, { quoted: m });
            fs.unlinkSync(ran);
        });
    } catch (e) {
        console.error(e);
        setReply('Terjadi kesalahan saat mengonversi!');
    }
};

handler.help = ['toimg'];
handler.command = ['toimg'];
handler.tags = ['convert'];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Ubah sticker atau dokumen gambar menjadi gambar biasa"];

module.exports = handler;