const fs = require("fs-extra");
const path = require("path");

let handler = async (m, { conn, setReply }) => {
    const isQuotedDocument = m.quoted && m.quoted.mtype === 'documentMessage';

    try {
        setReply("Mengambil isi dokumen...");

        // Download dokumen sebagai buffer
        let mediaBuffer = await conn.downloadMediaMessage(m.quoted);
        if (!mediaBuffer) {
            return setReply("Gagal mengunduh dokumen! Coba lagi.");
        }

        // Dapatkan nama file dan ekstensi
        let fileName = m.quoted.message.documentMessage.fileName || "unknown.txt";
        let ext = path.extname(fileName).toLowerCase();

        // Format yang bisa dikonversi ke teks
        let textFormats = ["js", "json", "txt", "html", "css", "xml", "md", "csv"];
        let isTextFormat = textFormats.includes(ext.replace(".", ""));

        // Simpan buffer ke file sementara
        let tempFilePath = `./temp/${fileName}`;
        fs.ensureDirSync("./temp"); // Pastikan folder temp ada
        fs.writeFileSync(tempFilePath, mediaBuffer);

        // Baca isi file jika formatnya bisa dikonversi
        if (isTextFormat) {
            let fileContent = fs.readFileSync(tempFilePath, "utf-8");

            // Hapus file setelah diproses
            fs.unlinkSync(tempFilePath);

            // Batasi panjang teks
            if (fileContent.length > 4000) {
                return setReply("Teks terlalu panjang! Silakan buka dokumen secara manual.");
            }

            return setReply(`📄 *Isi Dokumen (${fileName}):*\n\n${fileContent}`);
        } else {
            // Jika bukan format teks, kirim sebagai dokumen kembali
            let mimetype =
                ext === ".js" ? "text/javascript" :
                ext === ".json" ? "application/json" :
                ext === ".html" ? "text/html" :
                "application/octet-stream";

            await conn.sendMessage(m.chat, {
                document: fs.readFileSync(tempFilePath),
                fileName,
                mimetype
            }, { quoted: m });

            // Hapus file setelah dikirim
            fs.unlinkSync(tempFilePath);
        }
    } catch (e) {
        console.error(e);
        setReply("Terjadi kesalahan saat membaca dokumen! Pastikan file yang dikirim adalah dokumen teks.");
    }
};

handler.help = ["fromtext"];
handler.command = ["fromtext"];
handler.tags = ["convert"];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Mengubah dokumen teks menjadi teks biasa"];

module.exports = handler;