const fs = require('fs');
const { getRandom } = require('../../lib/myfunc');

const handler = async (m, { conn, setReply }) => {
    const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
    const isQuotedVideo = m.quoted && m.quoted.mtype === 'videoMessage';
    const isQuotedAudio = m.quoted && m.quoted.mtype === 'audioMessage';

    const isImage = m.mtype === 'imageMessage';
    const isVideo = m.mtype === 'videoMessage';
    const isAudio = m.mtype === 'audioMessage';

    const quoted = m.quoted ? m.quoted : m;

    if (!(isQuotedImage || isQuotedVideo || isQuotedAudio || isImage || isVideo || isAudio)) {
        return setReply('Reply gambar, video, atau audio untuk dikirim sebagai dokumen!');
    }

    try {
        setReply('Proses mengubah ke dokumen...');
        let media = await conn.downloadAndSaveMediaMessage(quoted);
        let ext = isQuotedImage || isImage ? '.jpg' : isQuotedVideo || isVideo ? '.mp4' : '.mp3';
        let fileName = getRandom(ext);

        fs.renameSync(media, fileName);
        
        await conn.sendMessage(m.chat, {
            document: { url: fileName },
            mimetype: isQuotedImage || isImage ? 'image/jpeg' :
                      isQuotedVideo || isVideo ? 'video/mp4' :
                      'audio/mpeg',
            fileName: `converted${ext}`
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (e) {
        console.error(e);
        setReply('Terjadi kesalahan saat mengonversi ke dokumen!');
    }
};

handler.help = ['todocumen'];
handler.command = ['todocumen','todokumen'];
handler.tags = ['convert'];
handler.noCmdStore = true;
handler.noCmdPrivate = true;
handler.description = ["Ubah media (gambar, video, audio) menjadi dokumen"];

module.exports = handler;