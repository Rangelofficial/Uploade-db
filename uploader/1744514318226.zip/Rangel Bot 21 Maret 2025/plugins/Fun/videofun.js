const fs = require('fs');

let handler = async (m, { command, conn,setReply,prefix }) => {

 const listVideoFun = [
  'tiktokghea', 'cosplayangel', 'tiktokbocil', 'videosad', 
    'videowibu', 'tiktokkayes', 'tiktokpanrika', 'videogalau'
  ];

  if (command === 'videofun') {
    let effectList = `Daftar video fun yang tersedia:\n\n`;
    listVideoFun.forEach((effect, index) => {
      effectList += `${index + 1}. ${effect}\n`;
    });
    effectList += `\nKetik ${prefix}[nama video] untuk menggunakannya.\nContoh: ${prefix}cosplayangel`;
    return setReply(effectList);
  }

    const paths = {
        tiktokghea: './database/storage/media/tiktokvids/gheayubi.json',
        cosplayangel: './database/storage/media/tiktokvids/cosplayangel.json',
        tiktokbocil: './database/storage/media/tiktokvids/bocil.json',
        videosad: './database/storage/media/tiktokvids/videosad.json',
        videowibu: './database/storage/media/tiktokvids/wibuvid.json',
        tiktokkayes: './database/storage/media/tiktokvids/kayes.json',
        tiktokpanrika: './database/storage/media/tiktokvids/panrika.json',
        videogalau: './database/storage/media/tiktokvids/galau.json'
    };
    if (!paths[command]) return m.reply("Perintah tidak ditemukan.");

    try {
        setReply("Tunggu sebentar...");
        const data = JSON.parse(fs.readFileSync(paths[command]));
        const hasil = data[Math.floor(Math.random() * data.length)]; 
        let caption = (command === 'cosplayangel')
            ? 'nih bang econn\nIngat jangan gamon yak\nAng3l udah pergi;)'
            : "Sukses!";

        await conn.sendMessage(m.chat, { caption, video: { url: hasil.url } }, { quoted: m });

    } catch (error) {
        console.error("Error saat mengambil video:", error);
        m.reply("Terjadi kesalahan saat mengambil video. Coba lagi nanti.");
    }
};

handler.command = [
    'videofun','tiktokghea', 'cosplayangel', 'tiktokbocil', 'videosad', 
    'videowibu', 'tiktokkayes', 'tiktokpanrika', 'videogalau'
];
handler.tags = ['fun'];
handler.help = [
    'tiktokghea', 'cosplayangel', 'tiktokbocil', 'videosad', 
    'wibuvid', 'tiktokkayes', 'tiktokpanrika', 'videogalau'
];
handler.noCmdStore = true
handler.onlyGroup = true
handler.description = ["random video fun"]
module.exports = handler;
