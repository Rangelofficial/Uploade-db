const fetch = require('node-fetch');

let handler = async (m, { conn,setReply,sendReact }) => {
    try {
mess.wait()
        let kaydt = await fetch('https://raw.githubusercontent.com/KirBotz/nyenyee/master/meryani.json').then(res => res.json());

        let hayu = kaydt[Math.floor(Math.random() * kaydt.length)];

        await conn.sendMessage(m.chat, { video: { url: hayu }, caption: `Nih kak🗿` }, { quoted: m });
    } catch (error) {
        console.error("Error fetching video:", error);
        sendReact('❌')
    }
};

handler.command = ['jjmeryani']; 
handler.tags = ['fun']; // Kategori fitur
handler.help = ['randomvideo']; 
handler.noCmdStore = true
handler.noCmdPrivate = true
handler.description = ["kumpulan jj meryani"]
module.exports = handler;
