let fetch = require('node-fetch');

let handler = async (m, { setReply, conn }) => {
  try {
    let response = await fetch("https://skizoasia.xyz/api/memes?apikey=Rangelofficial", {
      method: 'GET', 
      headers: {
        'Content-Type': 'application/json', 
      },
    });
    
    if (!response.ok) throw new Error("Gagal mengambil data");

    let result = await response.json();
    if (!result || result.length === 0) throw new Error("Meme suara tidak tersedia");

    let meme = result[Math.floor(Math.random() * result.length)];
m.reply('_wait sedang mencari sound_')
    await setReply(`🎵 *${meme.title}* \n🔗 [Link](${meme.link})`);

    await conn.sendMessage(m.chat, {
      audio: { url: meme.audioUrl },
      mimetype: 'audio/mp4',
      ptt: true  
    },{quoted:m});

  } catch (error) {
    console.error(error);
    setReply("Maaf, terjadi kesalahan dalam mengambil meme suara.");
  }
};

handler.tags = ["fun"];
handler.command = ["soundmeme"];
handler.help = ["memesound"];
handler.noCmdStore = true
handler.noCmdPrivate = true
handler.description = ["random sound meme"]
module.exports = handler;
