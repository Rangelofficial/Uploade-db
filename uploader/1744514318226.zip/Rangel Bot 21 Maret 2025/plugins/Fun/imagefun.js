const fs = require('fs');

let handler = async (m, { command,prefix, conn,setReply}) => {

const listRandom = [
    'chinese', 'hijab', 'indo', 'japanese', 'korean', 
    'malay', 'randomgirl', 'randomboy', 'thai', 'vietnamese'
  ];

  if (command === 'imagefun') {
    let effectList = `Daftar imagefun yang tersedia:\n\n`;
    listRandom.forEach((effect, index) => {
      effectList += `${index + 1}. ${effect}\n`;
    });
    effectList += `\nKetik ${prefix}[salah satu list] untuk menggunakannya.\nContoh: ${prefix}hijab`;
    return setReply(effectList);
  }

    const paths = {
        chinese: './database/storage/media/tiktokpics/china.json',
        hijab: './database/storage/media/tiktokpics/hijab.json',
        indo: './database/storage/media/tiktokpics/indonesia.json',
        japanese: './database/storage/media/tiktokpics/japan.json',
        korean: './database/storage/media/tiktokpics/korea.json',
        malay: './database/storage/media/tiktokpics/malaysia.json',
        randomgirl: './database/storage/media/tiktokpics/random.json',
        randomboy: './database/storage/media/tiktokpics/random2.json',
        thai: './database/storage/media/tiktokpics/thailand.json',
        vietnamese: './database/storage/media/tiktokpics/vietnam.json'
    };

    if (!paths[command]) return m.reply("Perintah tidak ditemukan.");

    try {
        setReply("Tunggu sebentar...");
        const data = JSON.parse(fs.readFileSync(paths[command]));
        const hasil = data[Math.floor(Math.random() * data.length)]; 
        await conn.sendMessage(m.chat, { caption: "Sukses!", image: { url: hasil.url } }, { quoted: m });

    } catch (error) {
        console.error("Error saat mengambil gambar:", error);
        m.reply("Terjadi kesalahan saat mengambil gambar. Coba lagi nanti.");
    }
};

handler.command = [
    'imagefun','chinese', 'hijab', 'indo', 'japanese', 'korean', 
    'malay', 'randomgirl', 'randomboy', 'thai', 'vietnamese'
];
handler.tags = ['fun'];
handler.help = [
    'chinese', 'hijab', 'indo', 'japanese', 'korean', 
    'malay', 'randomgirl', 'randomboy', 'thai', 'vietnamese'
];
handler.noCmdStore = true
handler.noCmdPrivate = true
handler.description = ["random image fun"]
module.exports = handler;
