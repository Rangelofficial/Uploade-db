let handler = async (m, {  conn, args, usedPrefix }) => {
  let info = `
乂 List Pet:
🐈 • Cᴀᴛ
🐕 • Dᴏɢ
🐎 • Hᴏʀsᴇ
🦊 • Fᴏx
🤖 • Rᴏʙᴏ
🐉 • Dragon

*➠ Example:* ${usedPrefix}feed cat
`.trim();
  let pesan = pickRandom([
    "ɴʏᴜᴍᴍᴍ~",
    "ᴛʜᴀɴᴋs",
    "ᴛʜᴀɴᴋʏᴏᴜ ^-^",
    "...",
    "ᴛʜᴀɴᴋ ʏᴏᴜ~",
    "ᴀʀɪɢᴀᴛᴏᴜ ^-^",
  ]);
  let type = (args[0] || "").toLowerCase();
  let emo =
    type == "fox"
      ? "🦊"
      : "" || type == "cat"
      ? "🐈"
      : "" || type == "dog"
      ? "🐕"
      : "" || type == "horse"
      ? "🐴"
      : "" || type == "robo"
      ? "🤖"
      : "" || type == "dragon"
      ? "🐲"
      : "";
  let user = global.db.data.users[m.sender];
  let rubah = global.db.data.users[m.sender].fox;
  let kuda = global.db.data.users[m.sender].horse;
  let kucing = global.db.data.users[m.sender].cat;
  let anjing = global.db.data.users[m.sender].dog;
  let robot = global.db.data.users[m.sender].robo;
  let naga = global.db.data.users[m.sender].dragon;
  switch (type) {
    case "fox":
      if (rubah == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (rubah == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __waktur = new Date() - user.foxlastfeed;
      let _waktur = 600000 - __waktur;
      let waktur = clockString(_waktur);
      if (new Date() - user.foxlastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.foxexp += 20;
          user.foxlastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );
          if (rubah > 0) {
            let naiklvl = rubah * 100 - 1;
            if (user.foxexp > naiklvl) {
              user.fox += 1;
              user.foxexp -= rubah * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${waktur}*`);
      break;
    case "cat":
      if (kucing == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (kucing == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __waktuc = new Date() - user.catlastfeed;
      let _waktuc = 600000 - __waktuc;
      let waktuc = clockString(_waktuc);
      if (new Date() - user.catlastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.catexp += 20;
          user.catlastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );

          if (kucing > 0) {
            let naiklvl = kucing * 100 - 1;
            if (user.catexp > naiklvl) {
              user.cat += 1;
              user.catexp -= kucing * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${waktuc}*`);
      break;
    case "dog":
      if (anjing == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (anjing == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __waktua = new Date() - user.doglastfeed;
      let _waktua = 600000 - __waktua;
      let waktua = clockString(_waktua);
      if (new Date() - user.doglastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.dogexp += 20;
          user.doglastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );
          if (anjing > 0) {
            let naiklvl = anjing * 100 - 1;
            if (user.dogexp > naiklvl) {
              user.dog += 1;
              user.dogexp -= anjing * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${waktua}*`);
      break;
    case "dragon":
      if (naga == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (naga == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __waktud = new Date() - user.dragonlastfeed;
      let _waktud = 600000 - __waktud;
      let waktud = clockString(_waktud);
      if (new Date() - user.dragonlastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.dragonexp += 20;
          user.dragonlastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );
          if (naga > 0) {
            let naiklvl = naga * 100 - 1;
            if (user.dragonexp > naiklvl) {
              user.dragon += 1;
              user.dragonexp -= naga * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${waktud}*`);
      break;
    case "horse":
      if (kuda == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (kuda == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __waktuk = new Date() - user.horselastfeed;
      let _waktuk = 600000 - __waktuk;
      let waktuk = clockString(_waktuk);
      if (new Date() - user.horselastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.horseexp += 20;
          user.horselastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );
          if (kuda > 0) {
            let naiklvl = kuda * 100 - 1;
            if (user.horseexp > naiklvl) {
              user.horse += 1;
              user.horseexp -= kuda * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${waktuk}*`);
      break;
    case "robo":
      if (robot == 0) return m.reply("ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛʜɪs ᴘᴇᴛ ʏᴇᴛ!");
      if (robot == 10) return m.reply("ʏᴏᴜʀ ᴘᴇᴛ ɪs ᴍᴀx ʟᴇᴠᴇʟ !");
      let __wakturb = new Date() - user.robolastfeed;
      let _wakturb = 600000 - __wakturb;
      let wakturb = clockString(_wakturb);
      if (new Date() - user.robolastfeed > 600000) {
        if (user.petfood > 0) {
          user.petfood -= 1;
          user.roboexp += 20;
          user.robolastfeed = new Date() * 1;
          m.reply(
            `ғᴇᴇᴅɪɴɢ *${type}*...\n*${emo} ${type.capitalize()}:* ${pesan}`
          );
          if (robot > 0) {
            let naiklvl = robot * 100 - 1;
            if (user.roboexp > naiklvl) {
              user.robo += 1;
              user.roboexp -= robot * 100;
              m.reply(`*ᴄᴏɴɢʀᴀᴛs!* , ʏᴏᴜʀ ᴘᴇᴛ ʟᴇᴠᴇʟᴜᴘ`);
            }
          }
        } else m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ғᴏᴏᴅ ɴᴏᴛ ᴇɴᴏᴜɢʜ`);
      } else
        m.reply(`ʏᴏᴜʀ ᴘᴇᴛ ɪs ғᴜʟʟ, ᴛʀʏ ғᴇᴇᴅɪɴɢ ɪᴛ ᴀɢᴀɪɴ ɪɴ\n➞ *${wakturb}*`);
      break;
    default:
      return m.reply(info);
  }
};
handler.help = ["feed [pet type]"];
handler.tags = ["rpg"];
handler.command = /^(berimakan(ing)?)$/i;

handler.register = true;
handler.group = true;
handler.rpg = true;
module.exports = handler;

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, " H ", m, " M ", s, " S"]
    .map((v) => v.toString().padStart(2, 0))
    .join("");
}
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}
