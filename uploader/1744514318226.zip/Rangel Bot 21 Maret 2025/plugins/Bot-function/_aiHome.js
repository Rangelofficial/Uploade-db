const fs = require('fs');
const axios = require('axios');
const uploadImage = require('../../lib/uploadImage'); 
const uploadToGithub = require('../../lib/uploadToGithub');
const { textToVoice } = require('../../lib/convert');

const handler = (m) => m;

handler.before = async function (m, { conn, prefix }) {
    const gameList = [
        "susunkata", "tekateki", "tebakbendera", "tebakkimia",
        "caklontong", "tebaklagu", "tebaktebak", "tebakkata",
        "tebaklirik", "siapaaku", "tebakgambar", "family",
        "tebakbom", "bj", "war"
    ];

    for (let game of gameList) conn[game] = conn[game] || {};
    for (let game of gameList) {
        if (m.chat in conn[game] || m.key.fromMe || m.isBaileys) return;
    }

    if (["videoMessage", "stickerMessage", "contactMessage", "locationMessage", "inviteLinkGroup", "mentionedJid"].includes(m.type)) {
        return;
    }

    const isCmd = m.body.startsWith(prefix);
    if (isCmd) return;

    const caracter = 'cgSgspJ2msm6clMCkdW9'; // kira

    try {
        const aihomeData = JSON.parse(fs.readFileSync('./database/group/aihome.json', 'utf-8'));
        const groupData = aihomeData.find((group) => group.id === m.chat);

        if (groupData && groupData.status) {
            conn.sendMessage(groupData.id, { react: { text: '💬', key: m.key } });

            const textPrompt = groupData.promptAi;
            let messageText = m.text || m.message?.conversation;

            // **Cek jika pesan adalah audio**
            if (m.type === 'audioMessage') {
                try {
                    let filePath = await conn.downloadAndSaveMediaMessage(m);
                    if (!fs.existsSync(filePath)) {
                        return conn.sendMessage(m.chat, { text: "❌ Gagal mengunduh audio." }, { quoted: m });
                    }

                    let audioBuffer = fs.readFileSync(filePath);
                    let urlAudio = await uploadToGithub(audioBuffer);
                    fs.unlinkSync(filePath);

                    if (!urlAudio) {
                        return conn.sendMessage(m.chat, { text: "❌ Gagal mengunggah audio ke server." }, { quoted: m });
                    }

                    // **Panggil API Transkripsi**
                    let transcribeRes = await axios.get(`https://api.neoxr.eu/api/whisper?audio=${urlAudio}&apikey=Ehanz`);

                    if (!transcribeRes.data?.status || !transcribeRes.data?.data?.text) {
                        return conn.sendMessage(m.chat, { text: "❌ Gagal mengenali audio." }, { quoted: m });
                    }

                    messageText = transcribeRes.data.data.text;
                } catch (err) {
                    console.error("❌ Error saat memproses VN:", err);
                    return conn.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat memproses audio." }, { quoted: m });
                }
            }

            // **Cek jika pesan berupa gambar yang di-quoted**
            const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
            if (isQuotedImage) {
                try {
                    const mediaPath = await conn.downloadAndSaveMediaMessage(m.quoted);
                    const media = fs.readFileSync(mediaPath);
                    const uploadedImageUrl = await uploadImage(media);

                    console.log('Gambar berhasil diupload:', uploadedImageUrl);

                    // **Panggil API Gemini untuk analisis gambar**
                    const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/image`;
                    const params = {
                        q: 'What is this picture? Please describe it.', 
                        url: uploadedImageUrl 
                    };
                    const response = await axios.get(apiUrl, { params });

                    const description = response.data?.content || 'Gagal mendapatkan deskripsi gambar.';

                    await conn.sendMessage(m.chat, {
                        text: `📷 *Deskripsi Gambar:*\n${description}`
                    }, { quoted: m });

                    fs.unlinkSync(mediaPath); // **Hapus file setelah selesai diproses**
                } catch (error) {
                    console.error("Error fetching AI image data:", error);
                    m.reply("Maaf, terjadi kesalahan saat memproses gambar. Coba lagi nanti ya!");
                }
            } else if (messageText) {
                // **Proses pesan teks atau hasil transkripsi audio**
                const requestData = { content: messageText, user: groupData.id, prompt: textPrompt };
                try {
                    const response = await axios.post('https://luminai.my.id', requestData);

                    if (groupData.type === 'audio') {
                        const audioBuffer = await textToVoice(caracter, response.data.result);
                        const audioNya = fs.readFileSync(audioBuffer);
                       m.reply(audioNya)
                        await conn.sendMessage(groupData.id, { audio: audioNya, mimetype: 'audio/ogg', ptt: true }, { quoted: m });
                    } else {
                        m.reply(response.data.result);
                    }
                } catch (error) {
                    console.error("Error fetching AI text data:", error);
                    m.reply("Maaf, terjadi kesalahan saat memproses permintaan AI. Coba lagi nanti ya!");
                }
            }
        }
    } catch (error) {
        console.error("Error processing AI Home:", error);
        m.reply("Maaf, terjadi kesalahan internal. Silakan cek konfigurasi aihome.json.");
    }
};

module.exports = handler;