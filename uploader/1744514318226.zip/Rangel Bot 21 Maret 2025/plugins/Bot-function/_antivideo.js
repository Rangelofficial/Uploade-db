let handler = (m) => m;

handler.before = async function (m, { conn }) {
 
  const isAntiVideo = m.isGroup ? db.data.chats[m.chat].antivideo : false;
  const isHanMedia = m.mtype;
  // ANTI VIDEO
  if (m.isGroup && isAntiVideo && isHanMedia) {
    if (isHanMedia === "videoMessage") {
       if (m.isAdmin) {
        return m.reply('😎 Kamu admin grup, jadi Video ini tidak akan dihapus!');
      }
      if (!m.isBotAdmin) return m.reply('Bot Bukan Admin Jadi Ga Bisa Hapus Video Nya')
      if (m.isBotAdmin) { 
  await m.reply(`\`\`\`「 Video Terdeteksi 」\`\`\`\nMaaf, saya akan mengambil tindakan sesuai pengaturan Anti-Video grup ini.`);
  await new Promise(resolve => setTimeout(resolve, 1000)); 
  await conn.sendMessage(m.chat, { 
    delete: { 
      remoteJid: m.chat, 
      fromMe: false, 
      id: m.key.id, 
      participant: m.key.participant || m.participant 
    }
  });
}
      }
    }
  
};

module.exports = handler;