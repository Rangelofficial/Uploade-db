const fs = require("fs");
const moment = require("moment-timezone");

const handler = (m) => m;

let sentFiles = {};
handler.before = async function (m, { conn }) {
  const jpegThumbnail = fs.readFileSync("./media/image/docRangel.jpg");
  
  async function sendDataJSON() {
    const currentTime = moment().tz("Asia/Jakarta").format("HH:mm"); 
    const currentDate = moment().format("YYYY-MM-DD");
    const targetTime = "07:00"; 
    if (currentTime !== targetTime) {
      
      return;
    }

    const dataFiles = [
      { path: "./database/store/datapanel.json", fileName: "datapanel.json" },
      { path: "./database/database.json", fileName: "database.json" },
    ];

    for (const { path, fileName } of dataFiles) {
     
      if (sentFiles[fileName] === currentDate) {
        console.log(`File ${fileName} sudah dikirim hari ini.`);
        continue;
      }

      if (fs.existsSync(path)) {
        try {
          await conn.sendMessage(ownerNumber, {
            document: fs.readFileSync(path),
            mimetype: "application/json",
            fileName,
            jpegThumbnail,
          });
          console.log(`File ${fileName} berhasil dikirim.`);
          sentFiles[fileName] = currentDate; 
        } catch (err) {
          console.error(`Gagal mengirim file ${fileName}:`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 5000)); 
      } else {
        console.log(`File ${fileName} tidak ditemukan.`);
      }
    }
  }

  await sendDataJSON(); 
};

module.exports = handler;