const fs = require("fs");
const axios = require("axios");

const dataSimiPath = "./database/group/simi.json";
let dataSimi = JSON.parse(fs.readFileSync(dataSimiPath));

const handler = (m) => m;
handler.before = async function (m, { conn, q, prefix, command, isAccept, reply }) {
  const isSimi = m.isGroup ? db.data.chats[m.chat]?.simi : false;
  const botNumber = m.botNumber;

  const gameList = [
    "susunkata",
    "tekateki",
    "tebakbendera",
    "tebakkimia",
    "caklontong",
    "tebaklagu",
    "tebaktebak",
    "tebakkata",
    "tebaklirik",
    "tebaklogo",
    "siapaaku",
    "tebakgambar",
    "family",
    "tebakbom",
    "bj",
    "war",
    "math",
    "aiPrivate",
    "werewolf"
  ];

  for (let game of gameList) {
    conn[game] = conn[game] ? conn[game] : {};
  }

  for (let game of gameList) {
    if (m.chat in conn[game] || !isSimi || m.key.fromMe) {
      return;
    }
  }

  const isCmd = m.body.startsWith(prefix);
  const allcommand = db.data.allcommand || [];
  const isKnownCommand = isCmd ? command : allcommand.includes(command);

  const isSticker = m.type === "stickerMessage";
  const isText = m.type === "conversation" || m.type === "extendedTextMessage";

  const isReplySticker =
    isSticker &&
    m.message?.stickerMessage?.contextInfo?.participant === botNumber;
  const isReplyText =
    isText &&
    m.message?.extendedTextMessage?.contextInfo?.participant === botNumber;

  const replySticker = async () => {
    if (Object.keys(db.data.sticker || {}).length === 0) return;
    const randomSticker = pickRandom(Object.keys(db.data.sticker));
    const stickerLink = db.data.sticker[randomSticker]?.link;
    if (stickerLink) {
      conn.sendMessage(m.chat, { sticker: { url: stickerLink } }, { quoted: m });
    }
  };

  const replyText = async (text) => {
    try {
      const prompt = `
          Mulai sekarang kamu adalah Simi, sebuah chatbot dengan gaya berbicara yang santai, singkat, dan ramah bernama rangel.
           Tuan kamu adalah ehanz dan angel adalah kekasih nya,social media kamu adalah rangelofficial atau ehanzdhoanx.
          Kamu Mempunyai Fitur Bot WhatsApp Jadi Jika Ada Yang Bingung Cara Pakai Bot Silahkan Ketik .menu dan pahami di setiap masing masing folder 
          Jawablah setiap pertanyaan atau obrolan dengan gaya bahasa sehari-hari yang tidak terlalu formal, seperti teman ngobrol biasa. 
          Hindari jawaban yang panjang dan buat percakapan lebih santai dengan sedikit humor. Kamu boleh menggunakan kata-kata tidak formal 
          seperti "yaudah", "hmm", "hehe", "oke deh", dan lainnya. Jangan terlalu teknis atau kaku, buatlah obrolan terasa hidup dan menyenangkan.
        `;


      const requestData = { content: text, prompt: prompt, user: m.sender };

      // Check if the response is already in simi.json
      const lowerCaseText = text.toLowerCase();
      if (dataSimi[lowerCaseText]) {
        reply(pickRandom(dataSimi[lowerCaseText]));
 
      } else {
        // If no response, fallback to API
        const response = await axios.post("https://luminai.my.id", requestData);

        if (response.data.result) {
          reply(response.data.result);
          // Save the response to simi.json
         // addNewDataToSimi(lowerCaseText, response.data.result);
        } else {
          reply("Hmm, aku nggak ngerti maksud kamu nih 🤔");
        }
      }
    } catch (err) {
      console.error(err);
      reply("Maaf, aku lagi error nih. Coba lagi nanti ya 😅");
    }
  };

  const addNewDataToSimi = (key, defaultResponse) => {
    if (!dataSimi[key]) {
      dataSimi[key] = [defaultResponse];
      fs.writeFileSync(dataSimiPath, JSON.stringify(dataSimi, null, 2), "utf-8");
      console.log(`Data baru ditambahkan: "${key}"`);
    }
  };

  try {
    if (!isKnownCommand) {
      if (isSticker && isReplySticker) {
        await sleep(2000);
        await replySticker();
      } else if (isText && isReplyText) {
        const userText = m.message.extendedTextMessage.text;
 conn.sendPresenceUpdate("composing", m.chat);
        await sleep(1000);
        await replyText(userText);
      }
    }
  } catch (err) {
    console.error(err);
  }
};

module.exports = handler;

const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));