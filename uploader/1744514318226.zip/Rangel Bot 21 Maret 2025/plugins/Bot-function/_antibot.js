let handler = (m) => m;

handler.before = async function (m, { conn }) {
  const isAntiBot = m.isGroup ? db.data.chats[m.chat]?.antibot : false;

  // ANTI BOT
  if (m.isGroup && isAntiBot) {
    if (m.isBaileys && !m.fromMe) {
      const groupMetadata = await conn.groupMetadata(m.chat);
      const botNumber = conn.user.jid; 
      const isBotAdmin = groupMetadata.participants.some(participant => 
        participant.id === botNumber && participant.admin
      );

      if (isBotAdmin) {
        await m.reply(
          `\`\`\`「 ANTI BOT 」\`\`\`\n*Another Bot Detected*\n\nHusshhh! Get away from this group!!!`
        );
        await new Promise(resolve => setTimeout(resolve, 1000));
        return await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
      } else {
        console.log(`[ANTI BOT] Bot tidak dapat menghapus anggota karena bukan admin.`);
      }
    }
  }
};

module.exports = handler;