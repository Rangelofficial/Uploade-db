/*const handler = (m) => m;

handler.before = async function (m, { conn }) {
    try {
        if (!m.message || !m.message.reactionMessage) return; 

        const chatId = m.key.remoteJid;
        const reactedMessageId = m.message.reactionMessage.key.id;
        const reactionText = m.message.reactionMessage.text;
        
        
        const reactedBy = m.message.reactionMessage.sender || m.participant || m.key.participant || m.key.remoteJid;

       
        const isMedia = !!(
            m.message.imageMessage ||
            m.message.videoMessage ||
            m.message.documentMessage ||
            m.message.audioMessage ||
            m.message.stickerMessage
        );

        m.reply(`Pesan ${reactedMessageId} di ${chatId} mendapat reaksi: ${reactionText} dari ${reactedBy}`);

      
        if (isMedia) {
            await conn.sendMessage(chatId, { text: "React ke media berhasil!" }, { quoted: m });
        } else {
            await conn.sendMessage(chatId, { text: "React berhasil!" }, { quoted: m });
        }

    } catch (err) {
        console.error('Terjadi kesalahan saat menangani reaksi:', err);
    }
};

module.exports = handler*/