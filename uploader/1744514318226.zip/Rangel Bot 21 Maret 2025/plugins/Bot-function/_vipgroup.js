const moment = require('moment-timezone');

const handler = (m) => m;

handler.before = async function (m, { conn }) {
  
  const chats = global.db.data.chats; 
  const currentTime = moment().tz('Asia/Jakarta');
  for (const [groupId, groupData] of Object.entries(chats)) {
    if (groupData.vip) {
      const vipExpired = moment(groupData.vipExpired).tz('Asia/Jakarta');

 
      if (currentTime.isAfter(vipExpired)) {
       
        groupData.vip = false;
        groupData.vipStart = ''; 
        groupData.vipExpired = ''; 
        try {
          await conn.sendMessage(
            groupId,{ text: `Status VIP grup ini telah berakhir dan telah direset. Jika ingin memperpanjang, silakan hubungi owner.`
            });
        } catch (e) {
          console.error(`Gagal mengirim notifikasi ke grup ${groupId}:`, e);
        }

  
        try {
          await conn.sendMessage(
            ownerNumber + '@s.whatsapp.net',{ text:    `Pemberitahuan: Status VIP grup ${groupId} telah berakhir dan telah direset.`})
        
            
         
        } catch (e) {
          console.error(`Gagal mengirim notifikasi ke owner:`, e);
        }
      }
    }
  }

  return true;
};

module.exports = handler;