const moment = require("moment-timezone");
const fs = require("fs");
const archiver = require("archiver");
const path = require("path");

const handler = (m) => m;

handler.before = async function (m, { conn, prefix }) {
  const jpegThumbnail = fs.readFileSync("./media/image/docRangel.jpg");
  
  async function createBackup() {
    const currentDate = moment().tz("Asia/Jakarta").format("YYYY-MM-DD");
    const nameFile = `${botName}-${currentDate}.zip`;
    const output = fs.createWriteStream(nameFile);
    const archive = archiver("zip", { zlib: { level: 9 } }); 

   
    console.log("Membuat file zip, harap tunggu...");

   
    output.on("close", async function () {
      console.log(
        `File zip berhasil dibuat\nTotal: ${await FileSize(archive.pointer())}`
      );
   
      await conn.sendMessage(ownerNumber, {
        document: fs.readFileSync(nameFile),
        jpegThumbnail,
        mimetype: "application/zip",
        fileName: nameFile,
      });

     
      fs.unlinkSync(nameFile);
    });

 
    archive.on("error", function (err) {
      throw err;
    });

    archive.pipe(output);

    function addFilesAndFolders(dirPath, archive) {
      const items = fs.readdirSync(dirPath);
      const kecuali = [
        "node_modules",
        ".git",
        "package-lock.json",
        ".heroku",
        ".profile.d",
        "vendor",
        ".npm",
      ];
      items.forEach((item) => {
        const fullPath = path.join(dirPath, item);
        if (fs.statSync(fullPath).isDirectory()) {
          if (!kecuali.includes(item)) {
            archive.directory(fullPath, item);
          }
        } else if (!fullPath.endsWith(".xml")) {
          archive.file(fullPath, { name: item });
        }
      });
    }

    addFilesAndFolders(".", archive);
    await archive.finalize();
  }

 
  const currentTime = moment().tz("Asia/Jakarta").format("HH:mm");
  if (currentTime === "07:00") {
    console.log("Waktunya membuat backup.");
    await createBackup();
  } else {
    
  }
};

module.exports = handler;

async function FileSize(number) {
  const SI_POSTFIXES = ["B", "KB", "MB", "GB", "TB", "PB", "EB"];
  const tier = (Math.log10(Math.abs(number)) / 3) | 0;
  if (tier == 0) return number + " B";
  const postfix = SI_POSTFIXES[tier];
  const scale = Math.pow(10, tier * 3);
  const scaled = number / scale;
  let formatted = scaled.toFixed(1).replace(".", ",");
  if (/\.0$/.test(formatted)) formatted = formatted.substr(0, formatted.length - 2);
  return formatted + " " + postfix;
}


