const fs = require("fs");

let handler = (m) => m;

handler.before = async function (m, { conn }) {
  const type = m.message ? Object.keys(m.message)[0] : "";
  const pesilit =
    type === "conversation" && m.message.conversation
      ? m.message.conversation
      : type === "imageMessage" && m.message.imageMessage.caption
      ? m.message.imageMessage.caption
      : type === "videoMessage" && m.message.videoMessage.caption
      ? m.message.videoMessage.caption
      : type === "extendedTextMessage" && m.message.extendedTextMessage.text
      ? m.message.extendedTextMessage.text
      : "";

  const messagesC = pesilit.trim().toLowerCase();

  // Load data dari file JSON
  const imagenya = JSON.parse(fs.readFileSync("./database/storage/image.json"));
  const videonya = JSON.parse(fs.readFileSync("./database/storage/video.json"));
  const responData = JSON.parse(fs.readFileSync("./database/storage/respon.json"));

  // AUTO RESPON VIDEO
  const videoData = videonya.find((video) => video.nama.toLowerCase() === messagesC);
  if (videoData) {
    await conn.sendFile(m.chat, videoData.urlVideo, "video.mp4", `🎥 Here is the video: *${videoData.nama}*`, m);
    return;
  }

  // AUTO RESPON IMAGE
  const imageData = imagenya.find((image) => image.nama.toLowerCase() === messagesC);
  if (imageData) {
    await conn.sendFile(m.chat, imageData.urlImage, "image.jpg", `🖼️ Here is the image: *${imageData.nama}*`, m);
    return;
  }

  // AUTO RESPON .JSON
  const chatId = m.chat;
  if (responData[chatId] && responData[chatId][messagesC]) {
    await conn.sendMessage(m.chat, { text: responData[chatId][messagesC] }, { quoted: m });
    return;
  }
};

module.exports = handler;