const fs = require('fs');
const axios = require('axios');
const { generateMessageIDV2 } = require('baileys');
const { randomBytes } = require('crypto');
const uploadToGithub = require('../../lib/uploadToGithub');
const { textToVoice } = require('../../lib/convert');

const character = 'cgSgspJ2msm6clMCkdW9'; // Karakter AI Jesica
const LIMIT_RESET_HOURS = 6;
const MAX_LIMIT = 50;

const handler = (m) => m;

handler.before = async function (m, { conn, prefix }) {
 
const gameList = [
        "susunkata", "tekateki", "tebakbendera", "tebakkimia", "caklontong", "tebaklagu", "tebaktebak", 
        "tebakkata", "tebaklirik", "siapaaku", "tebakgambar", "family", "tebakbom", "bj", "war"
    ];
    
    for (let game of gameList) {
        conn[game] = conn[game] ? conn[game] : {};
    }
    
    for (let game of gameList) {
        if (m.chat in conn[game] || m.key.fromMe || m.isBaileys || m.isGroup) {
            return;
        }
    }
    
    if (m.type === 'videoMessage' || m.type === 'stickerMessage'  || 
        m.type === 'contactMessage' || m.type === 'locationMessage' || m.type === 'inviteLinkGroup' ||
        m.type === 'mentionedJid') {
        return;
    }


    const userId = m.sender;
    const now = Date.now();

    conn.aiPrivate = conn.aiPrivate || {};
    if (!conn.aiPrivate[userId]) {
        conn.aiPrivate[userId] = {
            limit: MAX_LIMIT,
            lastReset: now,
        };
    }

    const userSession = conn.aiPrivate[userId];

    if (now - userSession.lastReset >= LIMIT_RESET_HOURS * 60 * 60 * 1000) {
        userSession.limit = MAX_LIMIT;
        userSession.lastReset = now;
    }

    const isCmd = m.text?.startsWith(prefix);
    if (isCmd) return;
    if (m.key?.remoteJid === 'status@broadcast') return;

    if (userSession.limit <= 0) {
        return conn.sendMessage(m.chat, { text: "Limit Chat AI Anda sudah habis. Silakan tunggu hingga limit direset." }, { quoted: m });
    }

    let messageText = m.text;
    let isAudio = false; // Flag untuk mendeteksi apakah pesan adalah audio

    // **Cek jika Pesan adalah Audio/VN**
    if (m.type === 'audioMessage') {
        isAudio = true;
        try {
            let filePath = await conn.downloadAndSaveMediaMessage(m);
            if (!fs.existsSync(filePath)) {
                return conn.sendMessage(m.chat, { text: "❌ Gagal mengunduh audio." }, { quoted: m });
            }

            let audioBuffer = fs.readFileSync(filePath);
            let urlAudio = await uploadToGithub(audioBuffer);
            fs.unlinkSync(filePath); // Hapus file setelah diunggah

            if (!urlAudio) {
                return conn.sendMessage(m.chat, { text: "❌ Gagal mengunggah audio ke server." }, { quoted: m });
            }

            // **Panggil API Transkripsi**
            let transcribeRes = await axios.get(`https://api.neoxr.eu/api/whisper?audio=${urlAudio}&apikey=Ehanz`);

            if (!transcribeRes.data?.status || !transcribeRes.data?.data?.text) {
                return conn.sendMessage(m.chat, { text: "❌ Gagal mengenali audio." }, { quoted: m });
            }

            messageText = transcribeRes.data.data.text;
        } catch (err) {
            console.error("❌ Error saat memproses VN:", err);
            return conn.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat memproses audio." }, { quoted: m });
        }
    }
conn.sendReact(m.sender, '💬', m.key);
    // **Gunakan AI untuk membalas pesan**
    try {
        const responseFromAI = await axios.post("https://luminai.my.id/", {
            content: messageText,
            user: m.sender,
            prompt: `Anda adalah asisten virtual yang cerdas dan responsif Bernama Jesica, Anda Dikembangkan Oleh Perusahaan Rangelofficial Yang Didirikan Oleh Ehanz Dan Kekasihnya Bernama Angel. Jawablah dengan bahasa yang alami, ramah, dan informatif. Kamu adalah AI di private chat saja yang dapat membantu atau mengarahkan cara penggunaan bot Rangel. Beritahukan bahwa fitur group tidak dapat digunakan di private chat. Untuk lebih lanjut, silakan lihat daftar fitur dengan ketik .menu dan untuk group botnya silakan ketik .gcrangel. Jawab seperti teman sehari-hari, jangan terlalu panjang.`
        });

        if (!responseFromAI.data?.result) {
            return conn.sendMessage(m.chat, { text: "❌ AI tidak memberikan respons yang valid." }, { quoted: m });
        }

        
        const aiResponse = responseFromAI.data.result;

        if (isAudio) {
            // **Jika pesan asal berupa audio, kirim balasan dalam format suara**
            const audioPath = await textToVoice(character, aiResponse);
            const audioBuffer = fs.readFileSync(audioPath);
m.reply(audioBuffer)
            await conn.sendMessage(m.chat, {
                audio: audioBuffer,
                mimetype: "audio/ogg",
                ptt: true
            }, { quoted: m });

            fs.unlinkSync(audioPath); // Hapus file setelah dikirim
        } else {
            // **Jika pesan asal berupa teks, balas dengan teks juga**
            await conn.sendMessage(m.chat, { text: aiResponse }, { quoted: m });
        }
    } catch (error) {
        console.error("Error saat mengambil data dari API:", error);
    }
};

module.exports = handler;