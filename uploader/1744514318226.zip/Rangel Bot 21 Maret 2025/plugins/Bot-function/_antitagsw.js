let handler = (m) => m;

handler.before = async function (m, { conn }) {
 
  const isAntiMentionGroup = m.isGroup ? db.data.chats[m.chat].antisticker : false; 
  const isHanMedia = m.mtype;

  let mentionedGroups = Array.isArray(m.mentionByTag) ? 
                        m.mentionByTag.filter(jid => jid.endsWith("@g.us")) : [];

  if (m.isGroup && isAntiMentionGroup && mentionedGroups.length > 0) {
    if (m.isAdmin) {
      return m.reply('😎 Kamu admin grup, jadi status penyebutan grup ini tidak akan dihapus!');
    }
    if (!m.isBotAdmin) return m.reply('Bot bukan admin, jadi tidak bisa menghapus status penyebutan grup!');
    
    if (m.isBotAdmin) { 
      await m.reply(`\`\`\`「 Status penyebutan grup terdeteksi 」\`\`\`\nMaaf, saya akan mengambil tindakan sesuai pengaturan.`);
      await new Promise(resolve => setTimeout(resolve, 1000)); 

      await conn.sendMessage(m.chat, { 
        delete: { 
          remoteJid: m.chat, 
          fromMe: false, 
          id: m.key.id, 
          participant: m.key.participant || m.participant 
        }
      });
    }
  }
};

module.exports = handler;