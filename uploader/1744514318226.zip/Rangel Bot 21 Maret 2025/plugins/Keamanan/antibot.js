let handler = async (m, {  conn, q, args, isOwner, setReply }) => {
  const isAntiBot = m.isGroup ? db.data.chats[m.chat].antibot : false;
  if (!m.isGroup) return mess.only.group()
  if (!m.isAdmin) return mess.only.admin();
  if (!m.isBotAdmin) return mess.only.badmin();
  if (args[0] === "on" || args[0] === "enable" || args[0] === "1") {
    if (isAntiBot) return setReply("Sudah aktif!!");
    db.data.chats[m.chat].antibot = true;
    setReply("Sukses mengaktifkan antibot!");
  } else if (args[0] === "off" || args[0] === "disable" || args[0] === "0") {
    if (!isAntiBot) return setReply("Udah off!!");
    db.data.chats[m.chat].antibot = false;
    setReply("Sukses mematikan antibot!");
  } else if (!q) {
    setReply("Pilih on atau off");
  }
};

handler.tags = ["group"];
handler.command = ["antibot"];
handler.noCmdPrivate = true;
handler.admin = true;

module.exports = handler;