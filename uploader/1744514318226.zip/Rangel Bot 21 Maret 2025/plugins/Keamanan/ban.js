const { clearAllBan, addBanned, unBanned, cekBannedUser } = require("../../lib/banned")

let handler = async (m, { conn, isOwner, setReply, q }) => {
  const ban = db.data.banned;
  const ownerNumber = [
    `${nomerOwner}@s.whatsapp.net`,
    `6285156137902@s.whatsapp.net`,
    `${conn.user.jid}`,
  ];
  const Tnow = (new Date() / 1000).toFixed(0);
  let alasan = "";
  if (!m.isAdmin && !isOwner) return setReply("hanya admin dan owner");
  if (q.startsWith("+")) {
    let woke = q.replace(new RegExp("[()+-/ +/]", "gi"), "");
    let Name = await conn.getName(woke);
    if (cekBannedUser(woke, ban)) return setReply("User sudah di ban sebelumnya");
    addBanned(Name, calender, woke, alasan, ban);
    setReply(`Berhasil banned ${woke}`);
  } else if (m.users) {
    let alasan = m.mentionByReply ? q : m.mentionByTag ? q.split("|")[1] : "";
    if (alasan == undefined) alasan = "Tidak ada";
    let Nomer = `${m.users.split("@")[0]}`;
    if (cekBannedUser(Nomer, ban)) return setReply("User sudah di ban sebelumnya");
    let Name = await conn.getName(m.users);
    if (ownerNumber.includes(m.users))
      return setReply("Tidak bisa membanned owner");
    addBanned(Name, calender, Nomer, alasan, ban);
    setReply(`Berhasil banned ${m.users.split("@")[0]}`);
  } else setReply("Reply/tag/input nomer targetnya");
};
handler.help = ["repy/tag target"];
handler.tags = ["group"];
handler.command = ["ban", "banned"];
module.exports = handler;