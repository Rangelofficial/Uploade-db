let handler = async (m, {  conn,prefix,q,setReply }) => {
  try {
    // Validasi input
    if (!q) return setReply(`Kirim perintah *${prefix}buylimit* jumlah limit yang ingin dibeli\n\nHarga 1 limit = Rp1000`);
    if (q.includes('-')) return  conn.reply(m.chat, `Jangan menggunakan tanda minus (-)`, m);
    if (isNaN(q)) return  conn.reply(m.chat, `Harus berupa angka`, m);
    
    // Hitung jumlah yang ingin dibeli
    let ane = Number(Math.floor(q) * 1000);
    if (global.db.data.users[m.sender].balance < ane) return  conn.reply(m.chat, `Saldo kamu tidak mencukupi untuk pembelian ini`, m);

    // Proses pembelian
    global.db.data.users[m.sender].balance -= ane;
    global.db.data.users[m.sender].limit += Math.floor(q);

    // Balasan
    setReply(`Pembelian limit sebanyak ${q} berhasil\n\nSisa Saldo : Rp ${global.db.data.users[m.sender].balance.toLocaleString()}\nSisa Limit : ${global.db.data.users[m.sender].limit}`);
  } catch (err) {
    console.error(err);
     conn.reply(m.chat, `Terjadi kesalahan saat memproses pembelian limit.`, m);
  }
};

handler.help = ['buylimit'];
handler.tags = ['limit'];
handler.command = /^(buylimit)$/i;
handler.noCmdStore = true
handler.noCmdPrivate = true

module.exports = handler;
