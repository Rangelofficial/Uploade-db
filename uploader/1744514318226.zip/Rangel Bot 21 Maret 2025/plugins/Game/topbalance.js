let handler = async (m, {  conn }) => {
      let uang = Object.values(db.data.users);
    uang.sort((a, b) => (a.balance < b.balance) ? 1 : -1);
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ?   conn.sendMessage(m.chat, { text: teks, mentions: memberr, contextInfo: { "mentionedJid": memberr }}):  

 conn.sendMessage(m.chat, {mentions: memberr,text: teks, contextInfo: { "mentionedJid": memberr }},{quoted: m})
}
    let top = '🏆 *「 TOP BALANCE GLOBAL 」* 🏆\n\n';
    var arrTop = [];
    var total = 15;
    
    if (uang.length < 15) total = uang.length;

    for (let i = 0; i < total; i++) {
        let positionEmoji = '';
        switch (i) {
            case 0: positionEmoji = '🥇'; break;
            case 1: positionEmoji = '🥈'; break;
            case 2: positionEmoji = '🥉'; break;
            default: positionEmoji = '⭐'; break;
        }

        top += `${positionEmoji} *${i + 1}. wa.me/${uang[i].id.split("@")[0]}*\n💰 Balance: $${uang[i].balance.toLocaleString()}\n\n`;
        arrTop.push(uang[i].id);
    }

    mentions(top, arrTop, true);
};

handler.help = ['topbalance', 'topglobal'];
handler.tags = ['info'];
handler.command = /^(topbalance|topglobal)$/i;
handler.noCmdStore = true
handler.onlyGroup = true
module.exports = handler;
