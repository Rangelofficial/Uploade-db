let handler = async (m, {  conn,setReply, q }) => {
  try {
    // Validasi input
      let target = m.mentionedJid && m.mentionedJid[0] 
      ? m.mentionedJid[0] 
      : m.quoted && m.quoted.sender 
      ? m.quoted.sender 
      : m.sender;
    if (!q || !target) return  conn.reply(m.chat, `Reply target dan masukkan jumlah saldo yang ingin diberikan\n\nContoh: .addbalance 5000`, m);
    if (isNaN(q)) return  conn.reply(m.chat, `Jumlah balance harus berupa angka`, m);
      
    let jumlah = Math.floor(Number(q));
    global.db.data.users[target].balance += jumlah;

     conn.reply(m.chat, `Berhasil menambahkan balance sebesar Rp ${jumlah.toLocaleString()} ke nomor ${target.split("@")[0]}`, m);
  } catch (err) {
    console.error(err);
     conn.reply(m.chat, `Terjadi kesalahan saat memberikan saldo. Pastikan pengguna sudah terdaftar di database bot.`, m);
  }
};

handler.help = ['givesaldo'];
handler.tags = ['owner'];
handler.command = ['givebalance','addbalance','givesaldo']
handler.owner = true; 
handler.noCmdStore = true
handler.noCmdPrivate = true
module.exports = handler;
