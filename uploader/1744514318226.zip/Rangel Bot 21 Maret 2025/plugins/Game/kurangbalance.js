let handler = async (m, {  conn, q, }) => {
  try {
    // Validasi input
    if (!q || !m.mentionByReply) return  conn.reply(m.chat, `Reply target dan masukkan jumlah saldo yang ingin dikurangi\n\nContoh: .kurangsaldo 5000`, m);
    if (isNaN(q)) return  conn.reply(m.chat, `Jumlah saldo harus berupa angka`, m);

    // Proses pengurangan saldo
    let target = m.mentionByReply;
    let jumlah = Math.floor(Number(q));

    if (global.db.data.users[target].balance < jumlah) {
      return  conn.reply(m.chat, `Saldo pengguna tidak mencukupi untuk dikurangi sebesar Rp ${jumlah.toLocaleString()}`, m);
    }

    global.db.data.users[target].balance -= jumlah;

    // Balasan sukses
     conn.reply(m.chat, `Berhasil mengurangi saldo sebesar Rp ${jumlah.toLocaleString()} dari nomor ${target.split("@")[0]}`, m);
  } catch (err) {
    console.error(err);
     conn.reply(m.chat, `Terjadi kesalahan saat mengurangi saldo. Pastikan pengguna sudah terdaftar di database bot.`, m);
  }
};

handler.help = ['kurangsaldo'];
handler.tags = ['owner'];
handler.command = /^(kurangbalance)$/i;
handler.owner = true; 
handler.noCmdStore = true
handler.noCmdPrivate = true
module.exports = handler;
