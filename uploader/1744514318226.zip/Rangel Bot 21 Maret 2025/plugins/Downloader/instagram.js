const axios = require("axios");

let handler = async (m, { text, conn }) => {
  if (!text) return conn.reply(m.chat, "Masukkan URL Instagram!", m);
  
  try {
    let apiKey = Neoxr
    let url = `https://api.neoxr.eu/api/ig-fetch?url=${encodeURIComponent(text)}&apikey=${apiKey}`;

    let response = await axios.get(url);
    let result = response.data;

    if (!result.status || !result.data.length) {
      return conn.reply(m.chat, "Gagal mengambil data. Coba lagi dengan URL yang benar!", m);
    }

    for (let media of result.data) {
      if (media.type === "mp4") {
        await conn.sendFile(m.chat, media.url, "instagram.mp4", "Berikut adalah video Instagram yang Anda minta.", m);
      } else {
        await conn.sendFile(m.chat, media.url, "instagram.jpg", "Berikut adalah gambar Instagram yang Anda minta.", m);
      }
    }
  } catch (err) {
    console.error(err);
    conn.reply(m.chat, "Terjadi kesalahan saat mengambil data dari Instagram!", m);
  }
};

handler.command = ["ig", "igdl", "instagram"];
handler.help = ["igdl <url>"];
handler.tags = ["downloader"];

module.exports = handler;