const axios = require("axios");

let handler = async (m, { text, conn }) => {
  if (!text) return conn.reply(m.chat, "Masukkan URL Videy!", m);

  try {
    let apiKey = Neoxr
    let url = `https://api.neoxr.eu/api/videy?url=${encodeURIComponent(text)}&apikey=${apiKey}`;
    
    let response = await axios.get(url);
    
    if (response.data.status && response.data.data?.url) {
      let videoUrl = response.data.data.url;
      await conn.sendMessage(m.chat, { video: { url: videoUrl }, caption: "Berikut video dari Videy!" }, { quoted: m });
    } else {
      conn.reply(m.chat, "Gagal mengambil data. Pastikan URL Videy valid!", m);
    }
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, "Terjadi kesalahan saat mengunduh video!", m);
  }
};

handler.command = ["videy"];
handler.help = ["videy <url>"];
handler.tags = ["downloader"];
handler.description = ["Unduhan video dari Videy"];
module.exports = handler;