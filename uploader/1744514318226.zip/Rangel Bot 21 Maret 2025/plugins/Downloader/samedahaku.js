const { getLatest, searchAnime, getAnimeDetail, getEpisodeLinks } = require("../../lib/Samedahaku");

let handler = async (m, { text }) => {
    if (!text) {
        return m.reply(
            `*Pilih opsi Samehadaku:*\n\n` +
            `🔍 *Search:* \`samedahaku search|judul anime\`\n` +
            `🔥 *Latest:* \`samedahaku latest\`\n` +
            `📖 *Detail:* \`samedahaku detail|url\`\n` +
            `📥 *Episode:* \`samedahaku episode|url\`\n`
        );
    }

    let [cmd, param] = text.split("|").map(v => v.trim());

    if (cmd === "search") {
        if (!param) return m.reply("⚠️ Masukkan judul anime!\n\nContoh: `samedahaku search|one piece`");
        let data = await searchAnime(param);
        if (data.length === 0) return m.reply("❌ Anime tidak ditemukan!");
        return m.reply("🔎 *Hasil Pencarian:*\n\n" + data.map(a => `📌 *${a.title}*\n🔗 ${a.url}`).join("\n\n"));
    } 
    
    if (cmd === "latest") {
        let data = await getLatest();
        return m.reply("🔥 *Anime Terbaru:*\n\n" + data.map(a => `📌 *${a.title}*\n🔗 ${a.url}`).join("\n\n"));
    }

    if (cmd === "detail") {
        if (!param) return m.reply("⚠️ Masukkan URL anime!\n\nContoh: `samedahaku detail|https://samehadaku.email/...`");
        let data = await getAnimeDetail(param);
        return m.reply(`📖 *Detail Anime:*\n\n🎬 *${data.metadata.title}*\n🔗 ${param}`);
    }

    if (cmd === "episode") {
        if (!param) return m.reply("⚠️ Masukkan URL episode!\n\nContoh: `samedahaku episode|https://samehadaku.email/...`");
        let data = await getEpisodeLinks(param);
        return m.reply("📥 *Link Download:*\n\n" + JSON.stringify(data.download, null, 2));
    }

    return m.reply("⚠️ Perintah tidak dikenali! Coba ketik `samedahaku` untuk melihat daftar perintah.");
};

handler.command = /^samedahaku$/i;
module.exports = handler;