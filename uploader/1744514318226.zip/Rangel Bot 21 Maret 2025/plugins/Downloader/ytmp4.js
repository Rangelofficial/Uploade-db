const fetch = require('node-fetch');

const handler = async (m, { conn, args }) => {
    let url = args[0];
    if (!url) return m.reply('Masukkan URL YouTube yang ingin diunduh!');
mess.wait()
    let apiKey = Neoxr
    let apiUrl = `https://api.neoxr.eu/api/youtube?url=${encodeURIComponent(url)}&type=video&quality=720p&apikey=${apiKey}`;

    try {
        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) {
            return m.reply('Gagal mengambil data, pastikan URL valid.');
        }

        let caption = `${gris1}*YouTube MP4 Downloader*\n\n` +
                      `🎥 *Judul:* ${json.title}\n` +
                      `📺 *Channel:* ${json.channel}\n` +
                      `🕒 *Durasi:* ${json.fduration}\n` +
                      `👁️ *Views:* ${json.views}\n` +
                      `📅 *Dipublikasikan:* ${json.publish}\n` +
                      `🎞️ *Kualitas:* ${json.data.quality}\n` +
                      `📦 *Ukuran:* ${json.data.size}${gris1}`;

       /* await conn.sendMessage(m.chat, {
            image: { url: json.thumbnail },
            caption: caption
        }, { quoted: m });*/

        await conn.sendMessage(m.chat, {
            video: { url: json.data.url },
            mimetype: 'video/mp4',
            caption: caption
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mengunduh video.');
    }
};

handler.help = ['ytmp4 <url>'];
handler.tags = ['downloader'];
handler.command = /^ytmp4$/i;
handler.limit = true
module.exports = handler;