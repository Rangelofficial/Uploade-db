const axios = require("axios");

let handler = async (m, { text, conn }) => {
  if (!text) return conn.reply(m.chat, "Masukkan URL CapCut!", m);

  try {
    let apiKey = Neoxr
    let url = `https://api.neoxr.eu/api/capcut?url=${encodeURIComponent(text)}&apikey=${apiKey}`;
    
    let response = await axios.get(url);
    
    if (response.data.status && response.data.data?.url) {
      let videoUrl = response.data.data.url;
      await conn.sendMessage(m.chat, { video: { url: videoUrl }, caption: "Berikut hasil unduhan CapCut!" }, { quoted: m });
    } else {
      conn.reply(m.chat, "Gagal mengambil data. Pastikan URL CapCut valid!", m);
    }
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, "Terjadi kesalahan saat mengunduh video!", m);
  }
};

handler.command = ["capcut", "capcutdl"];
handler.help = ["capcutdl <url>"];
handler.tags = ["downloader"];
handler.description = ["Unduhan video dari CapCut"];
module.exports = handler;