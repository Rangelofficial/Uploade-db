const spotify = require('../../lib/Spotify'); 
const axios = require('axios'); 
const { getBuffer } = require('../../lib/myfunc');
const handler = async (m, { conn, args, prefix }) => {
    if (!args[0]) {
        return m.reply(`Gunakan format:\n${prefix}spotify <judul / link>\n\nContoh:\n${prefix}spotify Shape of You\natau\n${prefix}spotify https://open.spotify.com/track/1boDpcUlP96RxGu6l7M4YW`);
    }
mess.wait()
    const query = args.join(' ');

    if (query.startsWith('https://open.spotify.com/track/')) {
        try {
            const info = await spotify.getInfo(query);
            if (!info.status) {
                return m.reply(`Error: ${info.msg}`);
            }

            const downloadUrl = await spotify.down(query);
            if (!downloadUrl) {
                return m.reply('Tidak dapat mengunduh lagu. Mungkin lagu ini tidak tersedia.');
            }

            const response = await axios.get(downloadUrl, { responseType: 'arraybuffer' });
            const audioBuffer = Buffer.from(response.data);
let thumbnailBuffer = await getBuffer(info.thumbnail);
            const message = `${gris1}🎵 *Spotify Track Info* 🎵\n\n🎧 *Title:* ${info.title}\n🎤 *Artist:* ${info.artist}\n🕒 *Duration:* ${info.duration}\n🔗 *Link:* ${info.url}\n📷 *Thumbnail:* ${info.thumbnail}\n🎶 *Preview:* ${info.preview || 'Tidak tersedia'} ${gris1}`;

  let contextInfo = {
  forwardingScore: 50,
  isForwarded: false,
  externalAdReply: {
    showAdAttribution: false,
    title: info.title,
    body: info.duration,
    mediaType: 1,
    renderLargerThumbnail: true,
    sourceUrl: info.url,
    thumbnailUrl: info.thumbnail,
  },
};

conn.sendMessage(
  m.chat,
  { text: message, contextInfo },
  { quoted: m }
);


            const fileName = `${info.title || 'audio'}.mp3`;
            await conn.sendMessage(
                m.chat,
                {
                    audio: audioBuffer,
                    mimetype: 'audio/mp4',
                    fileName,
                },
                { quoted: m }
            );
        } catch (error) {
            console.error('Error in Spotify URL handler:', error.message);
            m.reply('Terjadi kesalahan saat memproses lagu dari URL Spotify.');
        }
    } else {
 
        try {
            const result = await spotify.search(query, 5); 
            if (!result.status) {
                return m.reply(`Error: ${result.msg}`);
            }
            let message = `🎵 *Spotify Search Results* 🎵\n\n`;
            result.data.forEach((track, index) => {
                message += `${index + 1}. 🎧 *Title:* ${track.title}\n🎤 *Artist:* ${track.artist}\n🕒 *Duration:* ${track.duration}\n🔗 *Link:* ${track.url}\n\n`;
            });
            message += `Ketikkan nomor atau gunakan link untuk mendapatkan detail dan audio!`;

            m.reply(message);
        } catch (error) {
            console.error('Error in Spotify search handler:', error.message);
            m.reply('Terjadi kesalahan saat mencari lagu di Spotify.');
        }
    }
};

handler.help = ['spotify'];
handler.tags = ['spotify'];
handler.command = ['spotify','spotifydl'];
handler.noCmdPrivate = true;
handler.noCmdStore = true;
handler.description = ['Cari atau unduh lagu dari Spotify menggunakan judul atau URL'];

module.exports = handler;