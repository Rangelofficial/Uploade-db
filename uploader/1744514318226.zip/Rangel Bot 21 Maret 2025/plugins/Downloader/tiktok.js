const axios = require('axios');

let handler = async (m, { args, conn }) => {
    if (!args[0]) return m.reply('Masukkan link TikTok! Contoh: .tiktok https://vt.tiktok.com/ZS24ShS1n/');

    const url = args[0];
    if (!url.match(/(https:\/\/vt.tiktok.com\/|https:\/\/www.tiktok.com\/)/gi)) {
        return m.reply('Masukkan link TikTok yang valid.');
    }

    mess.wait();

    try {
        const response = await axios.get(`https://api.neoxr.eu/api/tiktok?url=${url}&apikey=${Neoxr}`);
        const json = response.data;

        if (!json.status) {
            return m.reply('🚫 Gagal mengambil data dari TikTok.');
        }

        const {
            id,
            caption,
            author,
            statistic,
            music,
            published,
            photo,
            audio,
            video,
            videoWM
        } = json.data;

        let message = `🎥 *TikTok Video Download (No Watermark)*\n\n`;
        message += `🆔 *ID Video*: ${id}\n`;
        message += `📌 *Deskripsi*: ${caption}\n`;
        message += `📅 *Diunggah pada*: ${new Date(published * 1000).toLocaleString()}\n`;
        message += `👤 *Author*: ${author.nickname} (@${author.uniqueId})\n`;
        message += `👀 *Views*: ${statistic.views}\n`;
        message += `❤️ *Likes*: ${statistic.likes}\n`;
        message += `💬 *Komentar*: ${statistic.comments}\n`;
        message += `🔄 *Dibagikan*: ${statistic.shares}\n`;
        message += `💾 *Disimpan*: ${statistic.saved}\n`;
        message += `🎵 *Music*: ${music.title} - ${music.author}\n`;
        message += `🎼 *Link Music*: ${music.url}\n\n`;

        let isMediaSent = false;

      
        if (video) {
            await conn.sendMessage(m.chat, {
                video: { url: video },
                caption: message
            },{quoted:m});
            isMediaSent = true;
        } else if (videoWM) {
            
            await conn.sendMessage(m.chat, {
                video: { url: videoWM },
                caption: message
            });
            isMediaSent = true;
        }

      
        if (!isMediaSent && Array.isArray(photo) && photo.length > 0) {
            for (let i = 0; i < photo.length; i++) {
                await conn.sendMessage(m.chat, {
                    image: { url: photo[i] },
                    caption: i === 0 ? "Poto awalan saja" : ""
                });
            }
        }

    
        if (audio) {
            await conn.sendMessage(m.chat, {
                audio: { url: audio },
                mimetype: 'audio/mp4',
                fileName: `${music.title}.mp3`
            }, { quoted: m });
        }

    } catch (error) {
        console.error("Error fetching TikTok content:", error);
        m.reply('❌ Terjadi kesalahan saat mengunduh konten TikTok.');
    }
};

handler.help = ['tiktok <link>'];
handler.tags = ['downloader'];
handler.limit = true;
handler.command = ["tiktok", "tt"];

module.exports = handler;