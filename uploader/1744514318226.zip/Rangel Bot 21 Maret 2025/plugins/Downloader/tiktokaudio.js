const axios = require('axios');

let handler = async (m, { args, conn }) => {
    if (!args[0]) return m.reply('Masukkan link TikTok! Contoh: .tiktok https://vt.tiktok.com/ZS24ShS1n/');
    
    const url = args[0];
    if (!url.match(/(https:\/\/vt.tiktok.com\/|https:\/\/www.tiktok.com\/)/gi)) {
        return m.reply('Masukkan link TikTok yang valid.');
    }

    mess.wait();

    try {
        const response = await axios.get(`https://api.agatz.xyz/api/tiktok?url=${encodeURIComponent(url)}`);
        const data = response.data.data;
        const musicInfo = data.music_info;

        if (!musicInfo || !musicInfo.url) {
            return m.reply('Audio tidak tersedia.');
        }

        const caption = `${gris1}🎵 *Detail Lagu TikTok*\n
📌 *Judul:* ${musicInfo.title}
👤 *Artis:* ${musicInfo.author}
📀 *Album:* ${musicInfo.album || 'Unknown'}
📅 *Diupload:* ${data.taken_at}
📍 *Region:* ${data.region}
👀 *Views:* ${data.stats.views}
❤️ *Likes:* ${data.stats.likes}
💬 *Komentar:* ${data.stats.comment}
🔄 *Shares:* ${data.stats.share}
⬇️ *Downloads:* ${data.stats.download}
🎧 *Audio:* ${musicInfo.url}${gris1}`;

        await conn.sendMessage(m.chat, { audio: { url: musicInfo.url }, mimetype: 'audio/mp4', fileName: `${musicInfo.title}.mp3` }, { quoted: m });
        await m.reply(caption);
    } catch (error) {
        console.error("Error fetching TikTok audio:", error);
        m.reply('Terjadi kesalahan saat mengunduh audio TikTok.');
    }
};

handler.help = ['tiktokaudio <link>'];
handler.tags = ['downloader'];
handler.command = ["tiktokaudio", "ttmp3", "ttaudio"];
handler.description = ['Mengunduh audio dari TikTok.'];

module.exports = handler;