const axios = require("axios");

let handler = async (m, { text, conn }) => {
  if (!text) return conn.reply(m.chat, "Masukkan URL Play Store!", m);

  try {
    let apiKey = Neoxr
    let url = `https://api.neoxr.eu/api/playstore?url=${encodeURIComponent(text)}&apikey=${apiKey}`;
    
    let response = await axios.get(url);
    
    if (response.data.status && response.data.data) {
      let { icon, name, version, developer, publish } = response.data.data;
      let files = response.data.files || [];
      
      let caption = `📱 *${name}*\n🔢 *Versi:* ${version}\n👨‍💻 *${developer}*\n📅 *${publish}*`;
      await conn.sendMessage(m.chat, { image: { url: icon }, caption: caption }, { quoted: m });

      for (let file of files) {
        await conn.sendMessage(m.chat, { document: { url: file.url }, mimetype: "application/vnd.android.package-archive", fileName: file.filename }, { quoted: m });
      }
    } else {
      conn.reply(m.chat, "Gagal mengambil data. Pastikan URL Play Store valid!", m);
    }
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, "Terjadi kesalahan saat mengambil data!", m);
  }
};

handler.command = ["playstore"];
handler.help = ["playstore <url>"];
handler.tags = ["downloader"];
handler.description = ["Unduhan aplikasi dari Play Store"];
module.exports = handler;