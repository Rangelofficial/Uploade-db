/* 
  ────────「 *RANGELOFFICIAL* 」──────── 
  Powered by *EhanzDhoanx* × *MENHERA MD* 
  Copyright © Raihan Fadillah 
  Instagram: @econndhonax 

  ⚠️ *Jangan hapus watermark ini!* 
  Dukunganmu sangat berarti untuk kami! 
  ──────────────────────────────── 
*/

const fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Gunakan format: ${usedPrefix + command} <url_facebook>`);

  try {
    let apiKey = Neoxr
    let res = await fetch(`https://api.neoxr.eu/api/fb?url=${encodeURIComponent(text)}&apikey=${apiKey}`);
    let json = await res.json();

    if (!json.status || !json.data.length) return m.reply('❌ Gagal mendapatkan video. Coba lagi dengan URL lain.');

    let videoHD = json.data.find(v => v.quality === "HD") || json.data[0]; // Pilih kualitas HD jika ada, jika tidak pilih yang pertama

    m.reply(`🔹 *Mengunduh video...*`);
    await conn.sendFile(m.chat, videoHD.url, 'facebook.mp4', `✅ *Berhasil mengunduh video!*\n📌 *Kualitas:* ${videoHD.quality}`, m);
  } catch (e) {
    console.error(e);
    m.reply('⚠️ Terjadi kesalahan saat mengambil data. Coba lagi nanti.');
  }
};

handler.command = ['fbdl', 'fb', 'facebook'];
handler.help = ['facebook'];
handler.tags = ['downloader'];
handler.limit = true;

module.exports = handler;