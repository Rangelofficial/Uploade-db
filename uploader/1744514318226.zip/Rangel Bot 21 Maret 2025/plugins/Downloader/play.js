const fetch = require('node-fetch');

const handler = async (m, { conn, args }) => {
    let query = args.join(" ");
    if (!query) return m.reply('Masukkan judul lagu yang ingin dicari!');
mess.wait()
    let apiKey = Neoxr
    let apiUrl = `https://api.neoxr.eu/api/play?q=${encodeURIComponent(query)}&apikey=${apiKey}`;

    try {
        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) {
            return m.reply('Gagal menemukan lagu, coba dengan kata kunci lain.');
        }

        let caption = `${gris1}*🎵 Play Audio 🎵*\n\n` +
                      `🎶 *Judul:* ${json.title}\n` +
                      `📺 *Channel:* ${json.channel}\n` +
                      `🕒 *Durasi:* ${json.fduration}\n` +
                      `👁️ *Views:* ${json.views}\n` +
                      `📅 *Dipublikasikan:* ${json.publish}\n` +
                      `🎼 *Kualitas:* ${json.data.quality}\n` +
                      `📦 *Ukuran:* ${json.data.size}\n\n📥 Audio Sedang Dikirim...${gris1}`;
let contextInfo = {
  forwardingScore: 50,
  isForwarded: false,
  externalAdReply: {
    showAdAttribution: false,
    title: json.title,
    body: json.publish,
    mediaType: 1,
    renderLargerThumbnail: true,
    sourceUrl: json.channel,
    thumbnailUrl: json.thumbnail,
  },
};
 conn.sendMessage(
  m.chat,
  { text: caption, contextInfo },
  { quoted: m }
);
        await conn.sendMessage(m.chat, {
            audio: { url: json.data.url },
            mimetype: 'audio/mpeg',
            fileName: json.data.filename,
            ptt: false
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mencari lagu.');
    }
};

handler.help = ['playaudio <judul lagu>'];
handler.tags = ['downloader'];
handler.command = ['play','playaudio']
handler.limit = true
module.exports = handler;