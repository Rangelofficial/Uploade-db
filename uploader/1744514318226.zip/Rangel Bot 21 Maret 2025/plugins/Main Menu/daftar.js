const fetch = require('node-fetch');

async function sendVerificationEmail(userEmail, verificationCode) {
  try {
    const response = await fetch("https://formspree.io/f/mqaegrwl", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: userEmail,
        message: `📩 *Terima Kasih Telah Mendaftar!*

Kami senang menyambut Anda. Gunakan kode verifikasi di bawah ini untuk melanjutkan proses pendaftaran:

*Kode Verifikasi Anda*: ${verificationCode}

Segera masukkan kode ini untuk mengaktifkan akun Anda. Jika Anda membutuhkan bantuan, jangan ragu untuk menghubungi kami.

Terima kasih telah bergabung bersama kami!`,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Formspree Error: ${errorText}`);
    }

    return true;
  } catch (error) {
    console.error("Error sending email:", error.message);
    return false;
  }
}



function generateVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

const handler = async (m, { text, usedPrefix, command, setReply }) => {
  let user = global.db.data.users[m.sender];

  if (user && user.registered === true) {
    return m.reply(`[💬] Kamu sudah terdaftar.`);
  }

  const emailReg = /(.+)[,|.](.+)[,|.](\d+)/i;
  const nameReg = /(.+)[,|.](\d+)/i;

  let email, name, age;
  if (emailReg.test(text)) {
    const [_, e, n, a] = text.match(emailReg);
    email = e;
    name = n;
    age = parseInt(a);
  } else if (nameReg.test(text)) {
    const [_, n, a] = text.match(nameReg);
    name = n;
    age = parseInt(a);
  } else {
    return m.reply(
      `⚠️ Format salah. Gunakan salah satu format berikut:\n` +
        `- *${usedPrefix + command} email.nama.umur*\n` +
        `- *${usedPrefix + command} nama.umur*\n` +
        `Jika Anda belum mengerti, silakan ketik *.caradaftar*.`
    );
  }

  if (email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return m.reply(`❌ *Email Tidak Valid!*\nPastikan email yang Anda masukkan sesuai format, contoh:\nexample@gmail.com`);
    }
  }

  if (!name || !age) {
    return m.reply(`⚠️ Semua field harus diisi dengan benar.`);
  }

  if (isNaN(age)) {
    return m.reply("⚠️ Usia harus berupa angka yang valid.");
  }

  if (age > 40) {
    return m.reply(`❌ *Pendaftaran Ditolak!*\nMaaf, batas usia maksimal adalah 40 tahun.`);
  }

  if (age < 5) {
    return m.reply(`❌ *Pendaftaran Ditolak!*\nMaaf, usia minimal adalah 5 tahun.`);
  }

  const emailAlreadyRegistered = email && Object.values(global.db.data.users).some((user) => user.email === email);
  if (emailAlreadyRegistered) {
    return m.reply(`❌ *Email Sudah Terdaftar!*\nGunakan email lain untuk mendaftar.`);
  }

  const nameAlreadyRegistered = Object.values(global.db.data.users).some((user) => user.name && user.name.toLowerCase() === name.toLowerCase());
  if (nameAlreadyRegistered) {
    return m.reply(`❌ *Nama Sudah Digunakan!*\nGunakan nama lain untuk mendaftar.`);
  }

  const verificationCode = generateVerificationCode();

  if (!global.db.data.users[m.sender]) {
    global.db.data.users[m.sender] = {};
  }

  user = global.db.data.users[m.sender];
  user.email = email || null;
  user.name = name;
  user.age = age;
  user.verificationCode = email ? verificationCode : null;
  user.registered = !email;

  if (email) {
    const emailSent = await sendVerificationEmail(user.email, verificationCode);
    if (emailSent) {
      return setReply(`
📩 *Kode Verifikasi Telah Dikirim!*

Kami telah mengirimkan *kode verifikasi* ke email Anda.  
Silakan cek *inbox* atau *folder spam* untuk menemukan email dari kami.

✨ *Langkah Berikutnya*:
Ketik perintah berikut untuk memverifikasi akun Anda:  
*verify <kode>*  
Contoh: *.verify 123456*

Jika Anda tidak menerima email, harap periksa kembali alamat email Anda.
`);
    } else {
      return m.reply(`❌ *Gagal Mengirim Email!*\nCoba lagi nanti.`);
    }
  }

  return setReply(`
🎉 *Pendaftaran Berhasil!*

Selamat, akun Anda telah terdaftar dengan informasi berikut:  
- Nama: ${name}  
- Usia: ${age}  

Terima kasih telah bergabung bersama kami!`);
};

handler.help = ["daftar <email>,<nama>,<umur>", "daftar <nama>,<umur>"];
handler.tags = ["daftar"];
handler.command = /^(daftar|register)$/i;

module.exports = handler;