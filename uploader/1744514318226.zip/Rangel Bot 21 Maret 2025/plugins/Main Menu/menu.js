const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");
const { generateWAMessageFromContent,prepareWAMessageMedia, proto } = require("baileys");

let handler = async (m, { conn, q, isOwner, setReply,dmusic,onlyGroup,ucapanWaktu }) => {
 
    if (!q) {
    function toMonospace(text) {
      return `${text}`;
    }
    const timeWib = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    moment.tz.setDefault("Asia/Jakarta").locale("id");

    const more = String.fromCharCode(8206);
    const readmore = more.repeat(4001); 
    let dt = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a");
    const ucapanWaktu = "Selamat " + dt.charAt(0).toUpperCase() + dt.slice(1);

    let dot = new Date(new Date() + 3600000);
    const dateIslamic = Intl.DateTimeFormat("id-TN-u-ca-islamic", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(dot);
// TAHUN BARU
let sekarang = moment().tz('Asia/Jakarta');
let tahunDepan = sekarang.year() + 1;
let tahunBaru = moment.tz(`${tahunDepan}-01-01 00:00:00`, 'Asia/Jakarta');
let selisih = moment.duration(tahunBaru.diff(sekarang));
let hari = Math.floor(selisih.asDays());
let jam = selisih.hours();
let menit = selisih.minutes();
let detik = selisih.seconds();
let ucapanTahunBaru = `Menuju tahun baru: ${hari} hari, ${jam} jam, ${menit} menit, dan ${detik} detik lagi.`;
// Info Lebaran 2025
let hariIni = moment().tz("Asia/Jakarta"); 
let lebaran = moment("2025-03-30").tz("Asia/Jakarta"); // Perkiraan Idul Fitri 1446 H
let sisaHari = lebaran.diff(hariIni, 'days');
    const data = global.db.data.others["newinfo"];
    const user = global.db.data.users[m.sender];
    const info = data ? data.info : "";
    const block = await conn.fetchBlocklist();
    const timeInfo = data ? clockString(new Date() - data.lastinfo) : "tidak ada";
const publik = `${global.public}`
  
    
  const pluginsFolderPath = "./plugins";

  let forOwner = ['Bot-function']
  let forUser = ['Bot-function','Game_answer','Game_hints','Case']
  const excludedFolders = isOwner ? forOwner : forUser; 
   function listFolders(folderPath, excludedFolders = []) {
        let result = '';
        const files = fs.readdirSync(folderPath);

        files.forEach((file) => {
            const filePath = path.join(folderPath, file);
            const stat = fs.statSync(filePath);

            
            if (stat.isDirectory() && !excludedFolders.includes(file)) {
                result += `*-* menu ${file} \n`; 
                result += listFolders(filePath, excludedFolders); 
            }
        });

        return result;
    }

    const outputStringFolder = listFolders(pluginsFolderPath, excludedFolders);
function countJSFiles(folderPath) {
      try {
        const files = fs.readdirSync(folderPath);
        let jsFileCount = 0;

        files.forEach((file) => {
          const filePath = path.join(folderPath, file);
          const stat = fs.statSync(filePath); 

          if (stat.isDirectory()) {
            if (!excludedFolders.includes(file)) {
              jsFileCount += countJSFiles(filePath); 
            }
          } else {
            if (path.extname(file) === ".js") {
              jsFileCount++; 
            }
          }
        });

        return jsFileCount;
      } catch (error) {
        console.error("Error:", error);
        return 0; 
      }
    }

 
    const totalJSFiles = countJSFiles(pluginsFolderPath);

    
    const totalCase = () => {
      try {
        const mytext = fs.readFileSync("./plugins/Case/case.js", "utf8");
      const numCases = (mytext.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || [])
        .length;
      return numCases;
    } catch (err) {
      console.error("Error:", err);
      return 0;
    }
  };
        
let jid = m.sender.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    
const menuRamadhan = transformText(`
︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥︶𝆹𝅥
🌙 *Marhaban Ya Ramadhan* 🕌  
Hi ${m.pushname}* 🤲✨  

Saya *Rangel Assistant*, siap menemani ibadah dan aktivitas Anda selama bulan Ramadhan.  
Semoga ibadah kita diterima dan penuh keberkahan.  

- 🕌 *Informasi Ramadhan*  
◦ ⏰ ${timeWib} WIB  
◦ 📅 ${dateIslamic}  
◦ 📆 ${week}, ${calender} 
◦ 🕋 *Jadwal Imsakiyah* : Gunakan *.imsakiyah*  
◦ ⏳ *Sisa waktu hingga Lebaran:* ${sisaHari} hari lagi  
◦ 🎊 *Perkiraan Idul Fitri:* Minggu, 30 Maret 2025 

📑 *– List - Menu*
${readmore}
${outputStringFolder}
──────────୨ৎ──────────
silahkan ketik *.menu <namafolder>* Jika Ingin Melihat Daftar Fitur Yang Ada Dalam Masing Masing Folder
`);    
const menu = transformText(`
📊 *Stats :*
┌  ◦ Running on: ${runWith}
│  ◦ Hits Today: ${
    thisHit == undefined
      ? "0"
      : thisHit.toLocaleString() == undefined
      ? "0"
      : thisHit.toLocaleString()
  }
│  ◦ Features: ${totalJSFiles}
│  ◦ Errors: ${db.data.listerror.length} 
│  ◦ Users: ${Object.keys(db.data.users).length}
│  ◦ Banned: ${db.data.banned.length} 
│  ◦ Blocked: ${block.length}
│  ◦ Premium: ${Object.values(db.data.users).filter((u) => u.premiumTime !== 0).length}
└  ◦ Blocked Commands: ${db.data.blockcmd.length} 

🕒 *Date & Time :* 
┌  ◦ ${week}, ${calender} 
│  ◦ ${timeWib} WIB
│  ◦ ${dateIslamic}
└  ◦ ${ucapanTahunBaru}

⚠ *Warning :*
┌  ◦ 🅟 : Premium
│  ◦ 🅛 : Limit
│  ◦ 🅔 : Error
└  ◦ 🅑 : Blocked

🆕 *Latest Update :*
┌ ◦ ${info}
╰ ◦ di update ${timeInfo} yang lalu

📑 *– List - Menu*
${readmore}
${outputStringFolder}
──────────୨ৎ──────────
silahkan ketik *.menu <namafolder>* Jika Ingin Melihat Daftar Fitur Yang Ada Dalam Masing Masing Folder
`)

var setmenu = db.data.settings['settingbot'].setmenu

if (setmenu === "livelocation") {
conn.relayMessage(m.chat, { liveLocationMessage: { 
degreesLatitude: 35.676570,
degreesLongitude: 139.762148,
caption :menu,
sequenceNumber: 1656662972682001, timeOffset: 8600, 
jpegThumbnail: null,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
containsAutoReply: true,
showAdAttribution: true,
}
}
}
}, {quoted: m})
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
}  else if (setmenu == "ramadhan"){
conn.sendMessage(m.chat, { 
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: true, 
 title: `Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶`,
 body: transformText(`Runtime ${runTime}`),
mediaType: 1,  
renderLargerThumbnail: true,
thumbnailUrl:'https://files.catbox.moe/73jgdg.jpeg',       
sourceUrl: ``
            },
            editKey: { 
                remoteJid: m.sender, 
                id: '6285795718659'  
            }
        },
        text: menuRamadhan,
    }, { quoted: fkontak });
await sleep(1500) 
conn.sendvn(m.chat,'https://raw.githubusercontent.com/Muler-Official/upload-db-media/main/uploader/8b9ef67e08.mp3',m)
} else if (setmenu == "payment"){
let numb = ["7.76","15.48","8.92","10.72","13.48","4.39","5.99","2.56"]
let amont = numb[Math.floor(Math.random() * numb.length)]
conn.relayMessage(m.chat,  {
requestPaymentMessage : {
expiryTimestamp: 0,												
currencyCodeIso4217: 'USD',
amount1000: (amont) * 1000,
requestFrom: `${m.sender.split('@')[0]}@s.whatsapp.net`,
noteMessage: {
extendedTextMessage: {
text : menu,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: true,
}
}
}
}
}
}, {})
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
 } else if (setmenu == "image"){
conn.sendMessage(m.chat, { contextInfo: { externalAdReply: { showAdAttribution: true,
title: 'Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶',
body:`${baileysVersion}`,
previewType:"PHOTO", 
thumbnailUrl: 'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg',
sourceUrl:``
}}, image: fs.readFileSync('./media/image/thumb.jpeg'),caption: menu},
{ quoted: fimage })
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
} else if (setmenu == "toko"){
return onlyGroup()
 } else if (setmenu == "thumbnail"){
conn.sendMessage(m.chat, { contextInfo: {
            externalAdReply: {
                showAdAttribution: true, 
                title: `Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶`,
                body: transformText(`Runtime ${runTime}`),
                mediaType: 1,  
                renderLargerThumbnail: true,
                thumbnailUrl:'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg',
                sourceUrl: ``
            },
            editKey: { 
                remoteJid: m.sender, 
                id: 'some_unique_message_id'  
            }
        },
        text: menu,
    }, { quoted: fimage });
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
} else if (setmenu == "gif"){
conn.sendMessage(m.chat, { video: fs.readFileSync('./media/video/menu.mp4'),
gifPlayback: true,
caption: menu,
 contextInfo: {
 externalAdReply: {
containsAutoReply: true,
mediaType: 1,

renderLargerThumbnail: false,
showAdAttribution: true,
sourceUrl: "https://instagram.com/ehanzdhoanx",
thumbnailUrl: 'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg',
title:'Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶',
body: `${ucapanWaktu} kak ${m.pushname}`,},},}, { quoted: fimage }); 
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
} else if (setmenu == "katalog"){
 const { generateWAMessageFromContent } = require("baileys")
let prep = generateWAMessageFromContent(m.chat, { orderMessage: { 
itemCount: `90000`, status: 500,
surface: 999,
message:menu,
description: '^^',
orderTitle: 'ʙᴇᴊɪʀ ᴅᴇᴋ',
token: '120363212768920223@g.us',
mediaType: 1,
curreyCode: 'IDR',
totalCurrencyCode: 'ʙᴇᴊɪʀ ᴅᴇᴋ',
totalAmount1000: '50000',
sellerJid: '6281316643491@s.whatsapp.net',
thumbnail: fs.readFileSync('./media/image/rangel.jpg'), 
//thumbnaiUrl: pickRandom(fotoRandom)
}}, {contextInfo:{ externalAdReply: {
showAdAttribution: true, 
title: `Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶`,
body: `${week} ${calender}`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl:getRandom(fotoRandom),
sourceUrl: `${web}`}},quoted: fimage})
conn.relayWAMessage(prep)
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
    } else if (setmenu == "document"){
conn.sendMessage(m.chat, {
document: fs.readFileSync("./package.json"),
fileName: wm,
mimetype: "application/vnd.ms-powerpoint",
jpegThumbnail:fs.readFileSync("./media/image/docRangel.jpg"),
caption: menu,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: 'Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶',
body: `Hai  ${ucapanWaktu} kak ${m.pushname}` ,
thumbnail: fs.readFileSync('./media/image/thumb.jpeg'),
thumbnailUrl: 'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg',
sourceUrl:'',
mediaType: 1,
renderLargerThumbnail: true 
}}}, { quoted: m,ephemeralExpiration: 86400});
await sleep(1500) 
conn.sendvn(m.chat,dmusic,m)
} else if (setmenu === "docImage") {
let msg = generateWAMessageFromContent(
  m.chat,
  {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid,
              newsletterName,
              serverMessageId: 145
            },
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.id
            },
            externalAdReply: {
              title: `Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶`,
              body: `Runtime ${runTime}`,
              thumbnailUrl: 'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg',
              sourceUrl: '',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: menu,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "ᴊᴇᴅᴀ ʙᴏᴛ ᴊɪᴋᴀ ᴛɪᴅᴀᴋ ᴍᴇʀᴇꜱᴩᴏɴ",
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            thumbnailUrl: "",
            gifPlayback: true,
            subtitle: "",
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({
              document: fs.readFileSync('./media/image/rangel.jpg'),
              mimetype: "image/png",
              fileLength: 99999999999999,
              jpegThumbnail: fs.readFileSync('./media/image/docRangel.jpg'),
              fileName: `${m.pushname}`,
            }, {
              upload: conn.waUploadToServer
            }))
          }),
          gifPlayback: true,
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [] // No buttons needed
          })
        }),
      }
    }
  },
  { quoted: m }
);


    await conn.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id,
    });
    await sleep(1500)
      conn.sendvn(m.chat,dmusic,m)
    }
  } else {



function displayFilesByFolder(folderPath, folderNameQuery, excludedFolders = [], premium = [], limit = [], error = [], bloked = [], isLast = false) {
    let result = '';  
    const files = fs.readdirSync(folderPath);

    files.forEach((file, index) => {
        const filePath = path.join(folderPath, file);
        const stat = fs.statSync(filePath);
        const isDirectory = stat.isDirectory();
        const folderName = isDirectory ? path.basename(filePath) : '';
        const fileNameWithoutExtension = isDirectory ? '' : path.parse(file).name;
        const isLastFile = index === files.length - 1 && !isDirectory && isLast;

        if (isDirectory && folderName.toLowerCase() === folderNameQuery.toLowerCase()) { 
            result += `▧──··· ${gris}「 ${Ehztext(folderName)} 」${gris}\n`; 
            const isSubLast = index === files.length - 1 && isLast;
            result += displayFilesByFolder(filePath, folderNameQuery, excludedFolders, premium, limit, error, bloked, isSubLast); 
        } else if (!isDirectory) {
            let marker = '';
            if (premium.includes(fileNameWithoutExtension)) {
                marker += ' 🅟';
            }
            if (limit.includes(fileNameWithoutExtension)) {
                marker += ' 🅛';
            }
            if (error.includes(fileNameWithoutExtension)) {
                marker += ' 🅔';
            }
            if (bloked.includes(fileNameWithoutExtension)) {
                marker += ' 🅑'; 
            }

           
     let description = "desk :";
            try {
                const fileContent = require(filePath);
                if (fileContent.description) {
                    description = fileContent.description;
                }
            } catch (error) {
                description = `Error membaca deskripsi: ${error.message}`;
            }

            const transformedFileName = `▸ ${fileNameWithoutExtension}`;
            result += transformText(`${transformedFileName}${marker}\n> └ ${description}\n`); 

            if (isLastFile) {
                result += '\n'; 
            }
        }
    });

    if (!isLast && !result.endsWith('\n')) {
        result += '\n\n';
    }

    return result; 
}
const queryFolder = q; 
    if (!queryFolder) return m.reply("Harap masukkan nama folder, contoh: menu ai");

    const pluginsFolderPath = path.join(process.cwd(), "plugins");
    const excludedFolders = ["Bot-function","Game_hints","Game_answer"]; 
  
    const premiumFiles = db.data.data.filter(item => item.name === 'premium')[0]?.id || [];
    const limitFiles = db.data.data.filter(item => item.name === 'limit')[0]?.id || [];
    const errorFiles = db.data.listerror?.map(item => item.cmd) || [];
    const blokedFiles = db.data.blockcmd?.map(item => item.cmd) || [];

    
    const outputString = displayFilesByFolder(
        pluginsFolderPath,
        queryFolder,
        excludedFolders,
        premiumFiles,
        limitFiles,
        errorFiles,
        blokedFiles,
        true
    );

    if (!outputString.trim()) {
        return m.reply(`Folder *${queryFolder}* tidak ditemukan atau kosong.`);
    }

 const thumbnailUrl = global.imgMenu[queryFolder.toLowerCase()] || 'https://raw.githubusercontent.com/Renzofficial/Uploade/main/uploader/1737046228673.jpg';
  const contextInfo = {
  forwardingScore: 1,
  isForwarded: true,
  containsAutoReply: true,
  mentionedJid: [m.sender],
  forwardedNewsletterMessageInfo: {
  newsletterJid: sig,
  serverMessageId: 100,
  newsletterName:'@ehanzdhoanx'
  },
  businessMessageForwardInfo: {
  businessOwnerJid: m.botNumber,
  },
  externalAdReply: {
  title: 'Ʀαиgєℓ Bσт 𝟼.𝟻.𝟶',
  body: transformText(`Runtime ${runTime}`),
  mediaType: 1,
  renderLargerThumbnail: true,
  thumbnailUrl,
  sourceUrl: '', 
  mediaUrl: global.syt,
  },
  };
  
  conn.sendMessage(m.chat,{ contextInfo, mentions: [m.sender], text: outputString},{quoted:m});

}

};

handler.help = ["all"];
handler.tags = ["internet"];
handler.group = true
handler.gcStore = true
handler.register = true
handler.command = ["menu","helpmen"];
module.exports = handler;
