
const fetch = require('node-fetch');

let handler = async (m, { q, args }) => {
  try {
    if (!q) {
      return m.reply("Silakan masukkan pertanyaan untuk  AI.");
    }

    
    async function bard(query) {
      let response = await fetch(`https://ai.xterm.codes/api/chat/bard?query=${encodeURIComponent(query)}&key=Bell409`);
      let data = await response.json();
      return data;
    }

    let result = await bard(q);

    if (result && result.status) {
      m.reply(result.chatUi);
    } else {
      m.reply("Maaf, terjadi kesalahan saat memproses permintaan.");
    }
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan dalam sistem.");
  }
};

handler.help = ["bard <pertanyaan>"];
handler.tags = ["internet", "ai", "gpt"];
handler.command = ["ai"]
                   
                   
handler.description = ["Gunakan perintah ini untuk bertanya kepada AI."];

module.exports = handler;