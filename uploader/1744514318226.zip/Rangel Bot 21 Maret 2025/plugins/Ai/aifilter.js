const axios = require("axios");
const uploadImage = require("../../lib/uploadImage");

let handler = async (m, { conn, args }) => {
  if (!args[0]) return conn.reply(m.chat, "Gunakan format: *.aifilter <style>* dengan mengirim atau mereply gambar!\n\nPilihan gaya: *epicmanga, anime, art, painting, cartoon, vector*", m);

  let styles = [
    "epicmanga",
    "anime",
    "art",
    "painting",
    "cartoon",
    "vector"
  ];

  let selectedStyle = args[0].toLowerCase();
  if (!styles.includes(selectedStyle)) {
    return conn.reply(m.chat, "Pilihan gaya: *epicmanga, anime, art, painting, cartoon, vector*", m);
  }

  let isQuotedImage = m.quoted && m.quoted.mtype === "imageMessage";
  let isImage = m.mtype === "imageMessage";

  if (!(isImage || isQuotedImage)) {
    return conn.reply(m.chat, "Harap kirim gambar atau balas gambar dengan perintah *.aifilter <style>*", m);
  }
mess.wait()
  try {
    let media = isQuotedImage ? await m.quoted.download() : await m.download();
    let imageUrl = await uploadImage(media);

    let apiKey = Neoxr
    let apiUrl = `https://api.neoxr.eu/api/aifilter?image=${encodeURIComponent(imageUrl)}&style=${encodeURIComponent(selectedStyle)}&apikey=${apiKey}`;

    let response = await axios.get(apiUrl);

    if (response.data.status && response.data.data?.url) {
      let aiFilteredImage = response.data.data.url;
      await conn.sendMessage(m.chat, { image: { url: aiFilteredImage }, caption: `🖼 Gaya filter AI *${args[0].toUpperCase()}* telah diterapkan.` }, { quoted: m });
    } else {
      conn.reply(m.chat, "Gagal menerapkan filter AI. Pastikan gambar valid!", m);
    }
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, "Terjadi kesalahan saat menerapkan filter AI!", m);
  }
};

handler.command = ["aifilter"];
handler.help = ["aifilter <style>"];
handler.tags = ["tools"];
handler.description = ["Mengubah gambar menggunakan filter AI"];
module.exports = handler;