const axios = require("axios");

let handler = async (m, { q, prefix, command }) => {
  if (!q) {
    return m.reply(`Contoh: ${prefix + command} hai luminai`);
  }

  const prompt = "kamu asisten google, tujuan kammu adalah membantu menjawab pertanyaan orang lain dengan detail beserta informasi link nya.";

  const requestData = { content: q, user: m.sender, prompt: prompt };

  try {
    const quoted = m && (m.quoted || m);
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }
    const response = await axios.post('https://luminai.my.id', requestData);
    
    m.reply(response.data.result);
  } catch (err) {
    m.reply(`Terjadi kesalahan: ${err.toString()}`);
  }
};

handler.help = ["chatgpt"];
handler.tags = ["internet", "ai", "gpt"];
handler.command = ["luminai"];

module.exports = handler;
