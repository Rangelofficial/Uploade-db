const axios = require("axios");
const fs = require("fs");
const { textToVoice } = require('../../lib/convert');

let handler = async (m, { q, conn, args, usedPrefix, command }) => {
    if (!q) {
        return m.reply(`*Contoh:* ${usedPrefix + command} Hai, siapa kamu?`);
    }
    conn.sendReact(m.chat, '💬', m.key);
    const character = 'cgSgspJ2msm6clMCkdW9'; // Karakter AI jesica
    try {
        const responseFromAI = await axios.post("https://luminai.my.id/", {
            content: q,
            user: m.sender,
            prompt: `Anda adalah asisten virtual yang cerdas dan responsif Bernama Jesica,Anda Di Kembangkan Oleh Perusahaan Rangelofficial Yang Di Dirikan Oleh Ehanz Dan Kekasihnya Bernama Angel. Jawablah dengan bahasa yang alami, ramah, dan informatif.`
        });

        if (!responseFromAI.data?.result) {
            return m.reply("❌ AI tidak memberikan respons yang valid.");
        }

        const aiResponse = responseFromAI.data.result;
        const audioPath = await textToVoice(character, aiResponse);
        const audioBuffer = fs.readFileSync(audioPath);
        m.reply(audioBuffer)
        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: "audio/ogg",
            ptt: true
        }, { quoted: m });

        console.log("✅ Audio berhasil dikirim!");

        fs.unlinkSync(audioPath);

    } catch (error) {
        console.error("❌ Error:", error);
        m.reply("❌ Terjadi kesalahan, coba lagi nanti.");
    }
};

handler.help = ["chatgpt"];
handler.tags = ["internet", "ai", "gpt"];
handler.command = ["jesica"];
handler.limitAi = true
module.exports = handler;