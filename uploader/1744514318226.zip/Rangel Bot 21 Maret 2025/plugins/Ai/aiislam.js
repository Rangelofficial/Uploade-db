// Rangelofficial 


const axios = require('axios');

let handler = async (m, { q, args }) => {

  if (!q) {
    return m.reply("Hai sahabat yang beriman, silakan tulis pertanyaanmu setelah perintah.");
  }

  const apiUrl = 'https://vercel-server-psi-ten.vercel.app/chat';
  const text = q; 
  const array = []; 
  try {
 
    const response = await axios.post(
      apiUrl,
      { text, array },
      {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
      }
    );

    const result = response.data.result || 'Jawaban tidak ditemukan.';
    m.reply(result); 
  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
    m.reply("Maaf, terjadi kesalahan saat menghubungi AI. Silakan coba lagi.");
  }
};


handler.help = ["aiislam <pertanyaan>"];
handler.tags = ["internet", "ai", "gpt"];
handler.command = ["aiislam", "islamai"]; 

module.exports = handler;