const fetch = require('node-fetch'); 

const handler = async (m, { q, conn }) => {
  try {
    if (!q) return m.reply('Harap masukkan teks prompt-nya!');

    let urlNya = `https://api.siputzx.my.id/api/ai/flux?prompt=${encodeURIComponent(q)}`;

    await conn.sendMessage(m.chat, { image: { url: urlNya }, caption: `Berikut hasil generasi gambar untuk: *${q}*` });

  } catch (error) {
    console.error(error);
    m.reply('Terjadi kesalahan saat menghasilkan gambar. Silakan coba lagi.');
  }
};

handler.help = ['dalle'];
handler.tags = ['ai'];
handler.command = /^(dalle)$/i;
handler.noCmdStore = true;
handler.onlyGroup = false;
handler.description = ["Menghasilkan gambar menggunakan DALL·E dari API"];

module.exports = handler;