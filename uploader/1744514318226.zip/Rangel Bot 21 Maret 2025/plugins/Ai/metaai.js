const axios = require('axios');

let handler = async (m, { q, args }) => { try { 
let query = encodeURIComponent(q || args.join(" "));
                                           let apiUrl = `https://api.neoxr.eu/api/meta?q=${query}&session=bb286368-37d4-485d-9522-fb88ee8f92b4&lang=id&apikey=${Neoxr}`

let response = await axios.get(apiUrl);
let result = response.data;

if (result.status && result.data) {
  let replyMessage = `*[Meta AI]*\n\n`;
  replyMessage += `💬 *Pertanyaan:* ${result.data.prompt}\n`;
  replyMessage += `📝 *Jawaban:* ${result.data.message}\n`;
  
  m.reply(replyMessage);
} else {
  m.reply("Maaf, terjadi kesalahan saat mengambil data dari Meta AI.");
}

} catch (error) { console.error(error); m.reply("Terjadi kesalahan dalam memproses permintaan Anda."); } };

handler.help = ["ai <pertanyaan>"]; handler.tags = ["internet", "ai", "gpt"]; handler.command = ["metaai"]; handler.description = ["Gunakan perintah ini untuk bertanya kepada Meta AI."];

module.exports = handler;

