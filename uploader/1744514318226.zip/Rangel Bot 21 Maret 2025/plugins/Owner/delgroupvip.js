const moment = require('moment-timezone');

let handler = async (m, { conn, q, isOwner, text }) => {

  let groupId = m.chat;  
  if (text) {
    const matchGroupId = text.match(/^(\S+)$/); 
    if (matchGroupId) {
      groupId = matchGroupId[1];  
    }
  }

  if (!global.db.data.chats[groupId] || !global.db.data.chats[groupId].vip) {
    return conn.reply(m.chat, 'Grup ini tidak memiliki status VIP atau belum terdaftar!', m);
  }

  global.db.data.chats[groupId].vip = false;
  global.db.data.chats[groupId].vipStart = ''; 
  global.db.data.chats[groupId].vipExpired = ''; 

  conn.reply(m.chat, `Status VIP grup dengan ID ${groupId} telah dihapus.`, m);
};

handler.help = ["delgroupvip"];
handler.tags = ["info"];
handler.command = /^(delgroupvip)$/i;
handler.owner = true;

module.exports = handler;