const fs = require("fs-extra");
const archiver = require("archiver");

let handler = async (m, { q, conn, setReply }) => {
  if (!q) return setReply("Nama foldernya apa?");
  let mimetype = "application/zip";
  let name = `${q}.zip`;
  let jpegThumbnail = fs.readFileSync("./stik/menhera.jpg");

  try {
    let folderPath = `./${q}`;
    let folderExists = await fs.pathExists(folderPath);
    if (!folderExists) return setReply("Folder tidak ditemukan");

    setReply("Sedang membuat file ZIP, tunggu sebentar...");

    let output = fs.createWriteStream(name);
    let archive = archiver("zip", { zlib: { level: 9 } });

    archive.on("error", (err) => {
      throw err;
    });

    archive.pipe(output);
    archive.directory(folderPath, false); 
    await archive.finalize();
    output.on("close", async () => {
      let file = fs.readFileSync(name);
      await conn.sendMessage(
        m.chat,
        { document: file, fileName: name, mimetype, jpegThumbnail },
        { quoted: m }
      );
      fs.unlinkSync(name);
    });
  } catch (error) {
    console.error(error);
    setReply(`Error: ${error.message}`);
  }
};

handler.help = ["getfolder"];
handler.tags = ["internet"];
handler.command = /^(getfolder|gfo)$/i;
handler.owner = true;
module.exports = handler;