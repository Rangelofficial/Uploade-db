const fs = require("fs");

const getCaseCode = (caseName) => {
  try {
    const mytext = fs.readFileSync("./plugins/Case/case.js", "utf8");
    const regex = new RegExp(`case\\s+['"]${caseName}['"]:[^]*?break;`, "g"); 
    const match = mytext.match(regex);
    return match ? match[0] : null;
  } catch (err) {
    console.error("Error:", err);
    return null;
  }
};

let handler = async (m, { text, setReply }) => {
  if (!text) return setReply("❌ Harap masukkan nama command. Contoh: `.getcase tes`");

  const caseCode = getCaseCode(text);
  if (caseCode) {
    setReply(`📂 **Kode untuk command "${text}":**\n\n\`\`\`${caseCode}\`\`\``);
  } else {
    setReply(`❌ Command "${text}" tidak ditemukan di file case.js.`);
  }
};

handler.help = ['getcase'];
handler.tags = ['owner'];
handler.command = /^(getcase)$/i;
handler.owner = true; 
module.exports = handler;