const fs = require("fs");

const addCase = (caseCode) => {
  try {
    const filePath = "./plugins/Case/case.js";
    let fileContent = fs.readFileSync(filePath, "utf8");

    const caseNameMatch = caseCode.match(/case\s+['"]([^'"]+)['"]:/); 
    if (!caseNameMatch) return "❌ Format case tidak valid.";
    const caseName = caseNameMatch[1];

    const regex = new RegExp(`case\\s+['"]${caseName}['"]`, "g");
    if (regex.test(fileContent)) {
      return `❌ Command "${caseName}" sudah ada di file case.js.`;
    }

    if (/default:/g.test(fileContent)) {
      fileContent = fileContent.replace(/default:/g, `${caseCode}\n  default:`);
    } else {
      fileContent += `\n${caseCode}\n`;
    }

    fs.writeFileSync(filePath, fileContent, "utf8");
    return `✅ Command "${caseName}" berhasil ditambahkan.`;
  } catch (err) {
    console.error("Error:", err);
    return "❌ Terjadi kesalahan saat menambahkan command.";
  }
};

let handler = async (m, { text, setReply }) => {
  if (!text.startsWith("case ")) {
    return setReply(
      "❌ Format salah. Gunakan format:\n`.addcase case 'nama_case': { ... }`\n\nContoh:\n`.addcase case 'tes': { if (!m.isAdmin) return global.mess.only.admin(); reply('Tes berhasil!'); break; }`"
    );
  }

  const result = addCase(text);
  setReply(result);
};

handler.help = ['addcase'];
handler.tags = ['owner'];
handler.command = /^(addcase)$/i;
handler.owner = true; 
module.exports = handler;