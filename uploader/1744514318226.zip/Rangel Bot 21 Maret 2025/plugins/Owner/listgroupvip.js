const moment = require('moment-timezone');

let handler = async (m, { conn }) => {
  let message = 'Daftar Grup VIP:\n\n';

  let vipGroups = Object.entries(global.db.data.chats).filter(([groupId, groupData]) => groupData.vip);

  if (vipGroups.length === 0) {
    return conn.reply(m.chat, 'Tidak ada grup yang memiliki status VIP saat ini.', m);
  }

  vipGroups.forEach(([groupId, groupData]) => {
    const vipStart = moment(groupData.vipStart).tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    const vipExpired = moment(groupData.vipExpired).tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    message += `ID Grup: ${groupId}\nNama Grup: ${groupData.name || 'Tidak Diketahui'}\nVIP Dimulai: ${vipStart}\nVIP Berakhir: ${vipExpired}\n\n`;
  });

  conn.reply(m.chat, message, m);
};

handler.help = ["listgroupvip"];
handler.tags = ["info"];
handler.command = /^(listgroupvip)$/i;
handler.owner = true;

module.exports = handler;