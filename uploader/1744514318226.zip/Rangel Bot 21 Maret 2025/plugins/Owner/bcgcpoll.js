const fs = require('fs-extra')

let handler = async (m, {q, conn, isOwner, setReply, args, usedPrefix, command}) => {
  if (!isOwner && !m.itsMe) return mess.only.owner()
  if (!q) {
    return setReply(`Cara Penggunaan: 
      *${usedPrefix}${command} <teks polling> | <pilihan 1> | <pilihan 2> | ... | <pilihan n>*
      
      Contoh: 
      *${usedPrefix}${command} Siapa yang paling keren? | Saya | Kamu | Mereka*`)
  }
  let getGroups = await conn.groupFetchAllParticipating()
  let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
  let groupsToSend = groups.filter(i => !i.isCommunity && !i.isCommunityAnnounce)
  setReply(`Mengirim Broadcast Ke ${groupsToSend.length} Grup, Waktu Selesai ${groupsToSend.length * 0.5} detik`)
  for (let group of groupsToSend) {
    let groupId = group.id
    let a = q.split("|").slice(1) 
    if (a.length < 2) return setReply("Format polling salah, minimal 2 pilihan!")
    if (a.length > 12) return setReply("Kebanyakan pilihan, maksimal 12 pilihan!")
    if (checkDuplicate(a)) return setReply("Ada pilihan yang duplikat!")

    let cap = `🎉 *Broadcast Polling Survei* 🎉\n
Dari *${m.name}*, berikut adalah survei/polling yang ingin kami lakukan!
Date : ${calender}

📝 *Pertanyaan:* ${q.split("|")[0]}\n
📊 *Pilih salah satu opsi di bawah ini untuk memberikan suara Anda:`

    const pollMessage = {
      name: cap,
      values: a,
      multiselect: false,
      selectableCount: 1
    }
    await conn.sendMessage(groupId, {
      poll: pollMessage
    })
  }

  setReply(`Sukses Mengirim Broadcast Ke ${groupsToSend.length} Grup`)

}

handler.help = ["broadcastpolling"]
handler.tags = ["owner"]
handler.command = ['bcgcpoll']
handler.owner = true
module.exports = handler

function checkDuplicate(arr) {
  return new Set(arr).size !== arr.length
}