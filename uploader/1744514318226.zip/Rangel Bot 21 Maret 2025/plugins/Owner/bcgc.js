const fs = require('fs-extra');

let handler = async (m, { q, conn, isOwner, setReply }) => {
    if (!isOwner && !m.itsMe) return mess.only.owner();
    if (!q) return setReply('Teksnya?\n\nJika ingin sambil tag ketik *.bcgc <teks> -tag*');

    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.values(getGroups).filter(i => !i.isCommunity && !i.isCommunityAnnounce);
    let groupIds = groups.map(v => v.id);

    if (groupIds.length === 0) return setReply('Tidak ada grup yang tersedia untuk broadcast.');

    let mediaFile;
    let isImage = m.mtype === 'imageMessage';
    let isVideo = m.mtype === 'videoMessage';
    const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
    const isQuotedVideo = m.quoted && m.quoted.mtype === 'videoMessage';
    const isQuotedAudio = m.quoted && m.quoted.mtype === 'audioMessage';

    let isQuoted = m.quoted && (isImage || isVideo || isQuotedImage || isQuotedVideo || isQuotedAudio);

    if (isQuoted) {
        mediaFile = await conn.downloadAndSaveMediaMessage(m.quoted, makeid(5));
    }

    setReply(`Mengirim broadcast ke ${groupIds.length} grup, perkiraan selesai dalam ${groupIds.length * 0.5} detik.`);

    let text = `*乂  ＢＲＯＡＤＣＡＳＴ*\n\n${q.replace('-tag', '')}\n\nDate: ${new Date().toLocaleString()}`;

    for (let id of groupIds) {
        await sleep(3000);
        let mem = [];
        let contextInfo = {
            forwardingScore: 50,
            isForwarded: true,
            mentionedJid: mem,
            externalAdReply: {
                showAdAttribution: false,
                title: botName,
                body: `Runtime ${runTime}`,
                mediaType: 1,
                renderLargerThumbnail: true,
                sourceUrl: sgc,
                thumbnailUrl: 'https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1739886630540.jpg'
            }
        };

        let groupMetadata = await conn.groupMetadata(id);
        let members = groupMetadata.participants.map(u => u.id);
        if (q.endsWith('-tag')) mem.push(...members);

        // Mengirim berdasarkan tipe media
        if (mediaFile) {
            let fileData = fs.readFileSync(mediaFile);

            if (isQuotedImage || isImage) {
                await conn.sendMessage(id, { contextInfo, mentions: mem, image: fileData, caption: text });
            } else if (isQuotedVideo || isVideo) {
                await conn.sendMessage(id, { contextInfo, mentions: mem, video: fileData, caption: text });
            } else if (isQuotedAudio) {
                await conn.sendMessage(id, { contextInfo, mentions: mem, audio: fileData, mimetype: 'audio/mp4' });
            } else {
                await conn.sendMessage(id, { contextInfo, text, mentions: mem });
            }
        } else {
            await conn.sendMessage(id, { contextInfo, text, mentions: mem });
        }
    }

    setReply(`Sukses mengirim broadcast ke ${groupIds.length} grup.`);
};

handler.help = ["bcgc"];
handler.tags = ["owner"];
handler.command = ['bcgc'];
handler.owner = true;

module.exports = handler;