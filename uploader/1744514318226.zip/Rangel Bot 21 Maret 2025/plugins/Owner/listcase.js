const fs = require("fs");

const listCase = () => {
  try {
    const mytext = fs.readFileSync("./plugins/Case/case.js", "utf8");
    const cases = (mytext.match(/(?<!\/\/)(case\s+['"]([^'"]+)['"])/g) || []).map(match => {
      return match.replace(/case\s+['"]([^'"]+)['"]/, '$1'); 
    });
    return cases;
  } catch (err) {
    console.error("Error:", err);
    return [];
  }
};

let handler = async (m, { setReply }) => {
  const cases = listCase();
  if (cases.length === 0) return setReply("❌ Tidak ada command terdaftar.");
  
  const response = `📂 **Daftar Commands Terdaftar:**\n\n${cases
    .map((c, i) => `${i + 1}. ${c}`)
    .join("\n")}`;
  setReply(response);
};

handler.help = ['listcase'];
handler.tags = ['owner'];
handler.command = /^(listcase)$/i;
handler.owner = true; 
module.exports = handler;