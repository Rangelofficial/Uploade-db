let handler = async (m,{ q, conn, isOwner, setReply, args, usedPrefix, command }) => {




    const fs = require('fs');
    const archiver = require('archiver');
    const path = require('path');
    let jpegThumbnail = fs.readFileSync("./media/image/docRangel.jpg");
   
    const output = fs.createWriteStream(`${botName} ${calender}.zip`);
    const nameFile = `${botName} ${calender}.zip`
    const archive = archiver('zip', {
        zlib: { level: 9 }
    });
    
    mess.wait()
   
    output.on('close', async function() {
        m.reply(`File zip berhasil dibuat\nTotal ${await FileSize(archive.pointer())}`);
         
    await conn.sendMessage(m.sender, {document:fs.readFileSync(nameFile) , jpegThumbnail,mimetype: "application/zip", fileName: nameFile}, {quoted: m})
    
    await fs.unlinkSync(nameFile)
    });
    
    archive.on('error', function(err) {
        throw err;
    });
    
  
    archive.pipe(output);
   
    function addFilesAndFolders(dirPath, archive) {
        const items = fs.readdirSync(dirPath);
        items.forEach((item) => {
            const fullPath = path.join(dirPath, item);
            let kecuali = ['node_modules' ,'.git','package-lock.json','.heroku','.profile.d','vendor','.npm']
            if (fs.statSync(fullPath).isDirectory()) {
                if (!kecuali.includes(item)) {
                   archive.directory(fullPath, item);
                }
            } else if (!fullPath.endsWith('.xml')) {
               
                archive.file(fullPath, { name: item });
            }
        });
    }
    
  
    addFilesAndFolders('.', archive);
    
 
    await archive.finalize();
  
    



  };
  
  handler.command = ["backup"];
  handler.owner = true;
  module.exports = handler;
  


  



  async function FileSize(number) {
    var SI_POSTFIXES = ["B", "KB", "MB", "GB", "TB", "PB", "EB"];
    var tier = (Math.log10(Math.abs(number)) / 3) | 0;
    if (tier == 0) return number + " B"; 
    var postfix = SI_POSTFIXES[tier];
    var scale = Math.pow(10, tier * 3);
    var scaled = number / scale;
    var formatted = scaled.toFixed(1).replace('.', ',') + ""; 
    if (/\.0$/.test(formatted))
        formatted = formatted.substr(0, formatted.length - 2);
    return formatted + " " + postfix;
};