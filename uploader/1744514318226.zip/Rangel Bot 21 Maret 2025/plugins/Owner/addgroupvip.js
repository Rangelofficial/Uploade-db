const moment = require('moment-timezone');

let handler = async (m, { conn, q, isOwner, text }) => {
  
  let groupId = m.chat;  
  if (text) {
    const matchGroupId = text.match(/^(\S+)\s+(\d+[dhms])$/); 
    if (matchGroupId) {
      groupId = matchGroupId[1];  
      q = matchGroupId[2];   
    }
  }
  const timePattern = /(\d+)([dhms])/i;
  const match = q.match(timePattern);

  if (!match) {
    return conn.reply(m.chat, 'Format waktu tidak valid! Gunakan format seperti "30d" (30 hari),\n "1h" (1 jam),\n atau "15m" (15 menit)\n"15s" (15 detik)',m);
  }

  const [_, timeAmount, timeUnit] = match;

  let multiplier;
  switch (timeUnit.toLowerCase()) {
    case 'd': // Hari
      multiplier = 24 * 60 * 60 * 1000; 
      break;
    case 'h': // Jam
      multiplier = 60 * 60 * 1000; 
      break;
    case 'm': // Menit
      multiplier = 60 * 1000; 
      break;
    case 's': // Detik
      multiplier = 1000; 
      break;
    default:
      return conn.reply(m.chat, 'Satuan waktu tidak valid. Gunakan "d", "h", "m", atau "s".', m);
  }
  const vipDuration = parseInt(timeAmount) * multiplier;
  const vipExpired = moment().add(vipDuration, 'milliseconds').tz('Asia/Jakarta').format(); 
  global.db.data.chats[groupId] = {
    ...global.db.data.chats[groupId], 
    vip: true,         
    vipStart: moment().tz('Asia/Jakarta').format(), 
    vipExpired: vipExpired,     
  };

  const remainingTime = vipDuration; 
  const remainingDays = Math.floor(remainingTime / (24 * 60 * 60 * 1000)); 
  const remainingHours = Math.floor((remainingTime % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000)); 
  const remainingMinutes = Math.floor((remainingTime % (60 * 60 * 1000)) / (60 * 1000)); 
  
  conn.reply(m.chat, `Grup dengan ID ${groupId} berhasil ditambahkan ke status VIP! Status VIP akan berakhir dalam ${remainingDays} hari, ${remainingHours} jam, dan ${remainingMinutes} menit.`, m);
};

handler.help = ["addgroupvip"];
handler.tags = ["info"];
handler.command = /^(addgroupvip)$/i;
handler.owner = true;

module.exports = handler;