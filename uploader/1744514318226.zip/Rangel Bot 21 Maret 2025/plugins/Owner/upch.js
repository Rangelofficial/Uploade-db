const { proto } = require("baileys");

let handler = async (m, { conn, setReply, args }) => {
    const quoted = m.quoted ? m.quoted : null;

    const channels = [
        { name: "Tes", id: "120363363359845263@newsletter" },
        { name: "Rangelofficial ✅", id: "120363185390263663@newsletter" },
        { name: "RangelWhats 🚩", id: "120363402649520969@newsletter" }
    ];

    if (!args[0]) {
        let channelList = "Silakan pilih channel untuk mengunggah pesan:\n";
        channels.forEach((channel, index) => {
            channelList += `${index + 1}. ${channel.name}\n`;
        });
        return setReply(channelList);
    }

    if (!quoted) {
        return setReply("Harap reply media atau pesan yang ingin diunggah ke channel.");
    }

    // Cek apakah argumen pertama adalah nomor valid
    const selectedIndex = parseInt(args[0]) - 1;
    if (selectedIndex < 0 || selectedIndex >= channels.length) {
        return setReply("Pilihan tidak valid. Harap pilih nomor channel dari daftar.");
    }
    const selectedChannel = channels[selectedIndex];
    try {
        const messages = quoted.fakeObj.message;
        const messageType = Object.keys(messages)[0];
        const messageToChannel = proto.Message.encode(messages).finish();
        let result = {
            tag: "message",
            attrs: { to: selectedChannel.id, type: "text" },
            content: [],
        };
        switch (messageType) {
            case "imageMessage":
            case "videoMessage":
                result.content.push({
                    tag: "media",
                    attrs: {
                        type: messageType === "imageMessage" ? "image" : "video",
                    },
                    content: messageToChannel,
                });
                break;

            case "documentMessage":
                result.content.push({
                    tag: "document",
                    attrs: {
                        filename: messages.documentMessage.fileName || "file",
                    },
                    content: messageToChannel,
                });
                break;

            case "stickerMessage":
                result.content.push({
                    tag: "sticker",
                    attrs: {},
                    content: messageToChannel,
                });
                break;

            default:
                result.content.push({
                    tag: "plaintext",
                    attrs: {},
                    content: messageToChannel,
                });
                break;
        }
        await conn.query(result);
        setReply(`Pesan berhasil dikirim ke channel ${selectedChannel.name}.`);
    } catch (err) {
        setReply(`Terjadi kesalahan: ${err.message}`);
    }
};

handler.help = ["upch"];
handler.tags = ["channel"];
handler.command = ["upch"];
handler.owner = true;

module.exports = handler;