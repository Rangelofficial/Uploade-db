const fs = require('fs-extra');
const uploadToGithub = require('../../lib/uploadToGithub');

let handler = async (m, { conn, text }) => {
  const { STORIES_JID, generateWAMessage } = require('baileys');

  const fetchParticipants = async (jid) => {
    let { participants } = await conn.groupMetadata(jid);
    return participants.map(({ id }) => id);
  };

  async function sendStatusWithMentions(jids, content) {
    let statusJidList = [];

    for (const jid of jids) {
      if (jid.endsWith('@g.us')) {
        let members = await fetchParticipants(jid);
        statusJidList.push(...members);
      } else {
        statusJidList.push(jid);
      }
    }

    statusJidList = [...new Set(statusJidList)]; // Menghapus duplikasi

    const mentions = statusJidList.map(jid => `@${jid.split('@')[0]}`).join(' ');

    if (content.text) {
      content.text += `\n\n${mentions}`;
    }

    const msg = await generateWAMessage(STORIES_JID, content, {
      upload: conn.waUploadToServer,
    });

    await conn.relayMessage(STORIES_JID, msg.message, { messageId: msg.key.id });

    conn.reply(m.chat, '✅ Berhasil mengunggah ke status grup dengan mention!', m);
  }

  const isQuotedVideo = m.quoted && m.quoted.mtype === 'videoMessage';
  const isVideo = m.mtype === 'videoMessage';
  const isQuotedAudio = m.quoted && m.quoted.mtype === 'audioMessage';
  const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
  const isImage = m.mtype === 'imageMessage';
  const isText = text && text.trim().length > 0;
  const quoted = m.quoted ? m.quoted : m;

  let mediaPath, mediaBuffer, uploadedUrl;
  let messageContent = {}; // Objek untuk menyimpan isi pesan

  if (isQuotedVideo || isVideo || isQuotedAudio || isQuotedImage || isImage) {
    if (quoted.duration && quoted.duration > 30) {
      return conn.reply(m.chat, '⚠️ Video atau audio tidak boleh lebih dari 30 detik.', m);
    }

    mediaPath = await conn.downloadAndSaveMediaMessage(quoted);
    mediaBuffer = fs.readFileSync(mediaPath);
    uploadedUrl = await uploadToGithub(mediaBuffer);

    if (isQuotedVideo || isVideo) {
      messageContent.video = { url: uploadedUrl };
    } else if (isQuotedAudio) {
      messageContent.audio = { url: uploadedUrl, mimetype: 'audio/mp4' };
    } else if (isQuotedImage || isImage) {
      messageContent.image = { url: uploadedUrl };
    }
  }

  if (isText) {
    messageContent.text = text;
  }

  if (Object.keys(messageContent).length === 0) {
    return conn.reply(m.chat, '⚠️ Kirim teks, gambar, audio, atau video untuk diunggah ke status.', m);
  }

  await sendStatusWithMentions([m.chat], messageContent);
};

handler.help = ['upswgc'];
handler.tags = ['owner'];
handler.command = ['upswgc1'];
handler.owner = true;

module.exports = handler;