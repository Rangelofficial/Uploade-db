const fs = require('fs-extra');
const fetch = require('node-fetch'); // Untuk mengambil file dari URL
const uploadToGithub = require('../../lib/uploadToGithub'); // Menggunakan uploadToGithub

let handler = async (m, { conn, text }) => {
  const { STORIES_JID, generateWAMessage } = require('baileys');

  const fetchParticipants = async (...jids) => {
    let results = [];
    for (const jid of jids) {
      let { participants } = await conn.groupMetadata(jid);
      results = results.concat(participants.map(({ id }) => id));
    }
    return results;
  };

  // Fungsi untuk mengunduh file dari URL dan mengunggahnya ke GitHub
  const downloadFileFromUrl = async (url) => {
    const res = await fetch(url);
    const buffer = await res.buffer();
    return buffer;
  };

  async function sendstatusMentions(jids, content) {
    const msg = await generateWAMessage(STORIES_JID, content, {
      upload: conn.waUploadToServer,
    });

    let statusJidList = [];
    for (const _jid of jids) {
      if (_jid.endsWith('@g.us')) {
        let participants = await fetchParticipants(_jid);
        statusJidList = [...statusJidList, ...participants];
      } else {
        statusJidList.push(_jid);
      }
    }
    statusJidList = [...new Set(statusJidList)];  // Menghilangkan duplikasi

    // Mengirim pesan status ke STORIES_JID
    await conn.relayMessage(STORIES_JID, msg.message, {
      messageId: msg.key.id,
    });

    // Mengirim pesan mention ke masing-masing jid
    for (const jid of statusJidList) {
      let type = jid.endsWith('@g.us') ? 'groupStatusMentionMessage' : 'statusMentionMessage';
      await conn.relayMessage(
        jid,
        {
          [type]: {
            message: {
              protocolMessage: {
                key: msg.key,
                type: 25,
              },
            },
          },
        },
        {}
      );
    }

    return msg;
  }

  try {
    let mediaBuffer;
    let mediaUrl;

    // Cek apakah ada URL di dalam teks
    if (text && text.trim()) {
      // Mengambil URL dari teks
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      const urls = text.match(urlRegex);

      if (urls && urls.length > 0) {
        mediaUrl = urls[0]; // Mengambil URL pertama

        // Menentukan tipe file berdasarkan ekstensi URL
        if (mediaUrl.match(/\.(jpeg|jpg|png)$/i)) {
          mediaBuffer = await downloadFileFromUrl(mediaUrl);
          const uploadedUrl = await uploadToGithub(mediaBuffer);
          await sendstatusMentions([m.chat], { image: { url: uploadedUrl } });
          conn.reply(m.chat, '✅ Berhasil mengunggah gambar ke status!', m);
        } else if (mediaUrl.match(/\.(mp4|mkv|webm)$/i)) {
          mediaBuffer = await downloadFileFromUrl(mediaUrl);
          const uploadedUrl = await uploadToGithub(mediaBuffer);
          await sendstatusMentions([m.chat], { video: { url: uploadedUrl } });
          conn.reply(m.chat, '✅ Berhasil mengunggah video ke status!', m);
        } else if (mediaUrl.match(/\.(mp3|ogg|wav)$/i)) {
          mediaBuffer = await downloadFileFromUrl(mediaUrl);
          const uploadedUrl = await uploadToGithub(mediaBuffer);
          await sendstatusMentions([m.chat], { audio: { url: uploadedUrl, mimetype: 'audio/mp4' } });
          conn.reply(m.chat, '✅ Berhasil mengunggah audio ke status!', m);
        } else {
          return conn.reply(m.chat, '⚠️ Format file tidak didukung. Harap kirim gambar, video, atau audio.', m);
        }
      } else {
        // Jika hanya teks yang dikirimkan
        await sendstatusMentions([m.chat], { text });
        conn.reply(m.chat, '✅ Berhasil mengunggah teks ke status!', m);
      }
    } else {
      conn.reply(m.chat, '⚠️ Harap kirim teks atau URL untuk diunggah sebagai status.', m);
    }
  } catch (err) {
    console.error(err);
    conn.sendMessage(
      m.chat,
      { text: 'Terjadi kesalahan dalam memproses permintaan.' },
      { quoted: m }
    );
  }
};

handler.help = ['upswgc'];
handler.tags = ['owner'];
handler.command = ['upswgc2'];  // Ganti dengan command yang diinginkan

module.exports = handler;