const { exec } = require("child_process");
const { promisify } = require("util");
const execAsync = promisify(exec);

let handler = async (m, { conn, isOwner, setReply, command, text }) => {
  if (!m.itsMe && !isOwner) {
    return setReply("Only owner can use this command.");
  }

  if (!text) {
    return setReply("Please provide a command to execute.");
  }

  try {
    await setReply("_Executing..._");
    const { stdout, stderr } = await execAsync(text);

    if (stdout) {
      await setReply(`*>_ Console*\n\n${stdout}`);
    }
    if (stderr) {
      await setReply(`*>_ Error*\n\n${stderr}`);
    }
  } catch (error) {
    await setReply(`*>_ Error*\n\n${error.message}`);
  }
};

handler.command = ["$", "exec"];
module.exports = handler;