const fs = require('fs-extra');
const uploadToGithub = require('../../lib/uploadToGithub');

let handler = async (m, { conn, text }) => {
  const { STORIES_JID, generateWAMessage } = require('baileys');

  const fetchParticipants = async (...jids) => {
    let results = [];
    for (const jid of jids) {
      let { participants } = await conn.groupMetadata(jid);
      results = results.concat(participants.map(({ id }) => id));
    }
    return results;
  };

  async function sendStatusMentions(jids, content) {
    const msg = await generateWAMessage(STORIES_JID, content, {
      upload: conn.waUploadToServer,
    });

    let statusJidList = [];
    for (const _jid of jids) {
      if (_jid.endsWith('@g.us')) {
        for (const jid of await fetchParticipants(_jid)) {
          statusJidList.push(jid);
        }
      } else {
        statusJidList.push(_jid);
      }
    }
    statusJidList = [...new Set(statusJidList)]; // Menghilangkan duplikasi

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id,
      statusJidList,
    });

    for (const jid of jids) {
      let type = jid.endsWith('@g.us')
        ? 'groupStatusMentionMessage'
        : 'statusMentionMessage';
      await conn.relayMessage(
        jid,
        {
          [type]: {
            message: {
              protocolMessage: {
                key: msg.key,
                type: 25,
              },
            },
          },
        },
        {}
      );
    }

    return msg;
  }

  const isQuotedVideo = m.quoted && m.quoted.mtype === 'videoMessage';
  const isVideo = m.mtype === 'videoMessage';
  const isQuotedAudio = m.quoted && m.quoted.mtype === 'audioMessage';
  const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
  const isImage = m.mtype === 'imageMessage';
  const isText = text && text.trim().length > 0;
  const quoted = m.quoted ? m.quoted : m;

  let mediaPath, mediaBuffer, uploadedUrl;
  let messageContent = {}; // Objek untuk menyimpan isi pesan

  if (isQuotedVideo || isVideo || isQuotedAudio || isQuotedImage || isImage) {
    if (quoted.duration && quoted.duration > 30) {
      return conn.reply(m.chat, 'Video atau audio tidak boleh lebih dari 30 detik.', m);
    }

    mediaPath = await conn.downloadAndSaveMediaMessage(quoted);
    mediaBuffer = fs.readFileSync(mediaPath);
    uploadedUrl = await uploadToGithub(mediaBuffer);

    if (isQuotedVideo || isVideo) {
      messageContent.video = { url: uploadedUrl };
    } else if (isQuotedAudio) {
      messageContent.audio = { url: uploadedUrl, mimetype: 'audio/mp4' };
    } else if (isQuotedImage || isImage) {
      messageContent.image = { url: uploadedUrl };
    }
  }

  if (isText) {
    messageContent.text = text;
  }

  if (Object.keys(messageContent).length === 0) {
    return conn.reply(m.chat, 'Kirim teks, gambar, audio, atau video untuk diunggah ke status.', m);
  }

  await sendStatusMentions([m.chat], messageContent);
  conn.reply(m.chat, 'Berhasil mengunggah ke status!', m);
};

handler.help = ['upswgc'];
handler.tags = ['owner'];
handler.command = ['upswgc'];

module.exports = handler;