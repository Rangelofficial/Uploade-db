const fs = require('fs-extra')

let handler = async (m, { q, conn, isOwner, setReply, usedPrefix, command }) => {
    if (!isOwner && !m.itsMe) return mess.only.owner();
    if (!q) return setReply('Teksnya?');

    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.values(getGroups).filter(g => !g.isCommunity && !g.isCommunityAnnounce);
    let groupIds = groups.map(g => g.id);

    setReply(`Mengirim Broadcast Ke ${groupIds.length} Chat, Waktu Selesai ±${groupIds.length * 0.5} detik`);

    for (let id of groupIds) {
        let mem = [];
        let text = `🚩 ${q.replace('-tag', '')}\n\n📅 Date: ${new Date().toLocaleDateString()}`;

        let data = await conn.groupMetadata(id);
        let members = data.participants;

        if (q.endsWith('-tag')) {
            mem = members.map(u => u.id);
        }
        await conn.sendMessage(id, { text, mentions: mem });
    }

    setReply(`✅ Sukses Mengirim Broadcast Ke ${groupIds.length} Group`);
};

handler.help = ["bcgctext"];
handler.tags = ["owner"];
handler.command = ['bcgctext'];
handler.owner = true;

module.exports = handler;