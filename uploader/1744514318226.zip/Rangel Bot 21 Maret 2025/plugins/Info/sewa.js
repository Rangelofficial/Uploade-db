
const moment = require("moment-timezone");
const timeWib = moment().tz('Asia/Jakarta').format('HH:mm:ss');


let ucapanWaktu;
if (timeWib < "06:00:00") {
    ucapanWaktu = '🌅 Selamat pagi!';
} else if (timeWib < "11:00:00") {
    ucapanWaktu = '☀️ Selamat pagi!';
} else if (timeWib < "15:00:00") {
    ucapanWaktu = '🌞 Selamat siang!';
} else if (timeWib < "18:00:00") {
    ucapanWaktu = '🌇 Selamat sore!';
} else if (timeWib < "19:00:00") {
    ucapanWaktu = '🌙 Selamat malam!';
} else {
    ucapanWaktu = '🌌 Selamat malam!';
}
const dada = (prefix, pushname, ucapanWaktu) => {
    return `${ucapanWaktu} 
Berikut adalah list harga untuk sewa bot:

🌟 *Paket Hemat*  
   ▸ Pengguna Baru: Rp 5.000  
   └ Per group - perpanjang: Rp 3.000  
   └ Masa aktif: 15 hari  

⚡ *Paket Premium*  
   ▸ Rp 10.000  
   └ Per group - perpanjang: Rp 7.000  
   └ Masa aktif: 30 hari  
   └ Fitur premium: Unlimited limit, akses eksklusif  

🔥 *Paket Ultimate*  
   ▸ Rp 25.000  
   └ Per group - perpanjang: Rp 20.000  
   └ Masa aktif: 60 hari  
   └ Fitur premium: Unlimited limit, akses eksklusif, auto-respond  

🎉 *Paket Bisnis (Multi-group)*  
   ▸ Rp 50.000  
   └ Untuk 5 group  
   └ Masa aktif: 90 hari  
   └ Group Add vip
   └ Fitur premium: Unlimited limit, akses eksklusif, auto-respond, prioritas support  

🛡️ *Paket Custom*  
   ▸ Harga menyesuaikan kebutuhan  
   └ Masa aktif: Sesuai kesepakatan  
   └ Fitur: Kustomisasi sesuai permintaan  

𝗡𝗢𝗧𝗘:  
- Bot aktif 24 jam, tetapi bisa offline jika ada perbaikan atau error.  
- Semua paket dilengkapi fitur auto-respond dasar.  
- Hubungi owner untuk request fitur tambahan atau konsultasi paket.  

💬 Jika tertarik, silakan hubungi Owner Bot untuk informasi lebih lanjut!  
`
};
const handler = async (m, {  conn, command, prefix, pushname,setReply}) => {
    if (command === 'sewa' || command === 'sewabot') {
       
        const sewanya = dada(prefix, m.pushname, ucapanWaktu);
        
        
        setReply(sewanya);
    }
};


handler.help = ['sewa', 'sewabot'];
handler.tags = ['info'];  
handler.command = /^(sewa|sewabot)$/i;  

module.exports = handler;
