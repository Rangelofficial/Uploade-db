const { exec } = require('child_process');

const handler = async (m, { conn, command, prefix }) => {
    // Check if the user wants to know the disk usage
    if (command === 'disk') {
        exec('cd && du -h --max-depth=1', (err, stdout) => {
            if (err) {
                return conn.reply(m.chat, `⚠️ Terjadi kesalahan: ${err}`, m);
            }
            if (stdout) {
                return conn.reply(m.chat, `*Disk Usage:*\n\n${stdout}`, m);
            }
        });
    }
};

// Command setup
handler.help = ['disk'];
handler.tags = ['tools'];
handler.command = /^disk$/i;

module.exports = handler;
