       
const handler = async (m, { conn,sendThumb, command, prefix }) => {    
 let teksTqto = transformText (`${thanksto(prefix)}`);
    
  conn.sendMessage(m.chat, {
    text: teksTqto, 
    contextInfo: {
      externalAdReply: {
        title: 'Big Thanks',
        body: `simpel bot WhatsApp`,
        thumbnailUrl: 'https://pomf2.lain.la/f/4kynvgsd.jpg', 
        sourceUrl: `${web}`,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

// Command setup
handler.help = ['tqto', 'thanksto'];
handler.tags = ['tools'];
handler.command = /^(tqto|thanksto)$/i;

module.exports = handler;
