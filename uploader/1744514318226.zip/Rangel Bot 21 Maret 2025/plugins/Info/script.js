const fetch = require("node-fetch");
let handler = async (m, {  conn, args }) => {
  const fs = require("fs");
  const path = require("path");

  const pluginsFolderPath = "./plugins";
  const excludedFolders = [""]; 
  function countFolders(folderPath) {
    try {
      const items = fs.readdirSync(folderPath);
      return items.filter((item) => {
        const itemPath = path.join(folderPath, item);
        return fs.statSync(itemPath).isDirectory() && !excludedFolders.includes(item);
      }).length;
    } catch (error) {
      console.error("Error:", error);
      return 0;
    }
  }
  function countJSFiles(folderPath) {
    try {
      const items = fs.readdirSync(folderPath);
      let jsFileCount = 0;

      items.forEach((item) => {
        const itemPath = path.join(folderPath, item);
        const stat = fs.statSync(itemPath);

        if (stat.isDirectory() && !excludedFolders.includes(item)) {
          jsFileCount += countJSFiles(itemPath); 
        } else if (path.extname(item) === ".js") {
          jsFileCount++;
        }
      });

      return jsFileCount;
    } catch (error) {
      console.error("Error:", error);
      return 0;
    }
  }
  const totalFolders = countFolders(pluginsFolderPath);
  const totalJSFiles = countJSFiles(pluginsFolderPath);
  const totalFitur = () => {
    try {
      const mytext = fs.readFileSync("./plugins/Case/case.js", "utf8");
      return (mytext.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || []).length;
    } catch (err) {
      console.error("Error:", err);
      return 0;
    }
  };
  const totalFeatures = totalJSFiles + totalFitur();
  const img = "https://raw.githubusercontent.com/Rangelofficial/Uploade-db/main/uploader/1734707149126.jpg";
  const currentYear = new Date().getFullYear();
  const socialMedia = {
    youtube: "https://www.youtube.com/@rangelbot",
    waChannel: "https://whatsapp.com/channel/0029VaAyQPOAjPXPIzpWKX3K", 
    ownerNumber: "+6281316643491",
    github: "https://github.com/Raihan-Fadillah", 
  };

  const teks1 = `
  ––––––『 *ɪɴғᴏ sᴄʀɪᴘᴛ* 』––––––
*ᴍᴇɴʜᴇʀᴀ ʙᴏᴛ* ᴀᴅᴀʟᴀʜ ʙᴏᴛ ʏᴀɴɢ ᴀᴡᴀʟɴʏᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴀsᴇ ᴅᴀʀɪ
[ᴀᴍᴇʟɪᴀ-ʙᴏᴛᴢ] https://github.com/officialdittaz/Amelia-Botz/
[ʜᴀsɪʀᴀ-ʙᴏᴛᴢ] https://replit.com/@AryaXyz
ᴋɪɴɪ ᴋᴀᴍɪ ᴛᴇʀᴜs ᴍᴇɴɢᴇᴍʙᴀɴɢᴋᴀɴ ᴅᴀɴ ᴍᴇᴍᴘᴇʀʙᴀʀᴜɪ ᴛᴀʜᴀᴘ ᴅᴇᴍɪ ᴛᴀʜᴀᴘ.

––––––『 *ɪɴғᴏ sᴏsɪᴀʟ ᴍᴇᴅɪᴀ* 』––––––
📺 *ʏᴏᴜᴛᴜʙᴇ:* [ᴋʟɪᴋ ᴅɪ sɪɴɪ] ${socialMedia.youtube}
📱 *ᴄʜᴀɴɴᴇʟ ᴡᴀ:* [ᴋʟɪᴋ ᴅɪ sɪɴɪ] ${socialMedia.waChannel}
📞 *ɴᴏᴍᴏʀ ᴏᴡɴᴇʀ:* ${socialMedia.ownerNumber}
🐱‍💻 *ɢɪᴛʜᴜʙ:* [ᴋʟɪᴋ ᴅɪ sɪɴɪ] ${socialMedia.github}\n\n`

let teks2 = transformText(`
––––––『 *STATISTIK FITUR* 』––––––
📂 *Plugins*
- Total Folder: ${totalFolders} folder
- Total File.js: ${totalJSFiles} file.js
- Fitur Case: ${totalFitur()} case
- Total Fitur: ${totalFeatures} fitur

––––––『 *BUTUH SCRIPT INI?* 』––––––
💡 *Anda tertarik dengan script ini?*  
Hubungi *Owner Bot* melalui nomor berikut:  
📞 *${socialMedia.ownerNumber}*

⚡ Jangan ragu untuk bertanya atau request fitur tambahan! Kami selalu siap membantu Anda.  

📅 Tahun: ${currentYear}
📄 © Rangelofficial Development Team
`).trim();
  
  let numb = ["7.76","15.48","8.92","10.72","13.48","4.39","5.99","2.56"]
let amont = numb[Math.floor(Math.random() * numb.length)]
 conn.relayMessage(m.chat,  {
requestPaymentMessage : {
expiryTimestamp: 0,												
currencyCodeIso4217: 'USD',
amount1000: (amont) * 1000,
requestFrom: `${m.sender.split('@')[0]}@s.whatsapp.net`,
noteMessage: {
extendedTextMessage: {
text : teks1 + teks2,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: true,
}
}
}
}
}
}, {})
};
handler.help = ["script"];
handler.tags = ["info"];
handler.command = ["script", "sc"];
handler.customPrefix = /(?:.)/;
module.exports = handler;