let handler = async (m, { conn, command, setReply }) => {

let promo = `
🎉 **UPGRADE KE PREMIUM SEKARANG!** 🎉

💎 **Promo Spesial Pengguna Baru**  
Hanya Rp 5.000  
🕒 Masa Aktif: 1 Bulan  

✨ **Premium Ekstra**  
Rp 25.000  
🕒 Masa Aktif: 1500 Hari  

**🌟 Keuntungan Premium:**
1. **Limit Tanpa Batas** 🚀  
2. **Klaim EXP Harian Lebih Banyak** 💥  
3. **Semua Fitur Premium Terbuka** 🔥  
4. **Akses Fitur NSFW** 🛑  
5. **Kustomisasi Watermark Stiker** ✍️  
6. **Pengalaman Eksklusif** 🎉  

📢 *Segera upgrade dan nikmati layanan tanpa batas!*  
Hubungi langsung owner di sini: ${nomerOwner}  

🔒 **Jaminan Kepuasan & Privasi Terjamin!**  
_Ubah pengalaman Anda menjadi lebih eksklusif bersama layanan premium kami._  
`
let amounts = ["7.76", "15.48", "8.92", "10.72", "13.48", "4.39", "5.99", "2.56"];
let amount = amounts[Math.floor(Math.random() * amounts.length)];

conn.relayMessage(m.chat, {
  requestPaymentMessage: {
    expiryTimestamp: 0,
    currencyCodeIso4217: 'USD',
    amount1000: (amount) * 1000,
    requestFrom: `${m.sender.split('@')[0]}@s.whatsapp.net`,
    noteMessage: {
      extendedTextMessage: {
        text: transformText(promo),
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            showAdAttribution: true,
          }
        }
      }
    }
  }
}, {});
}

handler.command = /^(buyprem|buypremium)$/i;
handler.tags = ['main'];
handler.help = ['premium'];

module.exports = handler;