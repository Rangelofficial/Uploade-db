let handler = async (m, { conn, args, q}) => {
  try {
    if (!args[0]) {
      return conn.reply(m.chat, `❌ *Contoh penggunaan:*\n.laporerror menu tidak muncul`, m);
    }
    
    let pesanError = q.split('|')[0];
    let pesan = `╭─❒ *Laporan Bug* ❒─╮
📨 *Pesan:* ${pesanError}
👤 *Pengirim:* @${m.sender.split('@')[0]}
${m.isGroup ? `👥 *Grup:* ${await conn.getName(m.chat)}` : ''}
╰─────────────────╯`;

   
    conn.reply(m.chat, `✅ *Terima kasih!*\nLaporan bugmu sudah terkirim ke Owner. Kami akan segera menindaklanjuti.`, m);

    
    conn.sendMessage(global.nomerOwner + "@s.whatsapp.net", {
      image: { url: `${getRandom(global.fotoRandom)}` },
      caption: pesan,
      mentions: [m.sender],
    });
  } catch (err) {
    console.error(err);
    conn.reply(m.chat, `❌ Terjadi kesalahan saat mengirim laporan.`, m);
  }
};

handler.help = ['laporerror'];
handler.tags = ['info'];
handler.command = /^(laporerror)$/i;

module.exports = handler;
