const fetch = require('node-fetch');

const handler = async (m, { conn, command, args }) => {
    let apiKey = Neoxr
    if (!apiKey) return m.reply('Masukkan API key yang ingin dicek!');

    let apiUrl = `https://api.neoxr.eu/api/check?apikey=${apiKey}`;
    
    try {
        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) {
            return m.reply('API key tidak valid atau terjadi kesalahan.');
        }

        let result = `*API Key Information*\n\n` +
                     `👤 Name: ${json.data.name}\n` +
                     `📊 Limit: ${json.data.limit}/${json.data.total}\n` +
                     `⭐ Premium: ${json.data.premium ? 'Ya' : 'Tidak'}\n` +
                     `📅 Expired At: ${json.data.expired_at}\n` +
                     `🕒 Last Activity: ${json.data.last_activity}\n` +
                     `🌐 URL: ${json.data.url}`;

    conn.sendMessage(m.chat, {
    image: { url: json.data.url },
    caption: result
}, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mengecek API key.');
    }
};

handler.help = ['cekapikeyneoxr <apikey>'];
handler.tags = ['tools'];
handler.command = /^cekapikey$/i;

module.exports = handler;