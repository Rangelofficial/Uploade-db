let handler = async (m, {  conn,usedPrefix }) => {
  let today = new Date();
  let curHr = today.getHours();
  let timeOfDay;

  if (curHr < 12) {
    timeOfDay = 'pagi';
  } else if (curHr < 18) {
    timeOfDay = 'siang';
  } else {
    timeOfDay = 'malam';
  }

  let payText = `
Halo Kak, selamat ${timeOfDay} 🌞🌛

Berikut adalah daftar sosial media kami yang dapat Kakak kunjungi:

📷 *Instagram*  
   ≡ ${sig || 'Tidak tersedia'}

💻 *GitHub*  
   ≡ ${sgh || 'Tidak tersedia'}

📘 *Facebook*  
   ≡ ${global.sfb || 'Tidak tersedia'}

▶️ *YouTube*  
   ≡ ${syt || 'Tidak tersedia'}

🎵 *TikTok*  
   ≡ ${global.stt || 'Tidak tersedia'}

📱 *WhatsApp*  
   ≡ wa.me/${nomerOwner || 'Tidak tersedia'}

🐦 *Twitter*  
   ≡ ${global.stw || 'Tidak tersedia'}

📌 *LinkedIn*  
   ≡ ${global.sln || 'Tidak tersedia'}

📞 *Telegram*  
   ≡ ${global.stg || 'Tidak tersedia'}

🛒 *Website*  
   ≡ ${global.sweb || 'Tidak tersedia'}

📢 Jangan lupa untuk mengikuti kami di platform favoritmu agar tidak ketinggalan informasi terbaru!  
Terima kasih telah mendukung kami 💖
`;
  await  conn.relayMessage(m.chat, { reactionMessage: { key: m.key, text: '📱' }}, { messageId: m.key.id });
   conn.sendMessage(m.chat, {
    text: payText, 
    contextInfo: {
      externalAdReply: {
        title: 'I N F O  S O S M E D',
        body: `${baileysVersion}`,
        thumbnailUrl: pickRandom(global.fotoRandom), 
        sourceUrl: `${web}`,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.command = /^(sosmed)$/i;
handler.tags = ['info'];
handler.help = ['sosmed'];

module.exports = handler;

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}