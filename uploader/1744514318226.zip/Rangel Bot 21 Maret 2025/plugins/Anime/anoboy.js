const axios = require('axios');

let handler = async (m, { q, reply }) => {
    if (!q) return reply('Masukkan judul anime yang ingin dicari.');

    try {
        let { data } = await axios.get(`https://api.neoxr.eu/api/anoboy?q=${encodeURIComponent(q)}&apikey=${Neoxr}`);
        
        if (!data.status || !data.data.length) {
            return reply('Anime tidak ditemukan atau terjadi kesalahan.');
        }

        let result = data.data.map(anime => `*${anime.title}*\n📅 Rilis: ${anime.up}\n🔗 Link: ${anime.url}`).join('\n\n');
        
        reply(result);
    } catch (error) {
        console.error(error);
        reply('Terjadi kesalahan saat mengambil data.');
    }
};

handler.help = ["anoboy"];
handler.tags = ["anime"];
handler.command = ["anoboy"];

module.exports = handler;