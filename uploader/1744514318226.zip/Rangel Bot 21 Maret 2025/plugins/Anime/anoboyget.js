const axios = require('axios');

let handler = async (m, { q, reply }) => {
    if (!q) return reply('Masukkan URL anime yang ingin diambil.');

    try {
        let { data } = await axios.get(`https://api.neoxr.eu/api/anoboy-get?url=${encodeURIComponent(q)}&apikey=${Neoxr}`);

        if (!data.status || !data.data) {
            return reply('Data anime tidak ditemukan atau terjadi kesalahan.');
        }

        let anime = data.data;
        let result = `*${anime.title}*\n\n📖 *Sinopsis:*\n${anime.sinopsis}\n\n🎬 *Studio:* ${anime.studio}\n🕒 *Durasi:* ${anime.duration}\n🏷️ *Genre:* ${anime.genre}\n⭐ *Score:* ${anime.score}\n\n🔗 *Streaming Links:*\n`;

        if (anime.stream) {
            anime.stream.forEach(provider => {
                result += `\n📺 *${provider.provider}:*\n`;
                provider.url.forEach(link => {
                    result += `▶️ [${link.quality}](${link.url})\n`;
                });
            });
        }

        result += `\n📥 *Download Links:*\n`;
        if (anime.download) {
            anime.download.forEach(provider => {
                result += `\n💾 *${provider.provider}:*\n`;
                provider.url.forEach(link => {
                    result += `📂 [${link.quality}](${link.url})\n`;
                });
            });
        }

        reply(result);
    } catch (error) {
        console.error(error);
        reply('Terjadi kesalahan saat mengambil data.');
    }
};

handler.help = ["anoboyget"];
handler.tags = ["anime"];
handler.command = ["anoboyget"];

module.exports = handler;