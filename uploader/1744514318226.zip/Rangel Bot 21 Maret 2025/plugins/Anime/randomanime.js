const axios = require('axios');
const fetch = require('node-fetch');

let handler = async (m, { command, conn, usedPrefix }) => {
    try {
        if (command === 'randomanime') {
            let commandsList = handler.command
                .filter((cmd) => cmd !== 'randomanime') 
                .map((cmd) => `${usedPrefix}${cmd}`) 
                .join('\n'); 

            return m.reply(`*Daftar Anime yang Tersedia:*\n\n${commandsList}`);
        }
        let imageUrlList, randomImage;
        if (['loli', 'cosplay', 'husbu', 'milf', 'wallml'].includes(command)) {
            const response = await axios.get(`https://raw.githubusercontent.com/Arya-was/endak-tau/main/${command}.json`);
            imageUrlList = response.data;
        } else {
            const response = await fetch(`https://raw.githubusercontent.com/KazukoGans/database/main/anime/${command}.json`);
            imageUrlList = await response.json();
        }
        if (!imageUrlList || imageUrlList.length === 0) throw 'Tidak ada gambar yang ditemukan!';
        randomImage = imageUrlList[Math.floor(Math.random() * imageUrlList.length)];
        const imageBuffer = await (await fetch(randomImage)).buffer();
        await conn.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `_${command}_`,
            footer: `Hasil pencarian dari kategori ${command}`,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'Wibu Bot',
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: randomImage,
                    sourceUrl: `https://wa.me/${global.nomerOwner}`
                }
            }
        }, { quoted: m });
    } catch (e) {
        console.error(e); 
        m.reply(`Terjadi kesalahan: ${e}`);
    }
};

handler.command = [
    'randomanime',
    'akira', 'akiyama', 'anna', 'asuna', 'ayuzawa', 'boruto', 'chitanda', 'chitoge', 'deidara',
    'doraemon', 'elaina', 'emilia', 'erza', 'gremory', 'hestia', 'hinata', 'inori', 'itachi',
    'isuzu', 'itori', 'kaga', 'kagura', 'kakasih', 'kaori', 'kaneki', 'kosaki', 'kotori', 'kuriyama',
    'kuroha', 'kurumi', 'madara', 'mikasa', 'miku', 'minato', 'naruto', 'natsukawa', 'nekohime',
    'nezuko', 'nishimiya', 'onepiece', 'pokemon', 'rem', 'rize', 'sagiri', 'sakura', 'sasuke', 'shina',
    'shinka', 'shizuka', 'shota', 'tomori', 'toukachan', 'tsunade', 'yatogami', 'yuki',
    'loli', 'cosplay', 'husbu', 'milf', 'wallml'
];

handler.tags = ['anime'];
handler.help = ['anime']; 
handler.noCmdPrivate = true; 
handler.description = ['Kumpulan gambar anime'];
handler.noCmdStore = true;

module.exports = handler;