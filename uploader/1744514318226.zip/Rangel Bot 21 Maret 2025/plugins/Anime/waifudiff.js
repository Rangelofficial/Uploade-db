const axios = require('axios');

let handler = async (m, { args, conn }) => {
    if (!args[0]) return m.reply('Masukkan kata kunci! Contoh: .waifudiff girl milk');
    
    const query = args.join(" ");
    mess.wait();

    try {
        const response = await axios.get(`https://api.neoxr.eu/api/waifudiff?q=${encodeURIComponent(query)}&apikey=${Neoxr}`);
        const data = response.data.data;

        if (!data || !data.url) {
            return m.reply('Gagal mendapatkan gambar.');
        }

        const caption = `🎨 *Waifu Diffusion* 🎨\n\n📌 *Prompt:* ${data.prompt}\n🔗 *URL:* [Klik disini](${data.url})`;

        await conn.sendMessage(m.chat, { image: { url: data.url }, caption }, { quoted: m });
    } catch (error) {
        console.error("Error fetching WaifuDiff:", error);
        m.reply('Terjadi kesalahan saat mengambil gambar.');
    }
};

handler.help = ['waifudiff <query>'];
handler.tags = ['ai'];
handler.command = ["waifudiff"];
handler.description = ['Mendapatkan gambar waifu berdasarkan prompt AI.'];

module.exports = handler;